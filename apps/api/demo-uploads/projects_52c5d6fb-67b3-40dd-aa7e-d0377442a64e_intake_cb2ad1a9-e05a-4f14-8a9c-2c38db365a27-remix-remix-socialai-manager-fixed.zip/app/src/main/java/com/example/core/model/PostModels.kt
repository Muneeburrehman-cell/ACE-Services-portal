package com.example.core.model

import java.util.UUID

data class PostItem(
    val id: String = UUID.randomUUID().toString(),
    val campaignId: String? = null,
    val platforms: List<SocialPlatform>,
    val topic: String,
    val primaryGoal: ContentGoal = ContentGoal.AWARENESS,
    val tone: ContentTone = ContentTone.PROFESSIONAL,
    // Platform-specific content maps:
    val instagramContent: PostPlatformContent? = null,
    val facebookContent: PostPlatformContent? = null,
    val linkedinContent: PostPlatformContent? = null,
    val attachedMediaUrls: List<String> = emptyList(),
    val status: PostStatus = PostStatus.DRAFT,
    val scheduledTimestamp: Long? = null,
    val publishedTimestamp: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val publishError: String? = null,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isFavorite: Boolean = false
) {
    fun getContentForPlatform(platform: SocialPlatform): PostPlatformContent? {
        return when (platform) {
            SocialPlatform.INSTAGRAM -> instagramContent
            SocialPlatform.FACEBOOK -> facebookContent
            SocialPlatform.LINKEDIN -> linkedinContent
        }
    }
}

enum class AiActionType {
    GENERATE_POST,
    GENERATE_MULTI_PLATFORM_POST,
    GENERATE_CAMPAIGN,
    CREATE_CALENDAR,
    ANALYZE_ANALYTICS,
    REWRITE_CONTENT,
    IMPROVE_HOOK,
    GENERATE_HASHTAGS,
    GENERATE_CTA,
    MAKE_PROFESSIONAL,
    MAKE_ENGAGING,
    SHORTEN,
    EXPAND,
    GET_ACCOUNT_STATUS,
    GENERAL_ADVICE
}

data class AiMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val detectedAction: AiActionType? = null,
    val structuredPostItem: PostItem? = null,
    val structuredCampaign: Campaign? = null,
    val structuredCalendarPlan: List<PostItem>? = null,
    val actionConfirmed: Boolean = false
)

data class AiCommandRequest(
    val prompt: String,
    val platform: SocialPlatform? = null,
    val goal: ContentGoal? = null,
    val tone: ContentTone? = null,
    val topic: String? = null,
    val currentText: String? = null,
    val brandContext: BrandProfile? = null
)
