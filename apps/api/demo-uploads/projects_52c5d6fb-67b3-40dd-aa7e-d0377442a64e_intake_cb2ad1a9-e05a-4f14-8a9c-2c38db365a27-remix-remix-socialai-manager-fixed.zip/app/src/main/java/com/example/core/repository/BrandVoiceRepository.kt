package com.example.core.repository

import com.example.core.database.BrandProfileDao
import com.example.core.database.BrandProfileEntity
import com.example.core.model.BrandProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BrandVoiceRepository(
    private val brandProfileDao: BrandProfileDao
) {
    fun getBrandProfile(): Flow<BrandProfile> = brandProfileDao.getBrandProfile().map { entity ->
        entity?.toDomainModel() ?: BrandProfile()
    }

    suspend fun getBrandProfileSync(): BrandProfile {
        return brandProfileDao.getBrandProfileSync()?.toDomainModel() ?: BrandProfile()
    }

    suspend fun saveBrandProfile(profile: BrandProfile) {
        brandProfileDao.insertOrUpdateProfile(profile.toEntity())
    }

    private fun BrandProfileEntity.toDomainModel() = BrandProfile(
        id = id,
        brandName = brandName,
        tagline = tagline,
        industry = industry,
        audience = audience,
        defaultTone = defaultTone,
        companyDescription = companyDescription,
        productsServices = productsServices,
        wordsToUse = wordsToUse,
        wordsToAvoid = wordsToAvoid,
        callToActionPreference = callToActionPreference
    )

    private fun BrandProfile.toEntity() = BrandProfileEntity(
        id = id,
        brandName = brandName,
        tagline = tagline,
        industry = industry,
        audience = audience,
        defaultTone = defaultTone,
        companyDescription = companyDescription,
        productsServices = productsServices,
        wordsToUse = wordsToUse,
        wordsToAvoid = wordsToAvoid,
        callToActionPreference = callToActionPreference
    )
}
