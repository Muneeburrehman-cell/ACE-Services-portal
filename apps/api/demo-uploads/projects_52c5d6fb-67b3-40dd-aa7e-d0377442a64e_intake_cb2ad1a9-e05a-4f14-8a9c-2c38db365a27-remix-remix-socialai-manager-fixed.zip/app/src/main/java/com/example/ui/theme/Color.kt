package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Core Theme Palette
val BrandPrimary = Color(0xFF0061A4)              // Crisp tech blue
val BrandPrimaryDark = Color(0xFF00487C)          // Deep blue
val BrandPrimaryContainer = Color(0xFFD1E4FF)     // Hero container blue
val BrandOnPrimaryContainer = Color(0xFF001D36)   // Deep navy contrast text
val BrandSecondary = Color(0xFF535F70)            // Refined slate
val BrandSecondaryContainer = Color(0xFFD7E3F8)
val BrandTertiary = Color(0xFF6B5778)             // Polished accent
val BrandTertiaryContainer = Color(0xFFF3DAFF)

// Platform Accents (Refined & Vibrant)
val InstagramPink = Color(0xFFE1306C)
val InstagramPurple = Color(0xFF833AB4)
val InstagramOrange = Color(0xFFF77737)
val FacebookBlue = Color(0xFF1877F2)
val FacebookLightBlue = Color(0xFFE7F3FF)
val LinkedInBlue = Color(0xFF0A66C2)
val LinkedInLightBlue = Color(0xFFE8F4F8)

// Semantic Accents with Soft Polish Containers
val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenContainer = Color(0xFFF0FDF4)
val WarningAmber = Color(0xFFD97706)
val WarningAmberContainer = Color(0xFFFEF3C7)
val ErrorRed = Color(0xFFBA1A1A)
val ErrorRedContainer = Color(0xFFFDF2F2)
val InfoSky = Color(0xFF0284C7)
val InfoSkyContainer = Color(0xFFF0F9FF)

// Dark Theme Surfaces
val DarkCanvas = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkBorder = Color(0xFF475569)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Light Theme Surfaces (Professional Polish)
val LightCanvas = Color(0xFFF8F9FF)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0F4FF)
val LightBorder = Color(0xFFDEE2EB)
val LightTextPrimary = Color(0xFF1A1C1E)
val LightTextSecondary = Color(0xFF43474E)
val LightTextMuted = Color(0xFF74777F)

