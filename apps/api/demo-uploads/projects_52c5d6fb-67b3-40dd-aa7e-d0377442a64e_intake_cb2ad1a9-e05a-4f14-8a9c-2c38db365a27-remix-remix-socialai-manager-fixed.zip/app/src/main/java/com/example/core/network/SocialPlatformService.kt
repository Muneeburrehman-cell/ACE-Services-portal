package com.example.core.network

import com.example.core.model.AnalyticsSnapshot
import com.example.core.model.PostPlatformContent
import com.example.core.model.SocialAccount
import com.example.core.model.SocialPlatform

sealed class SocialApiResult<out T> {
    data class Success<out T>(val data: T) : SocialApiResult<T>()
    data class Error(val message: String, val errorCode: String? = null, val isAuthExpired: Boolean = false) : SocialApiResult<Nothing>()
}

data class PublishPostResult(
    val platformPostId: String,
    val publishedUrl: String,
    val publishedTimestamp: Long = System.currentTimeMillis()
)

data class OAuthTokenResponse(
    val accessToken: String,
    val refreshToken: String? = null,
    val expiresInSeconds: Long,
    val scope: List<String>,
    val accountId: String,
    val accountName: String
)

interface SocialPlatformService {
    val platform: SocialPlatform
    suspend fun getAccountProfile(accountId: String): SocialApiResult<SocialAccount>
    suspend fun publishPost(accountId: String, content: PostPlatformContent, mediaUrls: List<String>): SocialApiResult<PublishPostResult>
    suspend fun fetchRecentAnalytics(accountId: String): SocialApiResult<List<AnalyticsSnapshot>>
    suspend fun disconnectAccount(accountId: String): SocialApiResult<Boolean>
    suspend fun validateToken(accountId: String): Boolean
}

class MockInstagramService : SocialPlatformService {
    override val platform: SocialPlatform = SocialPlatform.INSTAGRAM

    override suspend fun getAccountProfile(accountId: String): SocialApiResult<SocialAccount> {
        return SocialApiResult.Success(
            SocialAccount(
                id = accountId,
                platform = SocialPlatform.INSTAGRAM,
                accountName = "Pulse Creative Studio",
                handle = "@pulse_creative_ai",
                isConnected = true,
                isMock = true,
                followersCount = 24850,
                followingCount = 412,
                postsCount = 186,
                engagementRate = 4.8f
            )
        )
    }

    override suspend fun publishPost(
        accountId: String,
        content: PostPlatformContent,
        mediaUrls: List<String>
    ): SocialApiResult<PublishPostResult> {
        kotlinx.coroutines.delay(1200) // Realistic network simulation
        return SocialApiResult.Success(
            PublishPostResult(
                platformPostId = "ig_post_${System.currentTimeMillis()}",
                publishedUrl = "https://instagram.com/p/mock_${System.currentTimeMillis()}"
            )
        )
    }

    override suspend fun fetchRecentAnalytics(accountId: String): SocialApiResult<List<AnalyticsSnapshot>> {
        return SocialApiResult.Success(emptyList())
    }

    override suspend fun disconnectAccount(accountId: String): SocialApiResult<Boolean> {
        return SocialApiResult.Success(true)
    }

    override suspend fun validateToken(accountId: String): Boolean = true
}

class MockFacebookService : SocialPlatformService {
    override val platform: SocialPlatform = SocialPlatform.FACEBOOK

    override suspend fun getAccountProfile(accountId: String): SocialApiResult<SocialAccount> {
        return SocialApiResult.Success(
            SocialAccount(
                id = accountId,
                platform = SocialPlatform.FACEBOOK,
                accountName = "Pulse AI Global Community",
                handle = "PulseAIGlobal",
                isConnected = true,
                isMock = true,
                followersCount = 41200,
                followingCount = 98,
                postsCount = 342,
                engagementRate = 3.2f
            )
        )
    }

    override suspend fun publishPost(
        accountId: String,
        content: PostPlatformContent,
        mediaUrls: List<String>
    ): SocialApiResult<PublishPostResult> {
        kotlinx.coroutines.delay(1000)
        return SocialApiResult.Success(
            PublishPostResult(
                platformPostId = "fb_post_${System.currentTimeMillis()}",
                publishedUrl = "https://facebook.com/posts/mock_${System.currentTimeMillis()}"
            )
        )
    }

    override suspend fun fetchRecentAnalytics(accountId: String): SocialApiResult<List<AnalyticsSnapshot>> {
        return SocialApiResult.Success(emptyList())
    }

    override suspend fun disconnectAccount(accountId: String): SocialApiResult<Boolean> {
        return SocialApiResult.Success(true)
    }

    override suspend fun validateToken(accountId: String): Boolean = true
}

class MockLinkedInService : SocialPlatformService {
    override val platform: SocialPlatform = SocialPlatform.LINKEDIN

    override suspend fun getAccountProfile(accountId: String): SocialApiResult<SocialAccount> {
        return SocialApiResult.Success(
            SocialAccount(
                id = accountId,
                platform = SocialPlatform.LINKEDIN,
                accountName = "Pulse Studio Innovations",
                handle = "company/pulse-studio-ai",
                isConnected = true,
                isMock = true,
                followersCount = 18900,
                followingCount = 150,
                postsCount = 124,
                engagementRate = 6.1f
            )
        )
    }

    override suspend fun publishPost(
        accountId: String,
        content: PostPlatformContent,
        mediaUrls: List<String>
    ): SocialApiResult<PublishPostResult> {
        kotlinx.coroutines.delay(1400)
        return SocialApiResult.Success(
            PublishPostResult(
                platformPostId = "urn:li:share:${System.currentTimeMillis()}",
                publishedUrl = "https://linkedin.com/feed/update/urn:li:share:mock_${System.currentTimeMillis()}"
            )
        )
    }

    override suspend fun fetchRecentAnalytics(accountId: String): SocialApiResult<List<AnalyticsSnapshot>> {
        return SocialApiResult.Success(emptyList())
    }

    override suspend fun disconnectAccount(accountId: String): SocialApiResult<Boolean> {
        return SocialApiResult.Success(true)
    }

    override suspend fun validateToken(accountId: String): Boolean = true
}
