package com.example.core.database

import androidx.room.TypeConverter
import com.example.core.model.ContentGoal
import com.example.core.model.ContentTone
import com.example.core.model.PostPlatformContent
import com.example.core.model.PostStatus
import com.example.core.model.SocialPlatform
import org.json.JSONArray
import org.json.JSONObject

class Converters {

    @TypeConverter
    fun fromPlatform(platform: SocialPlatform?): String? = platform?.name

    @TypeConverter
    fun toPlatform(name: String?): SocialPlatform? = name?.let {
        try { SocialPlatform.valueOf(it) } catch (_: Exception) { null }
    }

    @TypeConverter
    fun fromPlatformList(platforms: List<SocialPlatform>?): String {
        if (platforms.isNullOrEmpty()) return ""
        return platforms.joinToString(",") { it.name }
    }

    @TypeConverter
    fun toPlatformList(data: String?): List<SocialPlatform> {
        if (data.isNullOrBlank()) return emptyList()
        return data.split(",").mapNotNull {
            try { SocialPlatform.valueOf(it.trim()) } catch (_: Exception) { null }
        }
    }

    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        if (list.isNullOrEmpty()) return ""
        val array = JSONArray()
        list.forEach { array.put(it) }
        return array.toString()
    }

    @TypeConverter
    fun toStringList(data: String?): List<String> {
        if (data.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(data)
            val list = mutableListOf<String>()
            for (i in 0 until array.length()) {
                list.add(array.getString(i))
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    @TypeConverter
    fun fromPostStatus(status: PostStatus?): String = status?.name ?: PostStatus.DRAFT.name

    @TypeConverter
    fun toPostStatus(name: String?): PostStatus = name?.let {
        try { PostStatus.valueOf(it) } catch (_: Exception) { PostStatus.DRAFT }
    } ?: PostStatus.DRAFT

    @TypeConverter
    fun fromGoal(goal: ContentGoal?): String = goal?.name ?: ContentGoal.AWARENESS.name

    @TypeConverter
    fun toGoal(name: String?): ContentGoal = name?.let {
        try { ContentGoal.valueOf(it) } catch (_: Exception) { ContentGoal.AWARENESS }
    } ?: ContentGoal.AWARENESS

    @TypeConverter
    fun fromTone(tone: ContentTone?): String = tone?.name ?: ContentTone.PROFESSIONAL.name

    @TypeConverter
    fun toTone(name: String?): ContentTone = name?.let {
        try { ContentTone.valueOf(it) } catch (_: Exception) { ContentTone.PROFESSIONAL }
    } ?: ContentTone.PROFESSIONAL

    @TypeConverter
    fun fromPlatformContent(content: PostPlatformContent?): String? {
        if (content == null) return null
        val json = JSONObject()
        json.put("platform", content.platform.name)
        json.put("hook", content.hook)
        json.put("body", content.body)
        json.put("callToAction", content.callToAction)
        json.put("visualIdea", content.visualIdea)
        json.put("characterCount", content.characterCount)
        val tags = JSONArray()
        content.hashtags.forEach { tags.put(it) }
        json.put("hashtags", tags)
        return json.toString()
    }

    @TypeConverter
    fun toPlatformContent(data: String?): PostPlatformContent? {
        if (data.isNullOrBlank()) return null
        return try {
            val json = JSONObject(data)
            val platform = SocialPlatform.valueOf(json.getString("platform"))
            val hook = json.optString("hook", "")
            val body = json.optString("body", "")
            val cta = json.optString("callToAction", "")
            val visualIdea = json.optString("visualIdea", "")
            val charCount = json.optInt("characterCount", 0)
            val tagsArray = json.optJSONArray("hashtags")
            val tags = mutableListOf<String>()
            if (tagsArray != null) {
                for (i in 0 until tagsArray.length()) {
                    tags.add(tagsArray.getString(i))
                }
            }
            PostPlatformContent(
                platform = platform,
                hook = hook,
                body = body,
                callToAction = cta,
                hashtags = tags,
                visualIdea = visualIdea,
                characterCount = charCount
            )
        } catch (_: Exception) {
            null
        }
    }
}
