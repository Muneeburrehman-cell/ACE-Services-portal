package com.example.core.repository

import com.example.core.database.AppNotificationEntity
import com.example.core.database.CampaignEntity
import com.example.core.database.ContentTemplateEntity
import com.example.core.database.PostDao
import com.example.core.database.PostEntity
import com.example.core.database.SocialAccountDao
import com.example.core.database.SocialAccountEntity
import com.example.core.database.SocialAiDatabase
import com.example.core.model.AppNotification
import com.example.core.model.Campaign
import com.example.core.model.ContentTemplate
import com.example.core.model.PostItem
import com.example.core.model.PostStatus
import com.example.core.model.SocialAccount
import com.example.core.model.SocialPlatform
import com.example.core.network.MockFacebookService
import com.example.core.network.MockInstagramService
import com.example.core.network.MockLinkedInService
import com.example.core.network.PublishPostResult
import com.example.core.network.SocialApiResult
import com.example.core.network.SocialPlatformService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class SocialMediaRepository(
    private val database: SocialAiDatabase
) {
    private val postDao = database.postDao()
    private val accountDao = database.socialAccountDao()
    private val campaignDao = database.campaignDao()
    private val templateDao = database.contentTemplateDao()
    private val notificationDao = database.appNotificationDao()

    private val igService: SocialPlatformService = MockInstagramService()
    private val fbService: SocialPlatformService = MockFacebookService()
    private val liService: SocialPlatformService = MockLinkedInService()

    fun getAllPosts(): Flow<List<PostItem>> = postDao.getAllPosts().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getScheduledPosts(): Flow<List<PostItem>> = postDao.getScheduledPosts().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getFavoritePosts(): Flow<List<PostItem>> = postDao.getFavoritePosts().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getAllAccounts(): Flow<List<SocialAccount>> = accountDao.getAllAccounts().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getConnectedAccounts(): Flow<List<SocialAccount>> = accountDao.getConnectedAccounts().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getAllCampaigns(): Flow<List<Campaign>> = campaignDao.getAllCampaigns().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getAllTemplates(): Flow<List<ContentTemplate>> = templateDao.getAllTemplates().map { list ->
        list.map { it.toDomainModel() }
    }

    fun getAllNotifications(): Flow<List<AppNotification>> = notificationDao.getAllNotifications().map { list ->
        list.map { it.toDomainModel() }
    }

    suspend fun savePost(post: PostItem) {
        postDao.insertPost(post.toEntity())
    }

    suspend fun savePosts(posts: List<PostItem>) {
        postDao.insertPosts(posts.map { it.toEntity() })
    }

    suspend fun updatePost(post: PostItem) {
        postDao.updatePost(post.toEntity())
    }

    suspend fun deletePost(post: PostItem) {
        postDao.deletePost(post.toEntity())
    }

    suspend fun deletePostById(id: String) {
        postDao.deletePostById(id)
    }

    suspend fun toggleFavorite(post: PostItem) {
        val updated = post.copy(isFavorite = !post.isFavorite)
        postDao.updatePost(updated.toEntity())
    }

    suspend fun saveCampaign(campaign: Campaign) {
        campaignDao.insertCampaign(campaign.toEntity())
    }

    suspend fun updateAccount(account: SocialAccount) {
        accountDao.updateAccount(account.toEntity())
    }

    suspend fun saveAccount(account: SocialAccount) {
        accountDao.insertAccount(account.toEntity())
    }

    suspend fun deleteAccount(account: SocialAccount) {
        accountDao.deleteAccount(account.toEntity())
    }

    suspend fun toggleAccountConnection(account: SocialAccount) {
        val updated = account.copy(
            isConnected = !account.isConnected,
            lastSyncTime = System.currentTimeMillis()
        )
        accountDao.updateAccount(updated.toEntity())
    }

    suspend fun publishPostNow(post: PostItem): Boolean {
        // Multi-platform publishing pipeline
        postDao.updatePost(post.copy(status = PostStatus.PUBLISHING).toEntity())

        var allSucceeded = true
        for (platform in post.platforms) {
            val content = post.getContentForPlatform(platform) ?: continue
            val service = when (platform) {
                SocialPlatform.INSTAGRAM -> igService
                SocialPlatform.FACEBOOK -> fbService
                SocialPlatform.LINKEDIN -> liService
            }
            val result = service.publishPost("acc_${platform.name}", content, post.attachedMediaUrls)
            if (result is SocialApiResult.Error) {
                allSucceeded = false
            }
        }

        val finalStatus = if (allSucceeded) PostStatus.PUBLISHED else PostStatus.FAILED
        val publishedTime = if (allSucceeded) System.currentTimeMillis() else null
        val errorMsg = if (!allSucceeded) "Some platform APIs returned an error during publishing." else null

        val updatedPost = post.copy(
            status = finalStatus,
            publishedTimestamp = publishedTime,
            publishError = errorMsg
        )
        postDao.updatePost(updatedPost.toEntity())

        if (allSucceeded) {
            notificationDao.insertNotification(
                AppNotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Post Published Successfully",
                    message = "Your post '${post.topic}' has been published across ${post.platforms.joinToString { it.displayName }}.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    actionRoute = "calendar"
                )
            )
        }

        return allSucceeded
    }

    suspend fun markNotificationAsRead(id: String) {
        notificationDao.markAsRead(id)
    }

    suspend fun clearAllNotifications() {
        notificationDao.clearAll()
    }

    // Converters:
    private fun PostEntity.toDomainModel() = PostItem(
        id = id,
        campaignId = campaignId,
        platforms = platforms,
        topic = topic,
        primaryGoal = primaryGoal,
        tone = tone,
        instagramContent = instagramContent,
        facebookContent = facebookContent,
        linkedinContent = linkedinContent,
        attachedMediaUrls = attachedMediaUrls,
        status = status,
        scheduledTimestamp = scheduledTimestamp,
        publishedTimestamp = publishedTimestamp,
        createdAt = createdAt,
        updatedAt = updatedAt,
        publishError = publishError,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isFavorite = isFavorite
    )

    private fun PostItem.toEntity() = PostEntity(
        id = id,
        campaignId = campaignId,
        platforms = platforms,
        topic = topic,
        primaryGoal = primaryGoal,
        tone = tone,
        instagramContent = instagramContent,
        facebookContent = facebookContent,
        linkedinContent = linkedinContent,
        attachedMediaUrls = attachedMediaUrls,
        status = status,
        scheduledTimestamp = scheduledTimestamp,
        publishedTimestamp = publishedTimestamp,
        createdAt = createdAt,
        updatedAt = updatedAt,
        publishError = publishError,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isFavorite = isFavorite
    )

    private fun SocialAccountEntity.toDomainModel() = SocialAccount(
        id = id,
        platform = platform,
        accountName = accountName,
        handle = handle,
        profileImageUrl = profileImageUrl,
        isConnected = isConnected,
        isMock = isMock,
        followersCount = followersCount,
        followingCount = followingCount,
        postsCount = postsCount,
        engagementRate = engagementRate,
        lastSyncTime = lastSyncTime,
        permissions = permissions,
        tokenExpiresAt = tokenExpiresAt
    )

    private fun SocialAccount.toEntity() = SocialAccountEntity(
        id = id,
        platform = platform,
        accountName = accountName,
        handle = handle,
        profileImageUrl = profileImageUrl,
        isConnected = isConnected,
        isMock = isMock,
        followersCount = followersCount,
        followingCount = followingCount,
        postsCount = postsCount,
        engagementRate = engagementRate,
        lastSyncTime = lastSyncTime,
        permissions = permissions,
        tokenExpiresAt = tokenExpiresAt
    )

    private fun CampaignEntity.toDomainModel() = Campaign(
        id = id,
        title = title,
        objective = objective,
        startDate = startDate,
        endDate = endDate,
        targetPlatforms = targetPlatforms,
        targetAudience = targetAudience,
        description = description,
        totalPostsPlanned = totalPostsPlanned,
        postsPublished = postsPublished,
        budgetNote = budgetNote,
        status = status
    )

    private fun Campaign.toEntity() = CampaignEntity(
        id = id,
        title = title,
        objective = objective,
        startDate = startDate,
        endDate = endDate,
        targetPlatforms = targetPlatforms,
        targetAudience = targetAudience,
        description = description,
        totalPostsPlanned = totalPostsPlanned,
        postsPublished = postsPublished,
        budgetNote = budgetNote,
        status = status
    )

    private fun ContentTemplateEntity.toDomainModel() = ContentTemplate(
        id = id,
        platform = platform,
        title = title,
        description = description,
        hookTemplate = hookTemplate,
        bodyTemplate = bodyTemplate,
        ctaTemplate = ctaTemplate,
        defaultHashtags = defaultHashtags,
        category = category
    )

    private fun AppNotificationEntity.toDomainModel() = AppNotification(
        id = id,
        title = title,
        message = message,
        timestamp = timestamp,
        platform = platform,
        isRead = isRead,
        actionRoute = actionRoute
    )
}
