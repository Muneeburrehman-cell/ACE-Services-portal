package com.example.core.model

import java.util.UUID

enum class SocialPlatform(
    val displayName: String,
    val brandColorHex: Long,
    val iconName: String,
    val maxCaptionLength: Int,
    val maxHashtags: Int,
    val defaultAudience: String
) {
    INSTAGRAM(
        displayName = "Instagram",
        brandColorHex = 0xFFE1306C,
        iconName = "instagram",
        maxCaptionLength = 2200,
        maxHashtags = 30,
        defaultAudience = "Visual, creative, lifestyle & reels audience"
    ),
    FACEBOOK(
        displayName = "Facebook",
        brandColorHex = 0xFF1877F2,
        iconName = "facebook",
        maxCaptionLength = 63206,
        maxHashtags = 10,
        defaultAudience = "Community, page followers, local audience"
    ),
    LINKEDIN(
        displayName = "LinkedIn",
        brandColorHex = 0xFF0A66C2,
        iconName = "linkedin",
        maxCaptionLength = 3000,
        maxHashtags = 5,
        defaultAudience = "B2B professionals, decision makers, industry leaders"
    )
}

enum class PostStatus {
    DRAFT,
    SCHEDULED,
    PUBLISHING,
    PUBLISHED,
    FAILED,
    NEEDS_ATTENTION
}

enum class ContentGoal(val label: String) {
    AWARENESS("Brand Awareness"),
    ENGAGEMENT("Audience Engagement"),
    LEADS("Lead Generation"),
    SALES("Product Sales"),
    EDUCATION("Educational Insights"),
    TRAFFIC("Website Traffic"),
    COMMUNITY("Community Building"),
    PERSONAL_BRANDING("Thought Leadership")
}

enum class ContentTone(val label: String) {
    PROFESSIONAL("Professional & Authoritative"),
    FRIENDLY("Friendly & Approachable"),
    EDUCATIONAL("Educational & Informative"),
    INSPIRATIONAL("Inspirational & Uplifting"),
    FUNNY("Witty & Humorous"),
    BOLD("Bold & Provocative"),
    LUXURY("Luxury & Sophisticated"),
    CASUAL("Casual & Authentic"),
    TECHNICAL("Technical & Deep-dive"),
    STORYTELLING("Narrative & Storytelling")
}

enum class ContentType(val label: String) {
    FEED_POST("Standard Feed Post"),
    CAROUSEL("Carousel Slides"),
    REELS_SCRIPT("Short Video / Reel Script"),
    STORY_CONCEPT("Story Sequence"),
    THOUGHT_LEADERSHIP("Long-form Essay"),
    CASE_STUDY("Case Study Breakdown"),
    POLL_OR_QUESTION("Community Question / Poll")
}

data class PostPlatformContent(
    val platform: SocialPlatform,
    val hook: String,
    val body: String,
    val callToAction: String,
    val hashtags: List<String> = emptyList(),
    val visualIdea: String = "",
    val characterCount: Int = 0
) {
    fun fullFormattedContent(): String {
        val sb = StringBuilder()
        if (hook.isNotBlank()) {
            sb.append(hook.trim()).append("\n\n")
        }
        if (body.isNotBlank()) {
            sb.append(body.trim()).append("\n\n")
        }
        if (callToAction.isNotBlank()) {
            sb.append(callToAction.trim()).append("\n\n")
        }
        if (hashtags.isNotEmpty()) {
            sb.append(hashtags.joinToString(" ") { if (it.startsWith("#")) it else "#$it" })
        }
        return sb.toString().trim()
    }
}

data class SocialAccount(
    val id: String = UUID.randomUUID().toString(),
    val platform: SocialPlatform,
    val accountName: String,
    val handle: String,
    val profileImageUrl: String = "",
    val isConnected: Boolean = true,
    val isMock: Boolean = false,
    val followersCount: Long = 0L,
    val followingCount: Long = 0L,
    val postsCount: Int = 0,
    val engagementRate: Float = 0f,
    val lastSyncTime: Long = System.currentTimeMillis(),
    val permissions: List<String> = emptyList(),
    val tokenExpiresAt: Long = System.currentTimeMillis() + (60L * 24 * 60 * 60 * 1000) // 60 days
)

data class BrandProfile(
    val id: String = "default_brand",
    val brandName: String = "Pulse Studio",
    val tagline: String = "Modern Creative Tech & Growth Agency",
    val industry: String = "Digital Marketing & AI Tech",
    val audience: String = "Founders, marketing directors, and creative entrepreneurs",
    val defaultTone: ContentTone = ContentTone.PROFESSIONAL,
    val companyDescription: String = "We build high-growth AI digital products and empower modern brands to scale their social footprint.",
    val productsServices: String = "Social media automation, AI marketing strategy, design consultancy",
    val wordsToUse: List<String> = listOf("impactful", "growth", "strategy", "streamlined", "next-gen"),
    val wordsToAvoid: List<String> = listOf("cheap", "revolutionary gimmick", "guaranteed overnight", "easy cash"),
    val callToActionPreference: String = "Join the conversation or visit our website to explore more."
)

data class Campaign(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val objective: ContentGoal = ContentGoal.AWARENESS,
    val startDate: Long = System.currentTimeMillis(),
    val endDate: Long = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000),
    val targetPlatforms: List<SocialPlatform> = listOf(SocialPlatform.INSTAGRAM, SocialPlatform.FACEBOOK, SocialPlatform.LINKEDIN),
    val targetAudience: String = "All Followers",
    val description: String = "",
    val totalPostsPlanned: Int = 7,
    val postsPublished: Int = 0,
    val budgetNote: String = "",
    val status: String = "ACTIVE"
)

data class ContentTemplate(
    val id: String = UUID.randomUUID().toString(),
    val platform: SocialPlatform,
    val title: String,
    val description: String,
    val hookTemplate: String,
    val bodyTemplate: String,
    val ctaTemplate: String,
    val defaultHashtags: List<String> = emptyList(),
    val category: String = "General"
)

data class AnalyticsSnapshot(
    val id: String = UUID.randomUUID().toString(),
    val platform: SocialPlatform,
    val dateTimestamp: Long,
    val impressions: Long,
    val reach: Long,
    val followers: Long,
    val followerChange: Long,
    val likes: Long,
    val comments: Long,
    val shares: Long,
    val saves: Long,
    val clicks: Long,
    val engagementRate: Float,
    val topPostId: String? = null
)

data class AutomationRule(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val isEnabled: Boolean = true,
    val triggerType: String,
    val actionType: String
)

data class AppNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val platform: SocialPlatform? = null,
    val isRead: Boolean = false,
    val actionRoute: String? = null
)
