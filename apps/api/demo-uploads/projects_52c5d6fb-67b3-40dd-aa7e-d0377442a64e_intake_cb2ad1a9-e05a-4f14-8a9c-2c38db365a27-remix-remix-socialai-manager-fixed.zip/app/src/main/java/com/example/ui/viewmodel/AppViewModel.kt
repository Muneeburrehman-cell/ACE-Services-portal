package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.SocialAiDatabase
import com.example.core.model.AiActionType
import com.example.core.model.AiMessage
import com.example.core.model.AppNotification
import com.example.core.model.BrandProfile
import com.example.core.model.Campaign
import com.example.core.model.ContentGoal
import com.example.core.model.ContentTemplate
import com.example.core.model.ContentTone
import com.example.core.model.PostItem
import com.example.core.model.PostPlatformContent
import com.example.core.model.PostStatus
import com.example.core.model.SocialAccount
import com.example.core.model.SocialPlatform
import com.example.core.network.AiContentEngine
import com.example.core.repository.AiWeeklyReport
import com.example.core.repository.AnalyticsRepository
import com.example.core.repository.BrandVoiceRepository
import com.example.core.repository.MultiPlatformSummary
import com.example.core.repository.SocialMediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SocialAiDatabase.getDatabase(application, viewModelScope)
    val socialRepo = SocialMediaRepository(database)
    val brandRepo = BrandVoiceRepository(database.brandProfileDao())
    val analyticsRepo = AnalyticsRepository(database.analyticsDao())
    private val aiEngine = AiContentEngine()

    // State Flows from Room:
    val posts: StateFlow<List<PostItem>> = socialRepo.getAllPosts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scheduledPosts: StateFlow<List<PostItem>> = socialRepo.getScheduledPosts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accounts: StateFlow<List<SocialAccount>> = socialRepo.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val brandProfile: StateFlow<BrandProfile> = brandRepo.getBrandProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BrandProfile())

    val campaigns: StateFlow<List<Campaign>> = socialRepo.getAllCampaigns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val templates: StateFlow<List<ContentTemplate>> = socialRepo.getAllTemplates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = socialRepo.getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Chat & Command Center State:
    private val _aiMessages = MutableStateFlow<List<AiMessage>>(
        listOf(
            AiMessage(
                isUser = false,
                messageText = "Hello! I'm your SocialAI Strategist. I can create platform-adapted posts, architect 7-day campaigns, generate content calendars, and analyze performance for Instagram, Facebook, and LinkedIn. What would you like to build today?"
            )
        )
    )
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _isAiGenerating = MutableStateFlow(false)
    val isAiGenerating: StateFlow<Boolean> = _isAiGenerating.asStateFlow()

    // Active Editor / Post Creation State:
    private val _activeEditingPost = MutableStateFlow<PostItem?>(null)
    val activeEditingPost: StateFlow<PostItem?> = _activeEditingPost.asStateFlow()

    // UI Status / Toast / Banner message:
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // Analytics Summary State:
    private val _analyticsSummary = MutableStateFlow<MultiPlatformSummary?>(null)
    val analyticsSummary: StateFlow<MultiPlatformSummary?> = _analyticsSummary.asStateFlow()

    private val _weeklyReport = MutableStateFlow<AiWeeklyReport?>(null)
    val weeklyReport: StateFlow<AiWeeklyReport?> = _weeklyReport.asStateFlow()

    init {
        loadAnalyticsSummary()
    }

    private fun loadAnalyticsSummary() {
        viewModelScope.launch {
            analyticsRepo.getAllSnapshots().collect { snapshots ->
                val summary = analyticsRepo.getSummary(snapshots)
                _analyticsSummary.value = summary
                _weeklyReport.value = analyticsRepo.generateWeeklyReport(summary)
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    // AI Command Center Natural Language execution:
    fun sendAiCommand(command: String) {
        if (command.isBlank()) return
        val userMsg = AiMessage(isUser = true, messageText = command)
        _aiMessages.value = _aiMessages.value + userMsg
        _isAiGenerating.value = true

        viewModelScope.launch {
            try {
                val currentBrand = brandProfile.value
                val aiReply = aiEngine.processNaturalLanguageCommand(command, currentBrand, posts.value.size)
                _aiMessages.value = _aiMessages.value + aiReply
            } catch (e: Exception) {
                _aiMessages.value = _aiMessages.value + AiMessage(
                    isUser = false,
                    messageText = "An error occurred during AI generation: ${e.localizedMessage ?: "Unknown error"}"
                )
            } finally {
                _isAiGenerating.value = false
            }
        }
    }

    fun approveAndSaveAiPost(postItem: PostItem) {
        viewModelScope.launch {
            socialRepo.savePost(postItem)
            _statusMessage.value = "Post saved to your content schedule!"
        }
    }

    // Multi-Platform Generation ("Create Everywhere"):
    fun generateMultiPlatformPost(
        topic: String,
        goal: ContentGoal,
        tone: ContentTone,
        platforms: List<SocialPlatform>,
        onSuccess: (PostItem) -> Unit
    ) {
        _isAiGenerating.value = true
        viewModelScope.launch {
            try {
                val post = aiEngine.generateMultiPlatformPost(
                    topic = topic,
                    goal = goal,
                    tone = tone,
                    brandProfile = brandProfile.value,
                    platforms = platforms
                )
                _activeEditingPost.value = post
                onSuccess(post)
            } catch (e: Exception) {
                _statusMessage.value = "Failed to generate post: ${e.message}"
            } finally {
                _isAiGenerating.value = false
            }
        }
    }

    // AI Content Rewrite (Hooks, tone, shorten, expand, CTA):
    fun rewritePlatformContent(
        platform: SocialPlatform,
        action: AiActionType,
        currentContent: PostPlatformContent,
        onResult: (String) -> Unit
    ) {
        _isAiGenerating.value = true
        viewModelScope.launch {
            try {
                val textToModify = if (action == AiActionType.IMPROVE_HOOK) currentContent.hook else currentContent.body
                val result = aiEngine.rewriteText(
                    text = textToModify.ifBlank { currentContent.fullFormattedContent() },
                    action = action,
                    platform = platform,
                    tone = brandProfile.value.defaultTone
                )
                onResult(result)
            } catch (e: Exception) {
                _statusMessage.value = "Rewrite failed: ${e.message}"
            } finally {
                _isAiGenerating.value = false
            }
        }
    }

    // Save or Schedule Post:
    fun savePost(post: PostItem, isScheduled: Boolean = false, scheduledTime: Long? = null) {
        viewModelScope.launch {
            val status = if (isScheduled && scheduledTime != null) PostStatus.SCHEDULED else PostStatus.DRAFT
            val itemToSave = post.copy(
                status = status,
                scheduledTimestamp = scheduledTime ?: post.scheduledTimestamp,
                updatedAt = System.currentTimeMillis()
            )
            socialRepo.savePost(itemToSave)
            _statusMessage.value = if (status == PostStatus.SCHEDULED) "Post scheduled successfully!" else "Draft saved successfully!"
        }
    }

    // Publish Post immediately:
    fun publishNow(post: PostItem) {
        viewModelScope.launch {
            _statusMessage.value = "Publishing to ${post.platforms.joinToString { it.displayName }}..."
            val success = socialRepo.publishPostNow(post)
            _statusMessage.value = if (success) "Published successfully to all selected platforms!" else "Publishing failed. Please check connected account status."
        }
    }

    fun deletePost(post: PostItem) {
        viewModelScope.launch {
            socialRepo.deletePost(post)
            _statusMessage.value = "Post deleted."
        }
    }

    fun toggleFavorite(post: PostItem) {
        viewModelScope.launch {
            socialRepo.toggleFavorite(post)
        }
    }

    // AI Calendar Generator:
    fun generateAiCalendar(
        daysCount: Int,
        platforms: List<SocialPlatform>,
        goal: ContentGoal,
        businessType: String,
        onComplete: (List<PostItem>) -> Unit
    ) {
        _isAiGenerating.value = true
        viewModelScope.launch {
            try {
                val plannedPosts = aiEngine.generateCalendarPlan(
                    daysCount = daysCount,
                    platforms = platforms,
                    objective = goal,
                    businessType = businessType,
                    brandProfile = brandProfile.value
                )
                socialRepo.savePosts(plannedPosts)
                _statusMessage.value = "Generated $daysCount-day content calendar with ${plannedPosts.size} scheduled posts!"
                onComplete(plannedPosts)
            } catch (e: Exception) {
                _statusMessage.value = "Calendar generation failed: ${e.message}"
            } finally {
                _isAiGenerating.value = false
            }
        }
    }

    // Brand Profile Update:
    fun updateBrandProfile(profile: BrandProfile) {
        viewModelScope.launch {
            brandRepo.saveBrandProfile(profile)
            _statusMessage.value = "Brand Voice Profile updated successfully!"
        }
    }

    // Account Management:
    fun toggleAccountConnection(account: SocialAccount) {
        viewModelScope.launch {
            socialRepo.toggleAccountConnection(account)
            _statusMessage.value = "${account.platform.displayName} account connection updated."
        }
    }

    fun saveOrUpdateAccount(account: SocialAccount) {
        viewModelScope.launch {
            socialRepo.saveAccount(account)
            _statusMessage.value = "${account.accountName} (${account.platform.displayName}) saved successfully!"
        }
    }

    fun deleteAccount(account: SocialAccount) {
        viewModelScope.launch {
            socialRepo.deleteAccount(account)
            _statusMessage.value = "${account.accountName} removed."
        }
    }

    fun disconnectAllAccounts() {
        viewModelScope.launch {
            accounts.value.forEach { account ->
                if (account.isConnected) {
                    socialRepo.updateAccount(account.copy(isConnected = false))
                }
            }
            _statusMessage.value = "All demo channels disconnected."
        }
    }

    // Create Campaign:
    fun saveCampaign(campaign: Campaign) {
        viewModelScope.launch {
            socialRepo.saveCampaign(campaign)
            _statusMessage.value = "Campaign '${campaign.title}' saved!"
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            socialRepo.markNotificationAsRead(id)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            socialRepo.clearAllNotifications()
            _statusMessage.value = "All notifications cleared."
        }
    }
}
