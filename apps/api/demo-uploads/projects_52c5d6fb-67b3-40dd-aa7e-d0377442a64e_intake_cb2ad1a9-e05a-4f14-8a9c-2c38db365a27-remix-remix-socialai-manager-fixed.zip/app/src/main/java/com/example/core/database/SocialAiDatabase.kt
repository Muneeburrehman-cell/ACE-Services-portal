package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.core.model.ContentGoal
import com.example.core.model.ContentTone
import com.example.core.model.PostPlatformContent
import com.example.core.model.PostStatus
import com.example.core.model.SocialPlatform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        PostEntity::class,
        SocialAccountEntity::class,
        BrandProfileEntity::class,
        CampaignEntity::class,
        ContentTemplateEntity::class,
        AnalyticsSnapshotEntity::class,
        AutomationRuleEntity::class,
        AppNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class SocialAiDatabase : RoomDatabase() {

    abstract fun postDao(): PostDao
    abstract fun socialAccountDao(): SocialAccountDao
    abstract fun brandProfileDao(): BrandProfileDao
    abstract fun campaignDao(): CampaignDao
    abstract fun contentTemplateDao(): ContentTemplateDao
    abstract fun analyticsDao(): AnalyticsDao
    abstract fun appNotificationDao(): AppNotificationDao
    abstract fun automationRuleDao(): AutomationRuleDao

    companion object {
        @Volatile
        private var INSTANCE: SocialAiDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): SocialAiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SocialAiDatabase::class.java,
                    "social_ai_manager_database"
                )
                    .fallbackToDestructiveMigration(false)
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: SocialAiDatabase) {
            // Populate Default Brand
            val defaultBrand = BrandProfileEntity(
                id = "default_brand",
                brandName = "Pulse AI Studio",
                tagline = "Empowering Next-Gen Creators & Brands",
                industry = "SaaS, AI & Growth Marketing",
                audience = "Tech founders, social media managers, modern creators, B2B agencies",
                defaultTone = ContentTone.PROFESSIONAL,
                companyDescription = "Pulse AI is an all-in-one AI social growth suite providing automated content generation, cross-platform scheduling, and deep analytics intelligence.",
                productsServices = "SocialAI Assistant, Multi-Platform Content Engine, AI Analytics Insights, Auto-Scheduler",
                wordsToUse = listOf("actionable", "frictionless", "data-driven", "scalable", "high-conversion", "seamless"),
                wordsToAvoid = listOf("get rich quick", "revolutionary magic", "spammy", "cheap tricks"),
                callToActionPreference = "Tap the link in bio to start your free 14-day trial or drop your thoughts below!"
            )
            database.brandProfileDao().insertOrUpdateProfile(defaultBrand)

            // Populate Initial Social Accounts (Demo / Sample State)
            val accounts = listOf(
                SocialAccountEntity(
                    id = "ig_acc_1",
                    platform = SocialPlatform.INSTAGRAM,
                    accountName = "Pulse Creative Studio",
                    handle = "@pulse_creative_ai",
                    profileImageUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150",
                    isConnected = true,
                    isMock = true,
                    followersCount = 24850,
                    followingCount = 412,
                    postsCount = 186,
                    engagementRate = 4.8f,
                    lastSyncTime = System.currentTimeMillis() - (15 * 60 * 1000),
                    permissions = listOf("instagram_basic", "instagram_content_publish", "pages_read_engagement", "instagram_manage_insights")
                ),
                SocialAccountEntity(
                    id = "fb_acc_1",
                    platform = SocialPlatform.FACEBOOK,
                    accountName = "Pulse AI Global Community",
                    handle = "PulseAIGlobal",
                    profileImageUrl = "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=150",
                    isConnected = true,
                    isMock = true,
                    followersCount = 41200,
                    followingCount = 98,
                    postsCount = 342,
                    engagementRate = 3.2f,
                    lastSyncTime = System.currentTimeMillis() - (35 * 60 * 1000),
                    permissions = listOf("pages_manage_posts", "pages_read_engagement", "pages_show_list", "read_insights")
                ),
                SocialAccountEntity(
                    id = "li_acc_1",
                    platform = SocialPlatform.LINKEDIN,
                    accountName = "Pulse Studio Innovations",
                    handle = "company/pulse-studio-ai",
                    profileImageUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
                    isConnected = true,
                    isMock = true,
                    followersCount = 18900,
                    followingCount = 150,
                    postsCount = 124,
                    engagementRate = 6.1f,
                    lastSyncTime = System.currentTimeMillis() - (8 * 60 * 1000),
                    permissions = listOf("w_member_social", "r_basicprofile", "w_organization_social", "r_organization_social")
                )
            )
            database.socialAccountDao().insertAccounts(accounts)

            // Populate Initial Templates
            val templates = listOf(
                ContentTemplateEntity(
                    id = "tpl_ig_1",
                    platform = SocialPlatform.INSTAGRAM,
                    title = "Product Launch Reel / Carousel",
                    description = "High-converting visual hook with value breakdown and CTA.",
                    hookTemplate = "Stop doing {old_way}. Here is the exact playbook we used to achieve {result} in 14 days 🧵👇",
                    bodyTemplate = "1️⃣ The Mindset Shift: Stop chasing vanity metrics.\n2️⃣ The Core Workflow: Automate repetitive tasks.\n3️⃣ The Growth Lever: Consistency across multiple platforms.\n\nSave this for your next campaign planning!",
                    ctaTemplate = "👉 Which step are you implementing first? Comment 'GUIDE' and I'll DM you the breakdown!",
                    defaultHashtags = listOf("SocialMediaStrategy", "GrowthHacking", "InstagramTips", "ContentCreator", "DigitalMarketing"),
                    category = "Product Launch"
                ),
                ContentTemplateEntity(
                    id = "tpl_li_1",
                    platform = SocialPlatform.LINKEDIN,
                    title = "Thought Leadership Breakdown",
                    description = "Executive insight structure designed for LinkedIn algorithms.",
                    hookTemplate = "Most founders spend 20 hours a week on social media with zero pipeline results.\n\nHere is how top 1% teams fix their distribution engine:",
                    bodyTemplate = "• Build a modular asset bank once a month.\n• Tailor the narrative specifically for B2B decision makers on LinkedIn.\n• Focus on solving real business friction rather than posting generic hype.\n\nExecution beats brainstorms every single quarter.",
                    ctaTemplate = "What is your biggest bottleneck in scaling content distribution right now? Let's discuss in the comments.",
                    defaultHashtags = listOf("Leadership", "B2BMarketing", "Strategy", "Entrepreneurship"),
                    category = "Thought Leadership"
                ),
                ContentTemplateEntity(
                    id = "tpl_fb_1",
                    platform = SocialPlatform.FACEBOOK,
                    title = "Community Discussion & Engagement",
                    description = "Stimulates organic conversation and comments in groups and pages.",
                    hookTemplate = "Quick question for the community: What is one tool in your daily tech stack that you genuinely can't live without in 2026? 💬",
                    bodyTemplate = "We recently surveyed 200+ marketing teams, and 78% said AI scheduling and content repurposing saved them 10+ hours every week.\n\nWe want to hear from your real-world experience!",
                    ctaTemplate = "Drop your favorite tool and how it helps you below! We'll pin the most insightful answers.",
                    defaultHashtags = listOf("Community", "MarketingTools", "Productivity"),
                    category = "Community"
                )
            )
            database.contentTemplateDao().insertTemplates(templates)

            // Populate Initial Sample Posts
            val now = System.currentTimeMillis()
            val samplePosts = listOf(
                PostEntity(
                    id = "post_1",
                    platforms = listOf(SocialPlatform.INSTAGRAM, SocialPlatform.FACEBOOK, SocialPlatform.LINKEDIN),
                    topic = "The 2026 AI Social Media Playbook",
                    primaryGoal = ContentGoal.AWARENESS,
                    tone = ContentTone.PROFESSIONAL,
                    instagramContent = PostPlatformContent(
                        platform = SocialPlatform.INSTAGRAM,
                        hook = "✨ AI isn't replacing social media managers—it's creating 10x creators.",
                        body = "Here are 3 rules we follow to produce 30 days of high-converting content in under 2 hours:\n\n1. Use AI to structure hooks & outlines, never raw copy.\n2. Adapt the tone strictly per platform.\n3. Keep your authentic brand voice front and center.",
                        callToAction = "Save this reel and tap link in bio for the complete template!",
                        hashtags = listOf("SocialAI", "ContentStrategy", "InstagramGrowth", "AITools")
                    ),
                    facebookContent = PostPlatformContent(
                        platform = SocialPlatform.FACEBOOK,
                        hook = "How are modern teams managing 3+ social channels without burning out?",
                        body = "We broke down the exact framework we use at Pulse AI to streamline cross-posting from Instagram to LinkedIn and Facebook without duplicating content verbatim.\n\nEvery platform has a unique audience expectation, and tailoring your message makes all the difference.",
                        callToAction = "Check out our latest case study breakdown and share your thoughts below!",
                        hashtags = listOf("DigitalMarketing", "Productivity", "Community")
                    ),
                    linkedinContent = PostPlatformContent(
                        platform = SocialPlatform.LINKEDIN,
                        hook = "The biggest mistake in multi-channel marketing is copying Instagram captions directly to LinkedIn.",
                        body = "LinkedIn demands business context, concrete metrics, and professional narrative framing.\n\nWhen we shifted our B2B strategy to platform-tailored thought leadership:\n• Inbound leads jumped +44%\n• Executive comment engagement tripled\n• Content production time dropped by 65%",
                        callToAction = "How has your team adapted content across professional vs visual channels? Let's connect.",
                        hashtags = listOf("B2BMarketing", "Leadership", "AIStrategy")
                    ),
                    status = PostStatus.SCHEDULED,
                    scheduledTimestamp = now + (2 * 60 * 60 * 1000), // in 2 hours
                    likesCount = 0,
                    commentsCount = 0,
                    isFavorite = true
                ),
                PostEntity(
                    id = "post_2",
                    platforms = listOf(SocialPlatform.LINKEDIN),
                    topic = "5 Strategies for Scaling Organic B2B Pipeline",
                    primaryGoal = ContentGoal.LEADS,
                    tone = ContentTone.EDUCATIONAL,
                    linkedinContent = PostPlatformContent(
                        platform = SocialPlatform.LINKEDIN,
                        hook = "5 frameworks that transformed our organic B2B outreach pipeline in Q3:",
                        body = "1. The Value-First Carousel: Teach something actionable in 6 slides.\n2. The Founder Teardown: Honest post-mortems of campaign wins & failures.\n3. The Industry Benchmark: Original data snapshots.\n4. Micro-interviews with category leaders.\n5. Structured polls with clear follow-up insights.",
                        callToAction = "Download our free Q3 Pipeline Blueprint via the link in the comments.",
                        hashtags = listOf("B2BGrowth", "LeadGen", "MarketingStrategy")
                    ),
                    status = PostStatus.PUBLISHED,
                    publishedTimestamp = now - (24 * 60 * 60 * 1000),
                    likesCount = 342,
                    commentsCount = 48,
                    sharesCount = 29,
                    isFavorite = true
                ),
                PostEntity(
                    id = "post_3",
                    platforms = listOf(SocialPlatform.INSTAGRAM),
                    topic = "Behind The Scenes: Creative Studio Workspace",
                    primaryGoal = ContentGoal.ENGAGEMENT,
                    tone = ContentTone.FRIENDLY,
                    instagramContent = PostPlatformContent(
                        platform = SocialPlatform.INSTAGRAM,
                        hook = "A peek behind the curtain at Pulse Studio ⚡️",
                        body = "From mood boards to AI-generated campaign prototypes, here is where our daily magic happens. Which setup element is your favorite?",
                        callToAction = "Drop an emoji below that matches your current work vibe! 🔥 ☕️ 💻",
                        hashtags = listOf("StudioVibes", "CreativeWorkspace", "BTS", "AgencyLife")
                    ),
                    status = PostStatus.PUBLISHED,
                    publishedTimestamp = now - (48 * 60 * 60 * 1000),
                    likesCount = 890,
                    commentsCount = 67,
                    sharesCount = 14
                )
            )
            database.postDao().insertPosts(samplePosts)

            // Populate Initial Analytics
            val analytics = mutableListOf<AnalyticsSnapshotEntity>()
            val dayMillis = 24 * 60 * 60 * 1000L
            for (i in 0 until 7) {
                val dayTime = now - (i * dayMillis)
                analytics.add(
                    AnalyticsSnapshotEntity(
                        id = "an_ig_$i",
                        platform = SocialPlatform.INSTAGRAM,
                        dateTimestamp = dayTime,
                        impressions = 14500L + (i * 820),
                        reach = 9800L + (i * 610),
                        followers = 24850L - (i * 75),
                        followerChange = 75L + (i * 4),
                        likes = 1240L + (i * 50),
                        comments = 180L + (i * 12),
                        shares = 94L + (i * 6),
                        saves = 135L + (i * 8),
                        clicks = 420L + (i * 20),
                        engagementRate = 4.8f + (i * 0.1f)
                    )
                )
                analytics.add(
                    AnalyticsSnapshotEntity(
                        id = "an_fb_$i",
                        platform = SocialPlatform.FACEBOOK,
                        dateTimestamp = dayTime,
                        impressions = 21000L + (i * 900),
                        reach = 16200L + (i * 700),
                        followers = 41200L - (i * 60),
                        followerChange = 60L + (i * 5),
                        likes = 890L + (i * 40),
                        comments = 145L + (i * 10),
                        shares = 110L + (i * 8),
                        saves = 45L + (i * 3),
                        clicks = 680L + (i * 30),
                        engagementRate = 3.2f + (i * 0.05f)
                    )
                )
                analytics.add(
                    AnalyticsSnapshotEntity(
                        id = "an_li_$i",
                        platform = SocialPlatform.LINKEDIN,
                        dateTimestamp = dayTime,
                        impressions = 18200L + (i * 1100),
                        reach = 12400L + (i * 850),
                        followers = 18900L - (i * 90),
                        followerChange = 90L + (i * 8),
                        likes = 980L + (i * 60),
                        comments = 210L + (i * 18),
                        shares = 88L + (i * 9),
                        saves = 190L + (i * 15),
                        clicks = 850L + (i * 45),
                        engagementRate = 6.1f + (i * 0.12f)
                    )
                )
            }
            database.analyticsDao().insertSnapshots(analytics)

            // Populate Initial Automation Rules
            val rules = listOf(
                AutomationRuleEntity(
                    id = "auto_1",
                    title = "Smart Best-Time Auto Scheduling",
                    description = "When a draft is approved, automatically schedule for the peak engagement hour.",
                    isEnabled = true,
                    triggerType = "ON_POST_APPROVE",
                    actionType = "AUTO_SCHEDULE_BEST_TIME"
                ),
                AutomationRuleEntity(
                    id = "auto_2",
                    title = "Weekly AI Strategy & Growth Briefing",
                    description = "Generate a strategic performance report every Monday morning.",
                    isEnabled = true,
                    triggerType = "CRON_WEEKLY_MONDAY",
                    actionType = "GENERATE_AI_REPORT"
                ),
                AutomationRuleEntity(
                    id = "auto_3",
                    title = "Safety & Brand Tone Guardrails",
                    description = "Scan generated posts for forbidden keywords and platform formatting rules.",
                    isEnabled = true,
                    triggerType = "PRE_PUBLISH_VALIDATION",
                    actionType = "BLOCK_VIOLATIONS"
                )
            )
            database.automationRuleDao().insertRules(rules)

            // Populate Initial Notifications
            val notifications = listOf(
                AppNotificationEntity(
                    id = "notif_1",
                    title = "AI Weekly Report Ready",
                    message = "Your weekly multi-platform report is ready! LinkedIn engagement was up +18.4% this week.",
                    timestamp = now - (2 * 60 * 60 * 1000),
                    platform = SocialPlatform.LINKEDIN,
                    isRead = false,
                    actionRoute = "analytics"
                ),
                AppNotificationEntity(
                    id = "notif_2",
                    title = "Upcoming Post Reminder",
                    message = "'The 2026 AI Social Media Playbook' will be published across IG, FB, and LinkedIn in 2 hours.",
                    timestamp = now - (30 * 60 * 1000),
                    platform = SocialPlatform.INSTAGRAM,
                    isRead = false,
                    actionRoute = "calendar"
                )
            )
            database.appNotificationDao().insertNotification(notifications[0])
            database.appNotificationDao().insertNotification(notifications[1])
        }
    }
}
