package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.SocialAccount
import com.example.core.model.SocialPlatform
import com.example.ui.components.PlatformBadge
import com.example.ui.theme.BrandOnPrimaryContainer
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandPrimaryContainer
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramOrange
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.InstagramPurple
import com.example.ui.theme.LinkedInBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.AppViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectedAccountsScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsStateWithLifecycle()

    var editingAccount by remember { mutableStateOf<SocialAccount?>(null) }
    var isAddingNewAccount by remember { mutableStateOf(false) }
    var showDisconnectAllDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("connected_accounts_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Connected Channels", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Setup Real Profiles & OAuth Permissions", style = MaterialTheme.typography.labelSmall, color = BrandPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showDisconnectAllDialog = true },
                        modifier = Modifier.testTag("disconnect_all_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Disconnect All",
                            tint = ErrorRed
                        )
                    }
                    Button(
                        onClick = { isAddingNewAccount = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(end = 8.dp).testTag("add_channel_top_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Channel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header instruction card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(BrandPrimaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = BrandOnPrimaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Custom Social Profiles & OAuth",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Edit existing demo accounts with your real handles, or add new profiles.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            items(accounts, key = { it.id }) { account ->
                ConnectedAccountCard(
                    account = account,
                    onEditClick = { editingAccount = account },
                    onDeleteClick = { viewModel.deleteAccount(account) },
                    onToggleConnection = { viewModel.toggleAccountConnection(account) }
                )
            }

            item {
                OutlinedButton(
                    onClick = { isAddingNewAccount = true },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Connect Another Social Account", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Edit Account Dialog
    if (editingAccount != null) {
        val account = editingAccount!!
        AccountEditDialog(
            account = account,
            onDismiss = { editingAccount = null },
            onSave = { updatedAccount ->
                viewModel.saveOrUpdateAccount(updatedAccount)
                editingAccount = null
            }
        )
    }

    // Add New Channel Dialog
    if (isAddingNewAccount) {
        AccountAddDialog(
            onDismiss = { isAddingNewAccount = false },
            onSave = { newAccount ->
                viewModel.saveOrUpdateAccount(newAccount)
                isAddingNewAccount = false
            }
        )
    }

    // Disconnect All Confirmation Dialog
    if (showDisconnectAllDialog) {
        AlertDialog(
            onDismissRequest = { showDisconnectAllDialog = false },
            icon = { Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = ErrorRed) },
            title = { Text("Disconnect All Channels?", fontWeight = FontWeight.Bold) },
            text = { Text("This will mark all connected demo accounts as disconnected. You can reconnect or configure your real accounts at any time.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.disconnectAllAccounts()
                        showDisconnectAllDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Disconnect All")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDisconnectAllDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ConnectedAccountCard(
    account: SocialAccount,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onToggleConnection: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                when (account.platform) {
                                    SocialPlatform.INSTAGRAM -> Brush.linearGradient(listOf(InstagramPurple, InstagramPink, InstagramOrange))
                                    SocialPlatform.FACEBOOK -> Brush.linearGradient(listOf(FacebookBlue, Color(0xFF4267B2)))
                                    SocialPlatform.LINKEDIN -> Brush.linearGradient(listOf(LinkedInBlue, Color(0xFF004182)))
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = account.accountName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = account.accountName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        Text(
                            text = account.handle,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlatformBadge(platform = account.platform, size = 10)
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = onEditClick, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Account", tint = BrandPrimary, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Account", tint = ErrorRed, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Metrics Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (account.followersCount >= 1000) "${account.followersCount / 1000}k" else "${account.followersCount}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text("Followers", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${account.engagementRate}%", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BrandPrimary)
                    Text("Engagement", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${account.postsCount}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text("Total Posts", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Permissions list
            Text("Active Permissions:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            account.permissions.forEach { perm ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(perm, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Connection Toggle & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (account.isConnected) SuccessGreen else ErrorRed)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (account.isConnected) "Connected (Active)" else "Disconnected",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (account.isConnected) SuccessGreen else ErrorRed
                    )
                }

                Button(
                    onClick = onToggleConnection,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (account.isConnected) MaterialTheme.colorScheme.surfaceVariant else BrandPrimary,
                        contentColor = if (account.isConnected) MaterialTheme.colorScheme.onSurfaceVariant else Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (account.isConnected) Icons.Default.LinkOff else Icons.Default.Link,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (account.isConnected) "Disconnect" else "Connect Account",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun AccountEditDialog(
    account: SocialAccount,
    onDismiss: () -> Unit,
    onSave: (SocialAccount) -> Unit
) {
    var accountName by remember { mutableStateOf(account.accountName) }
    var handle by remember { mutableStateOf(account.handle) }
    var followersStr by remember { mutableStateOf(account.followersCount.toString()) }
    var isConnected by remember { mutableStateOf(account.isConnected) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PlatformBadge(platform = account.platform, size = 11)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Edit Account Details", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Update this channel with your real name, username handle, and follower count.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = accountName,
                    onValueChange = { accountName = it },
                    label = { Text("Account / Page Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = handle,
                    onValueChange = { handle = it },
                    label = { Text("Handle / Username (e.g. @yourbrand)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = followersStr,
                    onValueChange = { followersStr = it },
                    label = { Text("Followers Count") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val followers = followersStr.toLongOrNull() ?: account.followersCount
                    onSave(
                        account.copy(
                            accountName = accountName.ifBlank { account.accountName },
                            handle = handle.ifBlank { account.handle },
                            followersCount = followers,
                            isConnected = isConnected
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun AccountAddDialog(
    onDismiss: () -> Unit,
    onSave: (SocialAccount) -> Unit
) {
    var selectedPlatform by remember { mutableStateOf(SocialPlatform.INSTAGRAM) }
    var accountName by remember { mutableStateOf("") }
    var handle by remember { mutableStateOf("") }
    var followersStr by remember { mutableStateOf("1000") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Connect New Social Channel", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Select your platform and enter your profile information:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Platform selector chips
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SocialPlatform.entries.forEach { platform ->
                        FilterChip(
                            selected = selectedPlatform == platform,
                            onClick = { selectedPlatform = platform },
                            label = { Text(platform.displayName, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = accountName,
                    onValueChange = { accountName = it },
                    label = { Text("Profile / Brand Name") },
                    placeholder = { Text("e.g. My Personal Brand") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = handle,
                    onValueChange = { handle = it },
                    label = { Text("Handle / Username") },
                    placeholder = { Text("e.g. @muneebzee") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = followersStr,
                    onValueChange = { followersStr = it },
                    label = { Text("Current Followers") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val followers = followersStr.toLongOrNull() ?: 0L
                    val finalName = accountName.ifBlank { "${selectedPlatform.displayName} Profile" }
                    val finalHandle = handle.ifBlank { "@${finalName.lowercase().replace(" ", "_")}" }
                    val newAcc = SocialAccount(
                        id = UUID.randomUUID().toString(),
                        platform = selectedPlatform,
                        accountName = finalName,
                        handle = if (finalHandle.startsWith("@")) finalHandle else "@$finalHandle",
                        profileImageUrl = "",
                        followersCount = followers,
                        engagementRate = 4.2f,
                        postsCount = 0,
                        isConnected = true,
                        lastSyncTime = System.currentTimeMillis(),
                        permissions = listOf("Read Analytics", "Publish Content", "Direct Messaging")
                    )
                    onSave(newAcc)
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
            ) {
                Text("Connect & Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

