package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Expand
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.AiActionType
import com.example.core.model.ContentGoal
import com.example.core.model.ContentTone
import com.example.core.model.PostItem
import com.example.core.model.PostPlatformContent
import com.example.core.model.PostStatus
import com.example.core.model.SocialPlatform
import com.example.ui.components.AiGradientButton
import com.example.ui.components.PlatformBadge
import com.example.ui.components.RealisticPostPreview
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.LinkedInBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    modifier: Modifier = Modifier
) {
    var coreTopic by remember { mutableStateOf("") }
    var selectedGoal by remember { mutableStateOf(ContentGoal.AWARENESS) }
    var selectedTone by remember { mutableStateOf(ContentTone.PROFESSIONAL) }
    val isGenerating by viewModel.isAiGenerating.collectAsStateWithLifecycle()
    val brandProfile by viewModel.brandProfile.collectAsStateWithLifecycle()

    var activePlatformTab by remember { mutableIntStateOf(0) }
    val platforms = listOf(SocialPlatform.INSTAGRAM, SocialPlatform.FACEBOOK, SocialPlatform.LINKEDIN)

    // Current working post state
    var workingPost by remember {
        mutableStateOf(
            PostItem(
                platforms = platforms,
                topic = "",
                primaryGoal = selectedGoal,
                tone = selectedTone,
                status = PostStatus.DRAFT
            )
        )
    }

    var isPreviewMode by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("create_post_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Create Everywhere", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("AI Cross-Platform Post Architect", style = MaterialTheme.typography.labelSmall, color = BrandPrimary)
                    }
                },
                actions = {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isPreviewMode) BrandPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { isPreviewMode = !isPreviewMode }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isPreviewMode) "Edit Mode" else "Preview",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPreviewMode) BrandPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Topic & Single Idea Input Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "1. Enter Core Concept or Idea",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = coreTopic,
                            onValueChange = { coreTopic = it },
                            placeholder = { Text("e.g., Announcing our new AI analytics feature that cuts reporting time in half...", fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("core_topic_input"),
                            shape = RoundedCornerShape(12.dp),
                            minLines = 2,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Goal & Tone selectors
                        Text("Campaign Goal & Tone:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(6.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ContentGoal.entries) { goal ->
                                FilterChip(
                                    selected = selectedGoal == goal,
                                    onClick = { selectedGoal = goal },
                                    label = { Text(goal.label, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BrandPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ContentTone.entries.take(6)) { tone ->
                                FilterChip(
                                    selected = selectedTone == tone,
                                    onClick = { selectedTone = tone },
                                    label = { Text(tone.label, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BrandSecondary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        AiGradientButton(
                            text = "Generate Everywhere with AI",
                            onClick = {
                                if (coreTopic.isNotBlank()) {
                                    viewModel.generateMultiPlatformPost(
                                        topic = coreTopic,
                                        goal = selectedGoal,
                                        tone = selectedTone,
                                        platforms = platforms,
                                        onSuccess = { generated ->
                                            workingPost = generated
                                        }
                                    )
                                }
                            },
                            isLoading = isGenerating,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // 2. Platform Tabs (Instagram, Facebook, LinkedIn)
            item {
                Column {
                    ScrollableTabRow(
                        selectedTabIndex = activePlatformTab,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = BrandPrimary,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[activePlatformTab]),
                                color = when (activePlatformTab) {
                                    0 -> InstagramPink
                                    1 -> FacebookBlue
                                    else -> LinkedInBlue
                                }
                            )
                        },
                        edgePadding = 0.dp
                    ) {
                        platforms.forEachIndexed { index, platform ->
                            Tab(
                                selected = activePlatformTab == index,
                                onClick = { activePlatformTab = index },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (platform) {
                                                        SocialPlatform.INSTAGRAM -> InstagramPink
                                                        SocialPlatform.FACEBOOK -> FacebookBlue
                                                        SocialPlatform.LINKEDIN -> LinkedInBlue
                                                    }
                                                )
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(platform.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // 3. Platform Editor / Preview
            val currentPlatform = platforms[activePlatformTab]
            val currentContent = workingPost.getContentForPlatform(currentPlatform)

            if (isPreviewMode) {
                item {
                    RealisticPostPreview(
                        platform = currentPlatform,
                        accountName = when (currentPlatform) {
                            SocialPlatform.INSTAGRAM -> "Pulse Creative Studio"
                            SocialPlatform.FACEBOOK -> "Pulse AI Global"
                            SocialPlatform.LINKEDIN -> "Pulse Studio Innovations"
                        },
                        handle = when (currentPlatform) {
                            SocialPlatform.INSTAGRAM -> "@pulse_creative_ai"
                            SocialPlatform.FACEBOOK -> "PulseAIGlobal"
                            SocialPlatform.LINKEDIN -> "company/pulse-studio-ai"
                        },
                        content = currentContent
                    )
                }
            } else {
                // Platform Editor Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header info
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${currentPlatform.displayName} Tailored Content",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val charCount = (currentContent?.hook?.length ?: 0) + (currentContent?.body?.length ?: 0) + (currentContent?.callToAction?.length ?: 0)
                                Text(
                                    text = "$charCount / ${currentPlatform.maxCaptionLength} chars",
                                    fontSize = 11.sp,
                                    color = if (charCount > currentPlatform.maxCaptionLength) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Hook Editor
                            Text("Hook / Headline:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = currentContent?.hook ?: "",
                                onValueChange = { newHook ->
                                    val updated = (currentContent ?: PostPlatformContent(currentPlatform, "", "", "")).copy(hook = newHook)
                                    workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                },
                                modifier = Modifier.fillMaxWidth().testTag("hook_field_${currentPlatform.name.lowercase()}"),
                                shape = RoundedCornerShape(10.dp),
                                maxLines = 3,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandPrimary
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Body Editor
                            Text("Main Body / Copy:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = currentContent?.body ?: "",
                                onValueChange = { newBody ->
                                    val updated = (currentContent ?: PostPlatformContent(currentPlatform, "", "", "")).copy(body = newBody)
                                    workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                },
                                modifier = Modifier.fillMaxWidth().testTag("body_field_${currentPlatform.name.lowercase()}"),
                                shape = RoundedCornerShape(10.dp),
                                minLines = 4,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandPrimary
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // CTA Editor
                            Text("Call to Action (CTA):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = currentContent?.callToAction ?: "",
                                onValueChange = { newCta ->
                                    val updated = (currentContent ?: PostPlatformContent(currentPlatform, "", "", "")).copy(callToAction = newCta)
                                    workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                },
                                modifier = Modifier.fillMaxWidth().testTag("cta_field_${currentPlatform.name.lowercase()}"),
                                shape = RoundedCornerShape(10.dp),
                                maxLines = 2,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandPrimary
                                )
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // AI Polish & Quick Action Toolbar
                            Text("AI Quick Refine Tools:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BrandPrimary)
                            Spacer(modifier = Modifier.height(8.dp))

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    AiToolChip(label = "Improve Hook", icon = Icons.Default.AutoAwesome) {
                                        if (currentContent != null) {
                                            viewModel.rewritePlatformContent(currentPlatform, AiActionType.IMPROVE_HOOK, currentContent) { rewritten ->
                                                val updated = currentContent.copy(hook = rewritten)
                                                workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                            }
                                        }
                                    }
                                }
                                item {
                                    AiToolChip(label = "Make Professional", icon = Icons.Default.Work) {
                                        if (currentContent != null) {
                                            viewModel.rewritePlatformContent(currentPlatform, AiActionType.MAKE_PROFESSIONAL, currentContent) { rewritten ->
                                                val updated = currentContent.copy(body = rewritten)
                                                workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                            }
                                        }
                                    }
                                }
                                item {
                                    AiToolChip(label = "Make Engaging", icon = Icons.Default.VolumeUp) {
                                        if (currentContent != null) {
                                            viewModel.rewritePlatformContent(currentPlatform, AiActionType.MAKE_ENGAGING, currentContent) { rewritten ->
                                                val updated = currentContent.copy(body = rewritten)
                                                workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                            }
                                        }
                                    }
                                }
                                item {
                                    AiToolChip(label = "Shorten", icon = Icons.Default.Compress) {
                                        if (currentContent != null) {
                                            viewModel.rewritePlatformContent(currentPlatform, AiActionType.SHORTEN, currentContent) { rewritten ->
                                                val updated = currentContent.copy(body = rewritten)
                                                workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                            }
                                        }
                                    }
                                }
                                item {
                                    AiToolChip(label = "Expand", icon = Icons.Default.Expand) {
                                        if (currentContent != null) {
                                            viewModel.rewritePlatformContent(currentPlatform, AiActionType.EXPAND, currentContent) { rewritten ->
                                                val updated = currentContent.copy(body = rewritten)
                                                workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                            }
                                        }
                                    }
                                }
                                item {
                                    AiToolChip(label = "Generate CTA", icon = Icons.Default.Tag) {
                                        if (currentContent != null) {
                                            viewModel.rewritePlatformContent(currentPlatform, AiActionType.GENERATE_CTA, currentContent) { rewritten ->
                                                val updated = currentContent.copy(callToAction = rewritten)
                                                workingPost = updatePostPlatformContent(workingPost, currentPlatform, updated)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Action Buttons (Publish Now, Schedule, Save Draft)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.publishNow(workingPost.copy(topic = coreTopic.ifBlank { "Social Post" }))
                            onNavigateBack()
                        },
                        modifier = Modifier.weight(1f).testTag("publish_post_now_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Publish Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val scheduledTime = System.currentTimeMillis() + (3 * 60 * 60 * 1000L) // Scheduled 3 hours from now
                            viewModel.savePost(workingPost.copy(topic = coreTopic.ifBlank { "Social Post" }), isScheduled = true, scheduledTime = scheduledTime)
                            onNavigateToCalendar()
                        },
                        modifier = Modifier.weight(1f).testTag("schedule_post_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Schedule", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.savePost(workingPost.copy(topic = coreTopic.ifBlank { "Social Post" }), isScheduled = false)
                            onNavigateBack()
                        },
                        modifier = Modifier.weight(1f).testTag("save_draft_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Draft", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AiToolChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(BrandPrimary.copy(alpha = 0.12f))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrandPrimary)
        }
    }
}

private fun updatePostPlatformContent(post: PostItem, platform: SocialPlatform, content: PostPlatformContent): PostItem {
    return when (platform) {
        SocialPlatform.INSTAGRAM -> post.copy(instagramContent = content)
        SocialPlatform.FACEBOOK -> post.copy(facebookContent = content)
        SocialPlatform.LINKEDIN -> post.copy(linkedinContent = content)
    }
}
