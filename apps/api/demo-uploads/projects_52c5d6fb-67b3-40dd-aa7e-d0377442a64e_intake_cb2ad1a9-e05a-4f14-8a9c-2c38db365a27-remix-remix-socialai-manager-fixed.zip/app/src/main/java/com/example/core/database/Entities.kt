package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.core.model.ContentGoal
import com.example.core.model.ContentTone
import com.example.core.model.PostPlatformContent
import com.example.core.model.PostStatus
import com.example.core.model.SocialPlatform

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val campaignId: String? = null,
    val platforms: List<SocialPlatform>,
    val topic: String,
    val primaryGoal: ContentGoal,
    val tone: ContentTone,
    val instagramContent: PostPlatformContent? = null,
    val facebookContent: PostPlatformContent? = null,
    val linkedinContent: PostPlatformContent? = null,
    val attachedMediaUrls: List<String> = emptyList(),
    val status: PostStatus = PostStatus.DRAFT,
    val scheduledTimestamp: Long? = null,
    val publishedTimestamp: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val publishError: String? = null,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isFavorite: Boolean = false
)

@Entity(tableName = "social_accounts")
data class SocialAccountEntity(
    @PrimaryKey val id: String,
    val platform: SocialPlatform,
    val accountName: String,
    val handle: String,
    val profileImageUrl: String = "",
    val isConnected: Boolean = true,
    val isMock: Boolean = false,
    val followersCount: Long = 0L,
    val followingCount: Long = 0L,
    val postsCount: Int = 0,
    val engagementRate: Float = 0f,
    val lastSyncTime: Long = System.currentTimeMillis(),
    val permissions: List<String> = emptyList(),
    val tokenExpiresAt: Long = System.currentTimeMillis() + (60L * 24 * 60 * 60 * 1000)
)

@Entity(tableName = "brand_profile")
data class BrandProfileEntity(
    @PrimaryKey val id: String = "default_brand",
    val brandName: String = "Pulse Studio",
    val tagline: String = "Modern Creative Tech & Growth Agency",
    val industry: String = "Digital Marketing & AI Tech",
    val audience: String = "Founders, marketing directors, and creative entrepreneurs",
    val defaultTone: ContentTone = ContentTone.PROFESSIONAL,
    val companyDescription: String = "We build high-growth AI digital products and empower modern brands to scale their social footprint.",
    val productsServices: String = "Social media automation, AI marketing strategy, design consultancy",
    val wordsToUse: List<String> = listOf("impactful", "growth", "strategy", "streamlined", "next-gen"),
    val wordsToAvoid: List<String> = listOf("cheap", "revolutionary gimmick", "guaranteed overnight", "easy cash"),
    val callToActionPreference: String = "Join the conversation or visit our website to explore more."
)

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey val id: String,
    val title: String,
    val objective: ContentGoal,
    val startDate: Long,
    val endDate: Long,
    val targetPlatforms: List<SocialPlatform>,
    val targetAudience: String,
    val description: String,
    val totalPostsPlanned: Int = 7,
    val postsPublished: Int = 0,
    val budgetNote: String = "",
    val status: String = "ACTIVE"
)

@Entity(tableName = "content_templates")
data class ContentTemplateEntity(
    @PrimaryKey val id: String,
    val platform: SocialPlatform,
    val title: String,
    val description: String,
    val hookTemplate: String,
    val bodyTemplate: String,
    val ctaTemplate: String,
    val defaultHashtags: List<String> = emptyList(),
    val category: String = "General"
)

@Entity(tableName = "analytics_snapshots")
data class AnalyticsSnapshotEntity(
    @PrimaryKey val id: String,
    val platform: SocialPlatform,
    val dateTimestamp: Long,
    val impressions: Long,
    val reach: Long,
    val followers: Long,
    val followerChange: Long,
    val likes: Long,
    val comments: Long,
    val shares: Long,
    val saves: Long,
    val clicks: Long,
    val engagementRate: Float,
    val topPostId: String? = null
)

@Entity(tableName = "automation_rules")
data class AutomationRuleEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val isEnabled: Boolean = true,
    val triggerType: String,
    val actionType: String
)

@Entity(tableName = "app_notifications")
data class AppNotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val platform: SocialPlatform? = null,
    val isRead: Boolean = false,
    val actionRoute: String? = null
)
