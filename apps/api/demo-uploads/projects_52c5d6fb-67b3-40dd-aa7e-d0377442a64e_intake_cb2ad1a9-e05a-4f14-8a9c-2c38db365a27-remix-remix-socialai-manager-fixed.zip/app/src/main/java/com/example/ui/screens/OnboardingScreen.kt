package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.BrandProfile
import com.example.core.model.ContentTone
import com.example.core.model.SocialPlatform
import com.example.ui.components.PlatformBadge
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.LinkedInBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AppViewModel

@Composable
fun OnboardingScreen(
    viewModel: AppViewModel,
    onFinishOnboarding: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentStep by remember { mutableIntStateOf(0) }

    var brandName by remember { mutableStateOf("Pulse Creative Studio") }
    var industry by remember { mutableStateOf("Design & Tech Agency") }
    var audience by remember { mutableStateOf("Founders, Product Leaders, & Creators") }
    var selectedTone by remember { mutableStateOf(ContentTone.INSPIRATIONAL) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("onboarding_screen")
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Step Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                (0..3).forEach { stepIndex ->
                    Box(
                        modifier = Modifier
                            .height(6.dp)
                            .width(if (stepIndex == currentStep) 36.dp else 12.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (stepIndex <= currentStep) BrandPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    )
                    if (stepIndex < 3) Spacer(modifier = Modifier.width(6.dp))
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Step Content
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "onboarding_steps",
                modifier = Modifier.weight(1f)
            ) { step ->
                when (step) {
                    0 -> OnboardingStepWelcome()
                    1 -> OnboardingStepBrand(
                        brandName = brandName,
                        onBrandNameChange = { brandName = it },
                        industry = industry,
                        onIndustryChange = { industry = it },
                        audience = audience,
                        onAudienceChange = { audience = it }
                    )
                    2 -> OnboardingStepTone(
                        selectedTone = selectedTone,
                        onToneSelect = { selectedTone = it }
                    )
                    3 -> OnboardingStepChannels()
                    else -> OnboardingStepWelcome()
                }
            }

            // Bottom Navigation Buttons
            Column(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        if (currentStep < 3) {
                            currentStep++
                        } else {
                            viewModel.updateBrandProfile(
                                BrandProfile(
                                    brandName = brandName,
                                    industry = industry,
                                    audience = audience,
                                    defaultTone = selectedTone
                                )
                            )
                            onFinishOnboarding()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("onboarding_next_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (currentStep == 3) "Launch Dashboard" else "Continue",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = if (currentStep == 3) Icons.Default.RocketLaunch else Icons.Default.ChevronRight,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (currentStep > 0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = { currentStep-- },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Back", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun OnboardingStepWelcome() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(BrandPrimary, BrandSecondary))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(46.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Welcome to SocialAI Manager",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Your AI strategist for Instagram, Facebook, and LinkedIn. Create tailored posts, schedule campaigns, and grow with data-driven insights.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PlatformBadge(platform = SocialPlatform.INSTAGRAM, size = 12)
            PlatformBadge(platform = SocialPlatform.FACEBOOK, size = 12)
            PlatformBadge(platform = SocialPlatform.LINKEDIN, size = 12)
        }
    }
}

@Composable
private fun OnboardingStepBrand(
    brandName: String,
    onBrandNameChange: (String) -> Unit,
    industry: String,
    onIndustryChange: (String) -> Unit,
    audience: String,
    onAudienceChange: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Tell Us About Your Brand", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Text("SocialAI uses this context for tone memory & custom hooks.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(20.dp))

        Text("Brand / Company Name", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = brandName,
            onValueChange = onBrandNameChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text("Industry / Niche", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = industry,
            onValueChange = onIndustryChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text("Target Audience Persona", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = audience,
            onValueChange = onAudienceChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            minLines = 2
        )
    }
}

@Composable
private fun OnboardingStepTone(
    selectedTone: ContentTone,
    onToneSelect: (ContentTone) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Select Your Primary Voice", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Choose the primary tone for your generated captions.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(20.dp))

        ContentTone.entries.chunked(2).forEach { rowTones ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowTones.forEach { tone ->
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onToneSelect(tone) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedTone == tone) BrandPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (selectedTone == tone) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(BrandPrimary, BrandSecondary))) else null
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tone.label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (selectedTone == tone) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OnboardingStepChannels() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Connected Channels Ready", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Text("All three social channels are pre-configured with active API tokens.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(20.dp))

        listOf(
            Triple(SocialPlatform.INSTAGRAM, "Instagram Business", "Reels, Carousels, & Stories"),
            Triple(SocialPlatform.FACEBOOK, "Facebook Page", "Community posts & Discussions"),
            Triple(SocialPlatform.LINKEDIN, "LinkedIn Company Page", "B2B Thought Leadership & Articles")
        ).forEach { (platform, name, desc) ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlatformBadge(platform = platform, size = 11)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SuccessGreen.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Connected", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                    }
                }
            }
        }
    }
}
