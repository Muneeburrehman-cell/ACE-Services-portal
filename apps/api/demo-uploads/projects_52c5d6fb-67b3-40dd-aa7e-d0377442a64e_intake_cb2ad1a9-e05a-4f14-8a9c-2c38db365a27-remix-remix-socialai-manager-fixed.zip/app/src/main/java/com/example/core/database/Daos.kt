package com.example.core.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.core.model.PostStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun getAllPosts(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE status = :status ORDER BY scheduledTimestamp ASC")
    fun getPostsByStatus(status: PostStatus): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE scheduledTimestamp IS NOT NULL AND status = 'SCHEDULED' ORDER BY scheduledTimestamp ASC")
    fun getScheduledPosts(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE campaignId = :campaignId ORDER BY createdAt ASC")
    fun getPostsForCampaign(campaignId: String): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavoritePosts(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE id = :id")
    suspend fun getPostById(id: String): PostEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<PostEntity>)

    @Update
    suspend fun updatePost(post: PostEntity)

    @Delete
    suspend fun deletePost(post: PostEntity)

    @Query("DELETE FROM posts WHERE id = :id")
    suspend fun deletePostById(id: String)
}

@Dao
interface SocialAccountDao {
    @Query("SELECT * FROM social_accounts")
    fun getAllAccounts(): Flow<List<SocialAccountEntity>>

    @Query("SELECT * FROM social_accounts WHERE isConnected = 1")
    fun getConnectedAccounts(): Flow<List<SocialAccountEntity>>

    @Query("SELECT * FROM social_accounts WHERE platform = :platformName LIMIT 1")
    suspend fun getAccountByPlatform(platformName: String): SocialAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: SocialAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<SocialAccountEntity>)

    @Update
    suspend fun updateAccount(account: SocialAccountEntity)

    @Delete
    suspend fun deleteAccount(account: SocialAccountEntity)
}

@Dao
interface BrandProfileDao {
    @Query("SELECT * FROM brand_profile WHERE id = 'default_brand' LIMIT 1")
    fun getBrandProfile(): Flow<BrandProfileEntity?>

    @Query("SELECT * FROM brand_profile WHERE id = 'default_brand' LIMIT 1")
    suspend fun getBrandProfileSync(): BrandProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: BrandProfileEntity)
}

@Dao
interface CampaignDao {
    @Query("SELECT * FROM campaigns ORDER BY startDate DESC")
    fun getAllCampaigns(): Flow<List<CampaignEntity>>

    @Query("SELECT * FROM campaigns WHERE id = :id")
    suspend fun getCampaignById(id: String): CampaignEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaign(campaign: CampaignEntity)

    @Update
    suspend fun updateCampaign(campaign: CampaignEntity)

    @Delete
    suspend fun deleteCampaign(campaign: CampaignEntity)
}

@Dao
interface ContentTemplateDao {
    @Query("SELECT * FROM content_templates ORDER BY category ASC")
    fun getAllTemplates(): Flow<List<ContentTemplateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplates(templates: List<ContentTemplateEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: ContentTemplateEntity)

    @Delete
    suspend fun deleteTemplate(template: ContentTemplateEntity)
}

@Dao
interface AnalyticsDao {
    @Query("SELECT * FROM analytics_snapshots ORDER BY dateTimestamp DESC")
    fun getAllSnapshots(): Flow<List<AnalyticsSnapshotEntity>>

    @Query("SELECT * FROM analytics_snapshots WHERE platform = :platformName ORDER BY dateTimestamp DESC")
    fun getSnapshotsForPlatform(platformName: String): Flow<List<AnalyticsSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshots(snapshots: List<AnalyticsSnapshotEntity>)
}

@Dao
interface AppNotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<AppNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotificationEntity)

    @Query("UPDATE app_notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("DELETE FROM app_notifications")
    suspend fun clearAll()
}

@Dao
interface AutomationRuleDao {
    @Query("SELECT * FROM automation_rules")
    fun getAllRules(): Flow<List<AutomationRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRules(rules: List<AutomationRuleEntity>)

    @Update
    suspend fun updateRule(rule: AutomationRuleEntity)
}
