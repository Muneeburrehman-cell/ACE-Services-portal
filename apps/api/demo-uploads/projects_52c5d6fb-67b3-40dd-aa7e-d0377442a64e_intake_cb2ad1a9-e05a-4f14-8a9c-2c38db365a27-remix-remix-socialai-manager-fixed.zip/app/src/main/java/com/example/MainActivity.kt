package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.AiCommandCenterScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.BrandVoiceScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.CampaignsScreen
import com.example.ui.screens.ConnectedAccountsScreen
import com.example.ui.screens.ContentLibraryScreen
import com.example.ui.screens.CreatePostScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.SocialAiTheme
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.launch

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard)
    object AiCommand : Screen("ai_command", "AI Command", Icons.Filled.Psychology, Icons.Outlined.Psychology)
    object CreatePost : Screen("create_post", "Create", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object Calendar : Screen("calendar", "Calendar", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth)
    object Analytics : Screen("analytics", "Analytics", Icons.Filled.Analytics, Icons.Outlined.Analytics)

    // Secondary Drawer/Modal screens
    object BrandVoice : Screen("brand_voice", "Brand Voice", Icons.Filled.RecordVoiceOver, Icons.Filled.RecordVoiceOver)
    object ConnectedAccounts : Screen("accounts", "Accounts", Icons.Filled.Link, Icons.Filled.Link)
    object Campaigns : Screen("campaigns", "Campaigns", Icons.Filled.Campaign, Icons.Filled.Campaign)
    object Library : Screen("library", "Library", Icons.Filled.Folder, Icons.Filled.Folder)
    object Notifications : Screen("notifications", "Notifications", Icons.Filled.Notifications, Icons.Filled.Notifications)
    object Settings : Screen("settings", "Settings", Icons.Filled.Settings, Icons.Filled.Settings)
    object Onboarding : Screen("onboarding", "Onboarding", Icons.Filled.HelpOutline, Icons.Filled.HelpOutline)
}

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SocialAiTheme {
                MainAppContainer(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContainer(viewModel: AppViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val brandProfile by viewModel.brandProfile.collectAsStateWithLifecycle()

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    val bottomNavItems = listOf(
        Screen.Dashboard,
        Screen.AiCommand,
        Screen.CreatePost,
        Screen.Calendar,
        Screen.Analytics
    )

    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = showBottomBar,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(300.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(BrandPrimary, BrandSecondary))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("SocialAI Suite", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(brandProfile.brandName, fontSize = 12.sp, color = BrandPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(14.dp))

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = null) },
                        label = { Text("Brand Voice & Memory", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selected = currentRoute == Screen.BrandVoice.route,
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            navController.navigate(Screen.BrandVoice.route)
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Link, contentDescription = null) },
                        label = { Text("Connected Accounts", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selected = currentRoute == Screen.ConnectedAccounts.route,
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            navController.navigate(Screen.ConnectedAccounts.route)
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Campaign, contentDescription = null) },
                        label = { Text("Campaigns Hub", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selected = currentRoute == Screen.Campaigns.route,
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            navController.navigate(Screen.Campaigns.route)
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Folder, contentDescription = null) },
                        label = { Text("Content Library", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selected = currentRoute == Screen.Library.route,
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            navController.navigate(Screen.Library.route)
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Notifications, contentDescription = null) },
                        label = { Text("Activity & Alerts", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selected = currentRoute == Screen.Notifications.route,
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            navController.navigate(Screen.Notifications.route)
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Settings & Automation", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selected = currentRoute == Screen.Settings.route,
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            navController.navigate(Screen.Settings.route)
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    Spacer(modifier = Modifier.weight(1f))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Instagram • Facebook • LinkedIn",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomBar) {
                    Column {
                        HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline)
                        NavigationBar(
                            containerColor = Color(0xFFF3F4F9),
                            tonalElevation = 0.dp,
                            modifier = Modifier.testTag("bottom_nav_bar")
                        ) {
                            bottomNavItems.forEach { screen ->
                                val isSelected = currentRoute == screen.route
                                NavigationBarItem(
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                            contentDescription = screen.title
                                        )
                                    },
                                    label = { Text(screen.title, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                                    selected = isSelected,
                                    onClick = {
                                        if (currentRoute != screen.route) {
                                            navController.navigate(screen.route) {
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("nav_item_${screen.route}")
                                )
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            NavHost(
                navController = navController,
                startDestination = Screen.Dashboard.route,
                modifier = Modifier.padding(paddingValues)
            ) {
                composable(Screen.Dashboard.route) {
                    DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.CreatePost.route) },
                        onNavigateToAiCommand = { navController.navigate(Screen.AiCommand.route) },
                        onNavigateToCalendar = { navController.navigate(Screen.Calendar.route) },
                        onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) },
                        onNavigateToAccounts = { navController.navigate(Screen.ConnectedAccounts.route) },
                        onNavigateToNotifications = { navController.navigate(Screen.Notifications.route) }
                    )
                }

                composable(Screen.AiCommand.route) {
                    AiCommandCenterScreen(
                        viewModel = viewModel,
                        onNavigateToEditor = { navController.navigate(Screen.CreatePost.route) }
                    )
                }

                composable(Screen.CreatePost.route) {
                    CreatePostScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.navigate(Screen.Dashboard.route) },
                        onNavigateToCalendar = { navController.navigate(Screen.Calendar.route) }
                    )
                }

                composable(Screen.Calendar.route) {
                    CalendarScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.CreatePost.route) }
                    )
                }

                composable(Screen.Analytics.route) {
                    AnalyticsScreen(
                        viewModel = viewModel
                    )
                }

                composable(Screen.BrandVoice.route) {
                    BrandVoiceScreen(
                        viewModel = viewModel
                    )
                }

                composable(Screen.ConnectedAccounts.route) {
                    ConnectedAccountsScreen(
                        viewModel = viewModel
                    )
                }

                composable(Screen.Campaigns.route) {
                    CampaignsScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.CreatePost.route) }
                    )
                }

                composable(Screen.Library.route) {
                    ContentLibraryScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.CreatePost.route) }
                    )
                }

                composable(Screen.Notifications.route) {
                    NotificationsScreen(
                        viewModel = viewModel
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = viewModel,
                        onNavigateToBrandVoice = { navController.navigate(Screen.BrandVoice.route) },
                        onNavigateToAccounts = { navController.navigate(Screen.ConnectedAccounts.route) },
                        onNavigateToOnboarding = { navController.navigate(Screen.Onboarding.route) }
                    )
                }

                composable(Screen.Onboarding.route) {
                    OnboardingScreen(
                        viewModel = viewModel,
                        onFinishOnboarding = { navController.navigate(Screen.Dashboard.route) }
                    )
                }
            }
        }
    }
}
