package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.SocialPlatform
import com.example.ui.components.MetricCard
import com.example.ui.components.PlatformBadge
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.BrandTertiary
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.LinkedInBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.analyticsSummary.collectAsStateWithLifecycle()
    val weeklyReport by viewModel.weeklyReport.collectAsStateWithLifecycle()
    val posts by viewModel.posts.collectAsStateWithLifecycle()

    var selectedPlatformFilter by remember { mutableIntStateOf(0) }
    val platformTabs = listOf("All Channels", "Instagram", "Facebook", "LinkedIn")

    var showWeeklyReportDialog by remember { mutableStateOf(false) }
    var userAiQuestion by remember { mutableStateOf("") }
    var aiAnswer by remember { mutableStateOf<String?>(null) }
    var isThinking by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("analytics_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Analytics & Insights", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Cross-Platform Intelligence", style = MaterialTheme.typography.labelSmall, color = BrandPrimary)
                    }
                },
                actions = {
                    Button(
                        onClick = { showWeeklyReportDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("view_ai_report_button")
                    ) {
                        Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("AI Report", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Channel Filter Tabs
            item {
                ScrollableTabRow(
                    selectedTabIndex = selectedPlatformFilter,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = BrandPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedPlatformFilter]),
                            color = BrandPrimary
                        )
                    },
                    edgePadding = 0.dp
                ) {
                    platformTabs.forEachIndexed { index, name ->
                        Tab(
                            selected = selectedPlatformFilter == index,
                            onClick = { selectedPlatformFilter = index },
                            text = { Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        )
                    }
                }
            }

            // 2. High-level metric cards
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = "Total Reach",
                            value = "142.5k",
                            changeText = "+24.8%",
                            isPositive = true,
                            icon = Icons.Default.Visibility,
                            accentColor = BrandTertiary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Audience Size",
                            value = "${(summary?.totalFollowers ?: 84950L) / 1000}k",
                            changeText = "+1,284",
                            isPositive = true,
                            icon = Icons.Default.Group,
                            accentColor = LinkedInBlue,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = "Engagement",
                            value = "${String.format("%.1f", summary?.totalEngagementRate ?: 4.7f)}%",
                            changeText = "+18.4%",
                            isPositive = true,
                            icon = Icons.Default.TrendingUp,
                            accentColor = BrandPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Top Channel",
                            value = "LinkedIn",
                            changeText = "6.1% rate",
                            isPositive = true,
                            icon = Icons.Default.WorkspacePremium,
                            accentColor = SuccessGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 3. Platform Breakdown Progress / Cards
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Channel Performance Comparison",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        PlatformPerformanceRow(
                            platform = SocialPlatform.LINKEDIN,
                            followers = "${summary?.linkedinFollowers ?: 18900} followers",
                            engagement = "6.1% Engagement",
                            badgeText = "Highest Converting",
                            accentColor = LinkedInBlue
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PlatformPerformanceRow(
                            platform = SocialPlatform.INSTAGRAM,
                            followers = "${summary?.instagramFollowers ?: 24850} followers",
                            engagement = "4.8% Engagement",
                            badgeText = "Top Viral Reach",
                            accentColor = InstagramPink
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PlatformPerformanceRow(
                            platform = SocialPlatform.FACEBOOK,
                            followers = "${summary?.facebookFollowers ?: 41200} followers",
                            engagement = "3.2% Engagement",
                            badgeText = "Largest Community",
                            accentColor = FacebookBlue
                        )
                    }
                }
            }

            // 4. "Ask AI About My Analytics" Conversational Analyst
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandPrimary.copy(alpha = 0.08f)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(BrandPrimary, BrandSecondary)))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ask AI About Your Social Analytics", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Ask questions like 'Why did our engagement drop on Facebook?' or 'What topic performs best on LinkedIn?'",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = userAiQuestion,
                            onValueChange = { userAiQuestion = it },
                            placeholder = { Text("Ask your analytics question...", fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            trailingIcon = {
                                IconButton(
                                    onClick = {
                                        if (userAiQuestion.isNotBlank()) {
                                            isThinking = true
                                            val q = userAiQuestion.lowercase()
                                            aiAnswer = when {
                                                q.contains("linkedin") -> "LinkedIn is your highest-leverage channel right now with a 6.1% engagement rate. Your multi-point tactical frameworks generate 3.8x more comments than standard text posts."
                                                q.contains("facebook") -> "Facebook reach is prioritizing community discussions. When you ask open-ended questions with single-image previews, comments increase by 42%."
                                                q.contains("instagram") -> "On Instagram, 5-slide educational carousels have the highest save rate (142 saves/post), while Reels generate 85% of your new non-follower discovery."
                                                else -> "Across all 3 channels, actionable educational content and behind-the-scenes building are outperforming promotional sales pitches by 2.4x. Focus your content mix on 70% value, 20% culture, and 10% direct conversion."
                                            }
                                            isThinking = false
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Ask", tint = BrandPrimary)
                                }
                            }
                        )

                        if (aiAnswer != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.Top) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = aiAnswer!!, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 18.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 5. Top Performing Posts Table
            item {
                Column {
                    Text("Top Performing Content", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.height(10.dp))

                    posts.take(4).forEach { post ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        post.platforms.forEach { PlatformBadge(platform = it, size = 9) }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(post.topic, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("${post.likesCount}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("${post.commentsCount}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // AI Weekly Performance Report Modal
    if (showWeeklyReportDialog && weeklyReport != null) {
        val report = weeklyReport!!
        AlertDialog(
            onDismissRequest = { showWeeklyReportDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = BrandPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(report.title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Text(report.summary, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 18.sp)
                    }
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Key Highlights", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BrandPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("• Net Follower Growth: +${report.followerGrowthCount}", fontSize = 12.sp)
                                Text("• Engagement Growth: +${report.engagementGrowthPct}%", fontSize = 12.sp)
                                Text("• Top Post: ${report.topPerformingPostTopic}", fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Text("Recommended Action Plan for Next Week:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        report.nextWeekActionPlan.forEach { action ->
                            Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                Text("• ", color = BrandPrimary, fontWeight = FontWeight.Bold)
                                Text(action, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showWeeklyReportDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
                ) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
private fun PlatformPerformanceRow(
    platform: SocialPlatform,
    followers: String,
    engagement: String,
    badgeText: String,
    accentColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(accentColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(platform.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(followers, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(engagement, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = accentColor)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(accentColor.copy(alpha = 0.12f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(badgeText, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = accentColor)
            }
        }
    }
}
