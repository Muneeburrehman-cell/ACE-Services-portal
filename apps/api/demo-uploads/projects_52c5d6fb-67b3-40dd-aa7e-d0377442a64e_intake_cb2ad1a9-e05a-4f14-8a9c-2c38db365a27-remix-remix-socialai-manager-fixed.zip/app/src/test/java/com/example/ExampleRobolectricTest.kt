package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.ContentGoal
import com.example.core.model.ContentTone
import com.example.core.model.PostPlatformContent
import com.example.core.model.PostStatus
import com.example.core.model.SocialPlatform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SocialAI Manager", appName)
    }

    @Test
    fun `formatted content generates properly for Instagram`() {
        val igContent = PostPlatformContent(
            platform = SocialPlatform.INSTAGRAM,
            hook = "Boost your social strategy today!",
            body = "Here are 3 key tips to scale your content fast.",
            callToAction = "Save this post and follow for more.",
            hashtags = listOf("SocialAI", "MarketingTips")
        )
        val formatted = igContent.fullFormattedContent()
        assertTrue(formatted.contains("Boost your social strategy today!"))
        assertTrue(formatted.contains("Save this post and follow for more."))
        assertTrue(formatted.contains("#SocialAI #MarketingTips"))
    }

    @Test
    fun `platform character limits are verified`() {
        assertEquals(2200, SocialPlatform.INSTAGRAM.maxCaptionLength)
        assertEquals(63206, SocialPlatform.FACEBOOK.maxCaptionLength)
        assertEquals(3000, SocialPlatform.LINKEDIN.maxCaptionLength)
    }

    @Test
    fun `content goals and tones are properly defined`() {
        assertTrue(ContentGoal.entries.isNotEmpty())
        assertTrue(ContentTone.entries.isNotEmpty())
        assertEquals("Brand Awareness", ContentGoal.AWARENESS.label)
        assertEquals("Professional & Authoritative", ContentTone.PROFESSIONAL.label)
    }
}
