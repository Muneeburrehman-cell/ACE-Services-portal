# Production Readiness Package

This package hardens the portal for controlled business deployment. It includes:

- Draft -> received submission workflow requiring at least one intake file.
- Server-side engineer/project-type validation.
- Safer S3 upload confirmation with project/type binding and size validation.
- Atomic refresh-token rotation.
- Atomic client-delivery claim to prevent duplicate sends.
- Admin uniqueness/self-deactivation protections.
- Corrected PostgreSQL RLS policies.
- Strict WebSocket CORS.
- HTTPS enforcement in production.
- Production Dockerfiles and compose file.
- Delivery request DTO validation.

## Required before go-live

1. Generate strong production secrets and configure `apps/api/.env`.
2. Use a non-superuser PostgreSQL runtime account; never use `postgres` for the API.
3. Configure a private S3 bucket with least-privilege IAM and lifecycle/backup policies.
4. Configure malware scanning/quarantine for uploaded files.
5. Configure a real TLS reverse proxy/load balancer in front of web/API.
6. Configure SendGrid (or replace with your approved transactional email provider).
7. Run `npx prisma migrate deploy` against a staging database first.
8. Run API and web builds in CI from source.
9. Execute end-to-end tests for the full BD -> Admin -> Engineer -> Client delivery workflow.
10. Test database backup restore and S3 recovery.
11. Set up application logs, metrics, alerting, and error tracking.
12. Perform a penetration/security review before handling sensitive client files.

This is a hardened software package, not a substitute for infrastructure/security acceptance testing in the target production environment.
