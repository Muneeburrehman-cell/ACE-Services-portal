# Requirements Document

## Introduction

A web-based project management portal for a US-based construction estimation company operating two shifts. The night shift Business Development (BD) department cold-calls US clients and logs new projects. The day shift Engineering department (Estimation engineers and Design & Drafting engineers) completes and delivers the work. The Admin role is the sole hub through which all communication and project visibility flows. Employees are distributed across Pakistan and access the portal from any location via browser.

The defining constraint of the system is strict role isolation: no employee can see, contact, or be aware of any other employee. Every employee's only relationship is with Admin. This hub-and-spoke access model is enforced at the database and API level.

---

## Glossary

- **Portal**: The web-based project management application described in this document.
- **Admin**: The single superuser account with full visibility over all projects, users, and system actions.
- **BD_Agent**: A Business Development department employee who logs new client projects during the night shift.
- **Estimation_Engineer**: An engineering department employee who receives and completes cost estimation projects.
- **Design_Engineer**: An engineering department employee who receives and completes design and drafting projects.
- **Engineer**: A collective term referring to both Estimation_Engineer and Design_Engineer roles.
- **Project**: A unit of work submitted by a BD_Agent containing client details, scope, files, and a deadline.
- **Deliverable**: The completed output file(s) uploaded by an Engineer for a specific Project.
- **Assignment**: The Admin action of linking a Project to a specific Engineer with a deadline, priority, and instructions.
- **Status_Trail**: The ordered sequence of status values a Project passes through: `received → assigned → in_progress → delivered → sent_to_client`.
- **Chat_Thread**: A one-to-one message channel that exists exclusively between a single employee and Admin.
- **Signed_URL**: A time-limited, cryptographically signed URL granting temporary access to a specific file in secure storage.
- **Transactional_Email**: An automated email sent to a client by the system on Admin's explicit instruction.
- **2FA**: Two-factor authentication requiring a second verification step beyond username and password.
- **JWT**: JSON Web Token used to authenticate and authorise API requests.
- **Audit_Log**: An immutable, append-only record of every significant action performed in the system.
- **PWA**: Progressive Web App — a web application installable on a device and accessible offline for static assets.

---

## Requirements

### Requirement 1: User Authentication and Session Management

**User Story:** As any employee, I want to securely log in to the Portal with my credentials, so that I can access only the features and data my role permits.

#### Acceptance Criteria

1. THE Portal SHALL provide a login page accepting an email address and password.
2. WHEN a user submits valid credentials, THE Portal SHALL issue a signed JWT access token with a 15-minute expiry and a refresh token with a 7-day expiry.
3. WHEN a user submits invalid credentials, THE Portal SHALL return an error response and SHALL NOT issue any token.
4. WHEN the JWT access token expires, THE Portal SHALL use the refresh token to issue a new access token without requiring the user to re-enter credentials.
5. WHEN the refresh token expires or is revoked, THE Portal SHALL redirect the user to the login page.
6. WHEN an Admin user submits valid credentials, THE Portal SHALL require completion of a 2FA challenge using a time-based one-time password (TOTP) before granting access.
7. IF the Admin user fails the 2FA challenge three consecutive times, THEN THE Portal SHALL lock the Admin account for 30 minutes and send a notification email to the registered Admin address.
8. THE Portal SHALL enforce HTTPS for all connections and SHALL reject plain HTTP requests.
9. WHEN a user requests a password reset, THE Portal SHALL send a reset link to the user's registered email address that expires after 60 minutes.
10. IF a password reset link is used more than once or has expired, THEN THE Portal SHALL reject the request and prompt the user to request a new link.
11. THE Portal SHALL store all passwords using a salted cryptographic hash (bcrypt with a minimum cost factor of 12).

---

### Requirement 2: Role-Based Access Control (RBAC)

**User Story:** As the system owner, I want every access control rule enforced at the API and database level, so that no employee can access data or functionality outside their role regardless of how the Portal is accessed.

#### Acceptance Criteria

1. THE Portal SHALL assign exactly one role to each user account from the set: `BD_Agent`, `Estimation_Engineer`, `Design_Engineer`, `Admin`.
2. THE Portal SHALL enforce all access control rules in the backend API layer and SHALL NOT rely solely on frontend visibility to restrict access.
3. WHEN any API request is received, THE Portal SHALL validate the requester's JWT and role before executing the requested operation.
4. IF a user's JWT does not authorise the requested operation, THEN THE Portal SHALL return an HTTP 403 response and SHALL NOT return any data.
5. THE Portal SHALL ensure that no database query executed on behalf of a BD_Agent returns any Project record not submitted by that BD_Agent.
6. THE Portal SHALL ensure that no database query executed on behalf of an Engineer returns any Project record not assigned to that Engineer.
7. THE Portal SHALL ensure that no API endpoint returns any user account record to a BD_Agent or Engineer.
8. THE Portal SHALL ensure that no API endpoint exposes client contact details (name, email, phone) to any Engineer.
9. THE Portal SHALL ensure that the assignment status, delivery status, and client-send status of a Project are never returned in any API response to a BD_Agent.
10. WHEN an Admin role is required for an operation, THE Portal SHALL reject requests from all non-Admin roles with an HTTP 403 response.

---

### Requirement 3: BD Agent — Project Intake

**User Story:** As a BD_Agent, I want to submit a new client project through a structured form, so that Admin can review it and assign it to the appropriate engineer.

#### Acceptance Criteria

1. THE Portal SHALL provide a project intake form accessible only to authenticated BD_Agent users.
2. THE intake form SHALL require the following fields: client name, client email address, client phone number, project scope description, requested deadline date, and at least one uploaded project file.
3. WHEN a BD_Agent submits the intake form with all required fields and valid file attachments, THE Portal SHALL create a new Project record with status `received` and associate it with the submitting BD_Agent.
4. IF a BD_Agent submits the intake form with any required field missing or with an invalid email address format, THEN THE Portal SHALL return a validation error identifying each invalid field and SHALL NOT create a Project record.
5. THE Portal SHALL accept project file uploads in the following formats: PDF, DWG, DXF, PNG, JPG, XLSX, DOCX, and ZIP.
6. THE Portal SHALL reject any individual file upload exceeding 100 MB and SHALL return a descriptive error message.
7. WHEN a project file is uploaded, THE Portal SHALL store the file in encrypted cloud storage and associate a Signed_URL with the Project record.
8. WHEN a Project is successfully created, THE Portal SHALL display a confirmation to the BD_Agent and add the Project to the BD_Agent's personal dashboard with status shown as "Received".

---

### Requirement 4: BD Agent — Personal Dashboard

**User Story:** As a BD_Agent, I want to see a list of the projects I have submitted, so that I can confirm my submissions were received.

#### Acceptance Criteria

1. THE Portal SHALL display a personal dashboard to authenticated BD_Agent users listing only the Projects submitted by that BD_Agent.
2. THE BD_Agent dashboard SHALL display the following fields for each Project: project reference number, client name, project scope summary, submission date, and status.
3. THE Portal SHALL display the status of every Project on the BD_Agent dashboard as "Received", regardless of the Project's internal Status_Trail value.
4. THE Portal SHALL NOT display assignment status, engineer name, delivery status, or client-send status on the BD_Agent dashboard.
5. WHILE a BD_Agent is viewing the dashboard, THE Portal SHALL present Projects in reverse chronological order by submission date.

---

### Requirement 5: Admin Dashboard and Project Management

**User Story:** As Admin, I want a full-visibility dashboard showing all projects and their complete status, so that I can manage the pipeline and ensure work is completed and delivered on time.

#### Acceptance Criteria

1. THE Portal SHALL provide an Admin dashboard accessible only to authenticated Admin users that displays all Projects in the system.
2. THE Admin dashboard SHALL display the following for each Project: project reference number, BD_Agent who submitted it, client name, client email, client phone, project scope, submission date, current Status_Trail value, assigned Engineer (if assigned), internal deadline, and priority.
3. WHEN Admin views a Project, THE Portal SHALL display the complete Status_Trail history with timestamps for each status transition.
4. THE Admin dashboard SHALL provide filtering by: Status_Trail value, engineer assignment, project type (estimation vs. design), submission date range, and deadline date range.
5. THE Admin dashboard SHALL provide a search function that returns Projects matching a client name or project reference number substring.
6. WHEN a new Project is submitted by any BD_Agent, THE Portal SHALL notify Admin via an in-Portal notification.

---

### Requirement 6: Admin — Project Assignment

**User Story:** As Admin, I want to assign each incoming project to a specific engineer with a deadline, priority, and instructions, so that the correct engineer receives and understands the work.

#### Acceptance Criteria

1. THE Portal SHALL provide an assignment interface accessible only to Admin that allows assigning a Project to a specific Engineer.
2. WHEN Admin assigns a Project, THE Portal SHALL require Admin to select: the engineer type (`Estimation_Engineer` or `Design_Engineer`), the specific Engineer from a list of available Engineers of that type, an internal deadline date, a priority level from the set `{low, medium, high, urgent}`, and optional written instructions.
3. WHEN Admin submits a valid assignment, THE Portal SHALL update the Project status to `assigned`, record the assignment details, and notify the assigned Engineer via an in-Portal notification.
4. WHEN Admin reassigns a Project that is already assigned, THE Portal SHALL record the reassignment in the Audit_Log, notify the newly assigned Engineer, and remove the Project from the previously assigned Engineer's dashboard.
5. IF Admin attempts to assign a Project to an Engineer of the wrong type (e.g., assigning a design project to an Estimation_Engineer), THE Portal SHALL display a confirmation warning before proceeding.

---

### Requirement 7: Engineer Dashboard and Work Completion

**User Story:** As an Engineer, I want to see only the projects assigned to me with their files and instructions, so that I can complete and submit my work without seeing unrelated projects or other users.

#### Acceptance Criteria

1. THE Portal SHALL display an Engineer dashboard to authenticated Engineer users listing only Projects assigned to that Engineer.
2. THE Engineer dashboard SHALL display the following for each assigned Project: project reference number, project scope/description, Admin instructions, internal deadline, priority level, and current status.
3. THE Engineer dashboard SHALL NOT display client name, client email, client phone, BD_Agent name, or any information about other Engineers or their projects.
4. WHEN an Engineer selects a Project, THE Portal SHALL provide a download action that generates a Signed_URL for each project file, valid for 60 minutes.
5. WHEN an Engineer uploads a Deliverable for a Project, THE Portal SHALL store the Deliverable in encrypted cloud storage, update the Project status to `delivered`, and notify Admin via an in-Portal notification.
6. THE Portal SHALL accept Deliverable file uploads in the following formats: PDF, DWG, DXF, PNG, JPG, XLSX, DOCX, and ZIP.
7. THE Portal SHALL reject any individual Deliverable file upload exceeding 100 MB and SHALL return a descriptive error message.
8. WHILE a Project has status `delivered` or `sent_to_client`, THE Portal SHALL display the Project on the Engineer dashboard as read-only with no further upload action available.
9. THE Engineer dashboard SHALL display a deadline countdown in days and hours for each Project with status `assigned` or `in_progress`.
10. WHEN an Engineer opens a project and begins downloading files, THE Portal SHALL update the Project status to `in_progress`.

---

### Requirement 8: Admin — Client Delivery

**User Story:** As Admin, I want to send the completed deliverable directly to the client by email, so that the client receives their work without any employee contact information being exposed.

#### Acceptance Criteria

1. THE Portal SHALL provide a "Send to Client" action accessible only to Admin, available on Projects with status `delivered`.
2. WHEN Admin initiates the "Send to Client" action, THE Portal SHALL pre-populate the recipient email address from the client email stored on the Project record and SHALL allow Admin to edit the email body using a template with variable substitution.
3. THE Portal SHALL support two delivery methods selectable by Admin: direct attachment (for total Deliverable size ≤ 25 MB) and secure download link (a Signed_URL expiring after 72 hours, for all sizes).
4. WHEN Admin confirms the "Send to Client" action, THE Portal SHALL send the Transactional_Email via the configured email service (Amazon SES or SendGrid), update the Project status to `sent_to_client`, and record the action in the Audit_Log with timestamp.
5. IF the Transactional_Email fails to send, THEN THE Portal SHALL display an error to Admin, SHALL NOT update the Project status, and SHALL log the failure in the Audit_Log.
6. THE Portal SHALL NOT expose any employee name, email, or contact information in the client-facing email.

---

### Requirement 9: Scoped One-to-One Chat

**User Story:** As any employee, I want a private chat channel with Admin only, so that I can communicate about my work without seeing or contacting any other employee.

#### Acceptance Criteria

1. THE Portal SHALL provide exactly one Chat_Thread per employee account, connecting that employee exclusively to Admin.
2. THE Portal SHALL NOT allow any Chat_Thread between two non-Admin users.
3. WHEN a user sends a message in their Chat_Thread, THE Portal SHALL deliver the message to the other party in real time using WebSockets.
4. WHEN a user is not connected via WebSocket, THE Portal SHALL queue undelivered messages and deliver them when the user reconnects.
5. THE Portal SHALL display a message history for each Chat_Thread, showing messages in chronological order with sender name and timestamp.
6. THE Portal SHALL NOT expose the existence, identity, or message content of any other Chat_Thread to any non-Admin user.
7. WHEN Admin opens the chat interface, THE Portal SHALL display a list of all employee Chat_Threads, identified only by the employee's name and role.
8. THE Portal SHALL persist all chat messages in the database and SHALL NOT delete messages automatically.

---

### Requirement 10: Notifications

**User Story:** As an employee, I want to receive relevant in-Portal notifications, so that I know when action is required without needing to poll the dashboard.

#### Acceptance Criteria

1. WHEN a BD_Agent submits a new Project, THE Portal SHALL deliver an in-Portal notification to Admin.
2. WHEN Admin assigns a Project to an Engineer, THE Portal SHALL deliver an in-Portal notification to that Engineer containing the project reference number and deadline.
3. WHEN an Engineer uploads a Deliverable, THE Portal SHALL deliver an in-Portal notification to Admin containing the project reference number and Engineer name.
4. THE Portal SHALL NOT deliver any notification to a BD_Agent regarding assignment, delivery, or client-send events.
5. WHEN a Project deadline is within 24 hours and the Project status is `assigned` or `in_progress`, THE Portal SHALL deliver an in-Portal notification to the assigned Engineer and to Admin.
6. THE Portal SHALL display a count of unread notifications in the navigation interface for the authenticated user.
7. WHEN a user acknowledges a notification, THE Portal SHALL mark it as read and decrement the unread count.
8. THE Portal SHALL NOT include any other employee's name, role, or contact information in any notification delivered to a non-Admin user.

---

### Requirement 11: Audit Log

**User Story:** As Admin, I want an immutable log of every significant system action, so that I can investigate issues and demonstrate compliance.

#### Acceptance Criteria

1. THE Portal SHALL record an Audit_Log entry for every one of the following events: user login (success and failure), password reset, project submission, project assignment, project reassignment, deliverable upload, "Send to Client" action (success and failure), chat message sent, and any change to a user account.
2. EACH Audit_Log entry SHALL contain: event type, timestamp (UTC), actor user ID and role, and event-specific metadata (e.g., Project ID, target user ID).
3. THE Portal SHALL expose the Audit_Log exclusively through the Admin interface and SHALL prevent all other roles from reading it.
4. THE Portal SHALL NOT allow any Audit_Log entry to be modified or deleted through any API endpoint.
5. THE Audit_Log SHALL be queryable by Admin using filters: event type, date range, and actor user ID.

---

### Requirement 12: File Storage Security

**User Story:** As the system owner, I want all uploaded files stored securely with access restricted to authorised users, so that client project data and deliverables are protected.

#### Acceptance Criteria

1. THE Portal SHALL store all uploaded project files and deliverables in a private cloud storage bucket (AWS S3 or DigitalOcean Spaces) with public access disabled at the bucket level.
2. THE Portal SHALL generate a Signed_URL for file access, valid for no longer than 60 minutes for project files and 72 hours for client delivery links.
3. WHEN a Signed_URL expires, THE Portal SHALL deny access to the file via that URL.
4. THE Portal SHALL enforce role-based access checks before generating any Signed_URL, ensuring BD_Agents cannot access Deliverables and Engineers cannot access files from Projects not assigned to them.
5. THE Portal SHALL encrypt all files at rest using AES-256 or the equivalent default encryption provided by the storage service.
6. WHEN a file is deleted from the Portal, THE Portal SHALL delete or revoke access to the corresponding object in cloud storage within 60 seconds.

---

### Requirement 13: Progressive Web App (PWA)

**User Story:** As any employee, I want to install the Portal on my device like a native app, so that I can access it quickly without navigating to a URL each time.

#### Acceptance Criteria

1. THE Portal SHALL include a valid Web App Manifest specifying app name, icons (at minimum 192×192 and 512×512 pixels), theme colour, and display mode `standalone`.
2. THE Portal SHALL register a Service Worker that caches static assets (HTML, CSS, JS bundles) for offline loading.
3. WHEN the Portal is loaded on a supported browser, THE Portal SHALL meet the browser's PWA installability criteria to display an install prompt.
4. WHILE the device is offline, THE Portal SHALL display the last cached dashboard view and a clear connectivity status indicator, and SHALL queue any user actions that require network access.

---

### Requirement 14: Performance and Scalability

**User Story:** As the system owner, I want the Portal to remain responsive under concurrent usage, so that employees across Pakistan and Admin in any location can use it without degradation.

#### Acceptance Criteria

1. THE Portal SHALL support at least 50 concurrent authenticated sessions without exceeding a 2-second response time for dashboard load requests under nominal load.
2. WHEN file upload or download operations are in progress, THE Portal SHALL display a progress indicator and SHALL NOT block other user interface interactions.
3. THE Portal SHALL paginate all list views (project lists, audit logs, chat history) returning no more than 50 records per page by default.
4. THE Portal SHALL be deployable on a single cloud VPS or managed platform and SHALL use horizontal scaling capability to accommodate future growth.

---

### Requirement 15: User Account Management

**User Story:** As Admin, I want to create, update, and deactivate employee accounts, so that I can manage the workforce as it changes.

#### Acceptance Criteria

1. THE Portal SHALL allow Admin to create a new user account by specifying: full name, email address, role, and an initial temporary password.
2. WHEN a new user account is created, THE Portal SHALL send a welcome email to the new user's email address containing a link to set their permanent password, expiring after 24 hours.
3. THE Portal SHALL allow Admin to change the role of any non-Admin user account.
4. WHEN Admin deactivates a user account, THE Portal SHALL immediately invalidate all active JWT tokens for that user and prevent new logins.
5. WHEN Admin deactivates a user account, THE Portal SHALL NOT delete the user's project history, chat messages, or audit trail entries.
6. THE Portal SHALL allow Admin to reset the password of any user account, triggering the same password reset email flow described in Requirement 1.
7. THE Portal SHALL NOT allow any user to modify their own role or the role of another user except through Admin.
