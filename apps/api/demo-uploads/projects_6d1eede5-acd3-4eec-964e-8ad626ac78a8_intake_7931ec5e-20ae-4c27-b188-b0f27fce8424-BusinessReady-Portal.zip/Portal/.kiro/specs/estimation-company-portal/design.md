# Technical Design Document
## Estimation Company Portal

---

## 1. System Architecture Overview

The Portal is a monolithic web application deployed on a single cloud VPS/managed platform, composed of three main tiers:

```
┌─────────────────────────────────────────────────────┐
│                   Client (Browser)                  │
│          Next.js 14 App Router  ·  PWA              │
└─────────────────────┬───────────────────────────────┘
                      │ HTTPS / WSS
┌─────────────────────▼───────────────────────────────┐
│               NestJS API Server                     │
│  REST endpoints  ·  Socket.IO gateway  ·  Guards    │
└──────┬──────────────┬──────────────────┬────────────┘
       │              │                  │
┌──────▼──────┐ ┌─────▼──────┐ ┌────────▼────────┐
│ PostgreSQL  │ │  AWS S3    │ │  SendGrid /     │
│  (primary  │ │  (file     │ │  Amazon SES     │
│  database) │ │  storage)  │ │  (email)        │
└─────────────┘ └────────────┘ └─────────────────┘
```

**Key architectural decisions:**

- **NestJS** provides a modular, decorator-driven structure with built-in Guards, Interceptors, and Pipes — ideal for enforcing RBAC at the framework level before any business logic runs.
- **PostgreSQL Row-Level Security (RLS)** is enabled as a second enforcement layer so that even raw SQL queries through the connection pool cannot return cross-user data.
- **Next.js App Router** with server components handles SSR for initial page load performance; client components manage real-time interactions.
- **Socket.IO** runs as a NestJS WebSocket gateway, sharing the same JWT authentication middleware as REST endpoints.

---

## 2. Repository Structure

```
portal/
├── apps/
│   ├── web/                        # Next.js 14 frontend
│   │   ├── app/
│   │   │   ├── (auth)/             # Login, reset-password, 2fa
│   │   │   ├── (bd)/               # BD agent pages
│   │   │   ├── (engineer)/         # Engineer pages
│   │   │   ├── (admin)/            # Admin pages
│   │   │   └── layout.tsx
│   │   ├── components/
│   │   │   ├── ui/                 # Shared design-system components
│   │   │   ├── bd/
│   │   │   ├── engineer/
│   │   │   ├── admin/
│   │   │   └── chat/
│   │   ├── lib/
│   │   │   ├── api.ts              # Typed fetch client
│   │   │   ├── socket.ts           # Socket.IO client singleton
│   │   │   └── auth.ts             # JWT/session helpers
│   │   ├── public/
│   │   │   ├── manifest.json       # PWA manifest
│   │   │   ├── sw.js               # Service Worker
│   │   │   └── icons/
│   │   └── next.config.js
│   └── api/                        # NestJS backend
│       ├── src/
│       │   ├── auth/               # AuthModule
│       │   ├── users/              # UsersModule
│       │   ├── projects/           # ProjectsModule
│       │   ├── assignments/        # AssignmentsModule
│       │   ├── files/              # FilesModule (S3)
│       │   ├── chat/               # ChatModule (Socket.IO)
│       │   ├── notifications/      # NotificationsModule
│       │   ├── delivery/           # DeliveryModule (email)
│       │   ├── audit/              # AuditModule
│       │   └── main.ts
│       ├── prisma/
│       │   └── schema.prisma
│       └── test/
└── docker-compose.yml
```

---

## 3. Database Schema

All tables use PostgreSQL. Row-Level Security (RLS) policies are applied on `projects`, `project_files`, `deliverables`, `chat_messages`, and `notifications`.

### 3.1 Enum Types

```sql
CREATE TYPE user_role AS ENUM (
  'BD_AGENT', 'ESTIMATION_ENGINEER', 'DESIGN_ENGINEER', 'ADMIN'
);

CREATE TYPE project_status AS ENUM (
  'received', 'assigned', 'in_progress', 'delivered', 'sent_to_client'
);

CREATE TYPE priority_level AS ENUM (
  'low', 'medium', 'high', 'urgent'
);

CREATE TYPE audit_event_type AS ENUM (
  'USER_LOGIN_SUCCESS', 'USER_LOGIN_FAILURE', 'PASSWORD_RESET_REQUEST',
  'PASSWORD_RESET_COMPLETE', 'PROJECT_SUBMITTED', 'PROJECT_ASSIGNED',
  'PROJECT_REASSIGNED', 'DELIVERABLE_UPLOADED', 'SEND_TO_CLIENT_SUCCESS',
  'SEND_TO_CLIENT_FAILURE', 'CHAT_MESSAGE_SENT', 'USER_ACCOUNT_CREATED',
  'USER_ACCOUNT_UPDATED', 'USER_ACCOUNT_DEACTIVATED', 'ROLE_CHANGED'
);
```

### 3.2 Table Definitions

```sql
-- ─── USERS ───────────────────────────────────────────────────────────────────
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name       VARCHAR(255) NOT NULL,
  email           VARCHAR(255) UNIQUE NOT NULL,
  password_hash   VARCHAR(255) NOT NULL,        -- bcrypt cost 12
  role            user_role NOT NULL,
  totp_secret     VARCHAR(255),                 -- Admin 2FA only; NULL for others
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  lockout_until   TIMESTAMPTZ,                  -- Admin lockout after 3 failed 2FA
  failed_2fa_count INT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── REFRESH TOKENS ──────────────────────────────────────────────────────────
CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  VARCHAR(255) NOT NULL UNIQUE,     -- SHA-256 of the raw token
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens(user_id);

-- ─── PASSWORD RESET TOKENS ───────────────────────────────────────────────────
CREATE TABLE password_reset_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  VARCHAR(255) NOT NULL UNIQUE,
  expires_at  TIMESTAMPTZ NOT NULL,
  used        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── PROJECTS ─────────────────────────────────────────────────────────────────
CREATE TABLE projects (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_number    VARCHAR(20) UNIQUE NOT NULL,  -- e.g. PRJ-2024-0001
  bd_agent_id         UUID NOT NULL REFERENCES users(id),
  client_name         VARCHAR(255) NOT NULL,
  client_email        VARCHAR(255) NOT NULL,
  client_phone        VARCHAR(50) NOT NULL,
  scope_description   TEXT NOT NULL,
  requested_deadline  DATE NOT NULL,
  status              project_status NOT NULL DEFAULT 'received',
  internal_deadline   DATE,
  priority            priority_level,
  admin_instructions  TEXT,
  assigned_to         UUID REFERENCES users(id),    -- NULL until assigned
  project_type        VARCHAR(50),                  -- 'estimation' | 'design'
  submitted_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_projects_bd_agent_id ON projects(bd_agent_id);
CREATE INDEX idx_projects_assigned_to ON projects(assigned_to);
CREATE INDEX idx_projects_status ON projects(status);

-- ─── PROJECT STATUS HISTORY ───────────────────────────────────────────────────
CREATE TABLE project_status_history (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id   UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  from_status  project_status,
  to_status    project_status NOT NULL,
  changed_by   UUID NOT NULL REFERENCES users(id),
  changed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  notes        TEXT
);
CREATE INDEX idx_psh_project_id ON project_status_history(project_id);

-- ─── PROJECT FILES (uploaded by BD agents) ───────────────────────────────────
CREATE TABLE project_files (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id      UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  original_name   VARCHAR(500) NOT NULL,
  s3_key          VARCHAR(1000) NOT NULL UNIQUE,
  mime_type       VARCHAR(100) NOT NULL,
  size_bytes      BIGINT NOT NULL,
  uploaded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_project_files_project_id ON project_files(project_id);

-- ─── DELIVERABLES (uploaded by engineers) ────────────────────────────────────
CREATE TABLE deliverables (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id      UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  engineer_id     UUID NOT NULL REFERENCES users(id),
  original_name   VARCHAR(500) NOT NULL,
  s3_key          VARCHAR(1000) NOT NULL UNIQUE,
  mime_type       VARCHAR(100) NOT NULL,
  size_bytes      BIGINT NOT NULL,
  uploaded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_deliverables_project_id ON deliverables(project_id);

-- ─── CLIENT DELIVERY LOG ─────────────────────────────────────────────────────
CREATE TABLE client_delivery_log (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id      UUID NOT NULL REFERENCES projects(id),
  sent_by         UUID NOT NULL REFERENCES users(id),
  recipient_email VARCHAR(255) NOT NULL,
  subject         VARCHAR(500) NOT NULL,
  delivery_method VARCHAR(20) NOT NULL,          -- 'attachment' | 'link'
  sent_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  success         BOOLEAN NOT NULL,
  error_message   TEXT
);

-- ─── CHAT THREADS ─────────────────────────────────────────────────────────────
-- One thread per non-admin user; enforced by UNIQUE constraint.
CREATE TABLE chat_threads (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id     UUID NOT NULL UNIQUE REFERENCES users(id),  -- non-Admin side
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- Note: admin_id is not stored — it is resolved at query time as the sole Admin user.
-- The UNIQUE constraint on employee_id ensures exactly one thread per employee.

-- ─── CHAT MESSAGES ────────────────────────────────────────────────────────────
CREATE TABLE chat_messages (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id   UUID NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  sender_id   UUID NOT NULL REFERENCES users(id),
  content     TEXT NOT NULL,
  sent_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  read_at     TIMESTAMPTZ
);
CREATE INDEX idx_chat_messages_thread_id ON chat_messages(thread_id);
CREATE INDEX idx_chat_messages_sent_at ON chat_messages(thread_id, sent_at);

-- ─── NOTIFICATIONS ────────────────────────────────────────────────────────────
CREATE TABLE notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_type  VARCHAR(100) NOT NULL,
  title       VARCHAR(255) NOT NULL,
  body        TEXT NOT NULL,
  metadata    JSONB,                              -- project_id, etc.
  read        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_user_id ON notifications(user_id, read);

-- ─── AUDIT LOG ────────────────────────────────────────────────────────────────
CREATE TABLE audit_log (
  id          BIGSERIAL PRIMARY KEY,             -- serial for ordering guarantee
  event_type  audit_event_type NOT NULL,
  actor_id    UUID REFERENCES users(id),         -- NULL for system events
  actor_role  user_role,
  target_id   UUID,                              -- project_id, user_id, etc.
  metadata    JSONB,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_log_actor_id ON audit_log(actor_id);
CREATE INDEX idx_audit_log_event_type ON audit_log(event_type);
CREATE INDEX idx_audit_log_occurred_at ON audit_log(occurred_at);
-- No DELETE or UPDATE privilege granted on this table to any application role.
```

### 3.3 Row-Level Security Policies

```sql
-- Enable RLS
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE deliverables ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Application uses three database roles: portal_admin, portal_bd, portal_engineer
-- Current user ID is passed via SET LOCAL app.current_user_id = '<uuid>'
-- Current user role is passed via SET LOCAL app.current_user_role = '<role>'

-- Projects: BD agents see only their own; engineers see only assigned to them
CREATE POLICY projects_bd_isolation ON projects
  FOR ALL TO portal_bd
  USING (bd_agent_id = current_setting('app.current_user_id')::UUID);

CREATE POLICY projects_engineer_isolation ON projects
  FOR ALL TO portal_engineer
  USING (assigned_to = current_setting('app.current_user_id')::UUID);

-- project_files: BD agents see only files for their projects
CREATE POLICY project_files_bd_isolation ON project_files
  FOR SELECT TO portal_bd
  USING (project_id IN (
    SELECT id FROM projects WHERE bd_agent_id = current_setting('app.current_user_id')::UUID
  ));

-- project_files: Engineers see only files for their assigned projects
CREATE POLICY project_files_engineer_isolation ON project_files
  FOR SELECT TO portal_engineer
  USING (project_id IN (
    SELECT id FROM projects WHERE assigned_to = current_setting('app.current_user_id')::UUID
  ));

-- Deliverables: BD agents cannot access at all (no policy = deny)
-- Engineers see only deliverables for their own projects
CREATE POLICY deliverables_engineer_isolation ON deliverables
  FOR ALL TO portal_engineer
  USING (engineer_id = current_setting('app.current_user_id')::UUID);

-- Chat messages: user can only see messages in their own thread
CREATE POLICY chat_messages_isolation ON chat_messages
  FOR ALL TO portal_bd, portal_engineer
  USING (thread_id IN (
    SELECT id FROM chat_threads
    WHERE employee_id = current_setting('app.current_user_id')::UUID
  ));

-- Notifications: user sees only their own
CREATE POLICY notifications_isolation ON notifications
  FOR ALL TO portal_bd, portal_engineer
  USING (user_id = current_setting('app.current_user_id')::UUID);
```

---

## 4. Backend — NestJS Module Design

### 4.1 AuthModule

**Responsibilities:** Login, token issuance, token refresh, password reset, 2FA (TOTP), account lockout.

**Endpoints:**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/auth/login` | Public | Validate credentials; issue JWT + refresh token. Admin: returns `requires_2fa: true` pending TOTP. |
| POST | `/auth/2fa/verify` | Partial (pre-2FA token) | Submit TOTP code; issue full JWT if valid. |
| POST | `/auth/refresh` | Refresh token cookie | Rotate access token. |
| POST | `/auth/logout` | JWT | Revoke refresh token. |
| POST | `/auth/forgot-password` | Public | Send reset email. |
| POST | `/auth/reset-password` | Reset token | Set new password. |
| POST | `/auth/2fa/setup` | Admin JWT | Generate TOTP secret + QR code for initial setup. |
| POST | `/auth/2fa/confirm` | Admin JWT | Confirm TOTP setup with a valid code. |

**JWT Payload:**
```typescript
interface JwtPayload {
  sub: string;        // user UUID
  role: UserRole;
  iat: number;
  exp: number;
}
```

**Guards:**
- `JwtAuthGuard` — validates access token on every protected route.
- `RolesGuard` — checks `@Roles(...)` decorator against JWT payload role.
- `TwoFactorGuard` — applied to Admin routes; rejects if 2FA not completed.

### 4.2 UsersModule (Admin only)

**Endpoints:**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/users` | Admin | List all users (paginated, filterable by role). |
| POST | `/users` | Admin | Create new user account; send welcome email. |
| PATCH | `/users/:id` | Admin | Update name, role, active status. |
| POST | `/users/:id/reset-password` | Admin | Trigger password reset email. |
| DELETE | `/users/:id/deactivate` | Admin | Deactivate account; revoke all tokens. |
| GET | `/users/engineers` | Admin | List active engineers by type (used in assignment dropdown). |

**Response DTOs are role-scoped:** Admin sees full user objects. No endpoint returns user lists to BD_Agent or Engineer roles.

### 4.3 ProjectsModule

**Endpoints:**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/projects` | BD_Agent | Submit new project (multipart/form-data). |
| GET | `/projects` | BD_Agent, Admin, Engineer | Returns role-scoped list (RLS enforced). |
| GET | `/projects/:id` | BD_Agent, Admin, Engineer | Returns role-scoped detail view. |
| PATCH | `/projects/:id/assign` | Admin | Assign project to engineer. |
| PATCH | `/projects/:id/reassign` | Admin | Reassign to different engineer. |
| GET | `/projects/:id/status-history` | Admin | Full status trail. |

**Response shape by role:**

```typescript
// BD_Agent — client data visible, status always normalised to "Received"
interface ProjectBDView {
  id: string;
  referenceNumber: string;
  clientName: string;
  scopeSummary: string;
  submittedAt: string;
  status: 'Received';          // always "Received" regardless of internal value
}

// Engineer — NO client data, NO bd_agent info
interface ProjectEngineerView {
  id: string;
  referenceNumber: string;
  scopeDescription: string;
  adminInstructions: string | null;
  internalDeadline: string;
  priority: PriorityLevel;
  status: ProjectStatus;
  files: ProjectFileRef[];
  deadlineCountdown: { days: number; hours: number };
}

// Admin — full data
interface ProjectAdminView {
  id: string;
  referenceNumber: string;
  bdAgentName: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  scopeDescription: string;
  submittedAt: string;
  status: ProjectStatus;
  assignedEngineer: { id: string; name: string; role: UserRole } | null;
  internalDeadline: string | null;
  priority: PriorityLevel | null;
  adminInstructions: string | null;
  statusHistory: StatusHistoryEntry[];
}
```

### 4.4 FilesModule

**Responsibilities:** Generate pre-signed S3 upload URLs, generate pre-signed S3 download URLs, enforce role-based access before signing, record file metadata in DB.

**Endpoints:**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/files/upload-url` | BD_Agent, Engineer | Generate a pre-signed S3 PUT URL (60s TTL). |
| POST | `/files/confirm` | BD_Agent, Engineer | Confirm upload complete; record metadata. |
| GET | `/files/:id/download-url` | BD_Agent, Admin, Engineer | Generate pre-signed GET URL after role check. |
| DELETE | `/files/:id` | Admin | Delete file from S3 and DB. |

**S3 key structure:**
```
projects/{project_id}/intake/{uuid}-{filename}       -- project files
projects/{project_id}/deliverables/{uuid}-{filename} -- deliverables
```

**Role access matrix for download URL generation:**

| File type | BD_Agent | Engineer (assigned) | Admin |
|-----------|----------|---------------------|-------|
| Project file | ✓ (own projects only) | ✓ | ✓ |
| Deliverable | ✗ | ✓ (own deliverables) | ✓ |

### 4.5 AssignmentsModule

Handles the project assignment flow. Triggers:
1. DB update: `projects.status → assigned`, `projects.assigned_to`, `projects.internal_deadline`, `projects.priority`, `projects.admin_instructions`, `projects.project_type`.
2. `project_status_history` insert.
3. `audit_log` insert (`PROJECT_ASSIGNED` or `PROJECT_REASSIGNED`).
4. Notification to engineer via `NotificationsService`.

### 4.6 ChatModule (WebSocket Gateway)

**Socket.IO Gateway** — `ChatGateway` decorated with `@WebSocketGateway({ namespace: '/chat' })`.

**Authentication:** Middleware validates JWT from `auth` handshake query param before allowing connection. Sets `socket.data.user` with the JWT payload.

**Room strategy:**
- Each chat thread is a Socket.IO room named `thread:{thread_id}`.
- On connect, the server joins the socket to `thread:{thread_id}` only — derived from `chat_threads` table. An employee can only join their own thread. Admin is joined to all threads.
- The server NEVER emits the room list to clients — thread routing is server-side only.

**Events:**

| Direction | Event | Payload | Description |
|-----------|-------|---------|-------------|
| Client → Server | `send_message` | `{ content: string }` | Send a message in the user's thread. |
| Server → Client | `new_message` | `ChatMessageDto` | Deliver message to recipient. |
| Server → Client | `thread_list` | `ThreadSummary[]` | Admin only: list of all threads with unread counts. |
| Client → Server | `mark_read` | `{ message_id: string }` | Mark message as read. |

**REST endpoints (chat history, paginated):**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/chat/thread` | BD_Agent, Engineer | Get own thread ID and message history (paginated). |
| GET | `/chat/threads` | Admin | List all threads with last message preview. |
| GET | `/chat/threads/:id/messages` | Admin | Full message history for a thread (paginated). |

**DB model enforcement:** The `chat_threads` table has `UNIQUE(employee_id)` — the schema physically cannot store two threads for the same employee or a thread between two non-Admin users.

### 4.7 NotificationsModule

**Delivery mechanism:** Notifications are persisted to the `notifications` table, then pushed to the connected user's Socket.IO room (`user:{user_id}`) via the `NotificationsGateway`.

**Notification rules (mapping to requirements):**

| Trigger event | Recipients | BD_Agent notified? |
|--------------|------------|--------------------|
| Project submitted | Admin | No |
| Project assigned | Target engineer | No |
| Deliverable uploaded | Admin | No |
| Deadline within 24h | Assigned engineer + Admin | No |

**Endpoints:**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/notifications` | All | List own unread + recent notifications (paginated). |
| PATCH | `/notifications/:id/read` | All | Mark as read. |
| PATCH | `/notifications/read-all` | All | Mark all as read. |

### 4.8 DeliveryModule

**Endpoints:**

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/delivery/:project_id/preview` | Admin | Preview populated email template. |
| POST | `/delivery/:project_id/send` | Admin | Send email to client; log result. |

**Send flow:**
1. Verify project status is `delivered`.
2. Fetch client email from `projects.client_email` (not from any user input at send time — source of truth is the original BD submission).
3. Admin selects delivery method (`attachment` or `link`) and edits template.
4. If `attachment`: fetch deliverable files from S3, attach if total ≤ 25 MB; else force `link`.
5. If `link`: generate S3 pre-signed GET URL with 72-hour TTL.
6. Send via SendGrid API (or Amazon SES).
7. On success: update `projects.status → sent_to_client`, insert `client_delivery_log`, insert `audit_log`.
8. On failure: insert `client_delivery_log` with `success=false`, insert `audit_log` with `SEND_TO_CLIENT_FAILURE`.

**Email template variables:** `{{client_name}}`, `{{project_reference}}`, `{{company_name}}`, `{{download_link}}` (if link delivery).

### 4.9 AuditModule

- `AuditService.log(event)` is called from every module — it is a fire-and-forget insert with no application-level read.
- Exposed only via Admin endpoint: `GET /audit?event_type=&actor_id=&from=&to=&page=&limit=`.
- The PostgreSQL application role used for audit writes has `INSERT` only on `audit_log` (no `UPDATE`, `DELETE`, `SELECT` for non-admin roles).

---

## 5. Frontend — Next.js Page & Component Structure

### 5.1 Route Groups and Pages

```
app/
├── (auth)/
│   ├── login/page.tsx
│   ├── reset-password/page.tsx
│   └── 2fa/page.tsx
│
├── (bd)/
│   ├── layout.tsx              -- RoleGuard: BD_AGENT only
│   ├── dashboard/page.tsx      -- Project list (status always "Received")
│   ├── submit/page.tsx         -- Intake form
│   └── chat/page.tsx           -- Chat with Admin
│
├── (engineer)/
│   ├── layout.tsx              -- RoleGuard: ESTIMATION_ENGINEER | DESIGN_ENGINEER
│   ├── dashboard/page.tsx      -- Assigned project queue
│   ├── projects/[id]/page.tsx  -- Project detail, file download, deliverable upload
│   └── chat/page.tsx           -- Chat with Admin
│
└── (admin)/
    ├── layout.tsx              -- RoleGuard: ADMIN only
    ├── dashboard/page.tsx      -- Full project pipeline
    ├── projects/[id]/page.tsx  -- Full project detail + assign + send-to-client
    ├── chat/page.tsx           -- All employee threads
    ├── users/page.tsx          -- User management
    ├── audit/page.tsx          -- Audit log viewer
    └── notifications/page.tsx
```

### 5.2 Role Guard Implementation

`RoleGuard` is a Next.js layout-level server component that reads the session cookie, validates the JWT, checks the role, and redirects to `/login` or `/403` if unauthorized. This means route-level access is enforced server-side, not just client-side.

```typescript
// apps/web/components/RoleGuard.tsx (Server Component)
export async function RoleGuard({
  allowedRoles,
  children,
}: {
  allowedRoles: UserRole[];
  children: React.ReactNode;
}) {
  const session = await getServerSession();
  if (!session || !allowedRoles.includes(session.role)) {
    redirect('/login');
  }
  return <>{children}</>;
}
```

### 5.3 Key Component Responsibilities

**BD Dashboard (`/bd/dashboard`):**
- Fetches `GET /projects` — server always returns `status: "Received"` for BD role.
- Columns: Reference, Client Name, Scope Summary, Submitted Date, Status.
- "New Project" button → `/bd/submit`.

**BD Intake Form (`/bd/submit`):**
- Controlled form with validation (react-hook-form + zod).
- File upload: requests pre-signed URL from `/files/upload-url`, uploads directly to S3, then calls `/files/confirm`.
- Shows upload progress per file.
- On success: toast confirmation, redirects to dashboard.

**Admin Dashboard (`/admin/dashboard`):**
- Server component fetches paginated project list with filters.
- Filter bar: status, engineer, project type, date ranges.
- Search bar.
- Status badges with full Status_Trail visibility.
- Row actions: "Assign", "View", "Send to Client" (shown only when `status === delivered`).

**Assignment Modal:**
- Step 1: Select engineer type (Estimation / Design & Drafting).
- Step 2: Select specific engineer from dropdown (filtered list from `/users/engineers`).
- Step 3: Set internal deadline, priority, instructions.
- Submits to `PATCH /projects/:id/assign`.

**Engineer Dashboard (`/engineer/dashboard`):**
- Project list — NO client columns.
- Deadline countdown badge (red if < 24h, amber if < 72h).
- Priority badge.
- Click row → project detail page.

**Engineer Project Detail (`/engineer/projects/[id]`):**
- Scope description and Admin instructions panel.
- File list with individual "Download" buttons (fetches signed URL on click).
- Deliverable upload section (hidden when status is `delivered` or `sent_to_client`).
- Upload status indicator.

**Chat (`/chat` for all roles, scoped by role):**
- Socket.IO connection authenticated via JWT.
- Message thread displayed as chat bubbles.
- Textarea + send button.
- Admin view: left sidebar lists all threads; selecting one opens that thread.

**Notifications Bell:**
- Persistent in nav bar for all authenticated users.
- Unread count badge.
- Dropdown showing last 10 notifications.
- "Mark all read" action.
- Real-time updates via Socket.IO `notification` event.

---

## 6. Real-Time Communication Design

### 6.1 WebSocket Namespaces

| Namespace | Purpose |
|-----------|---------|
| `/chat` | Chat messages |
| `/notifications` | In-Portal notification delivery |

### 6.2 Authentication Handshake

```typescript
// Client connects with JWT in auth object
const socket = io('/chat', {
  auth: { token: accessToken },
  transports: ['websocket'],
});
```

The NestJS `IoAdapter` middleware intercepts the handshake, validates the JWT, and attaches `socket.data.user`. Connections with invalid or expired tokens are rejected immediately.

### 6.3 Room Assignments on Connect

```typescript
// Server-side on connection
async handleConnection(socket: Socket) {
  const user = socket.data.user; // from JWT middleware
  if (user.role === 'ADMIN') {
    // Admin joins ALL chat threads and the admin notification room
    const threads = await this.chatService.getAllThreadIds();
    threads.forEach(id => socket.join(`thread:${id}`));
    socket.join(`user:${user.sub}`);
  } else {
    // Non-admin joins only their own thread and their notification room
    const thread = await this.chatService.getOrCreateThread(user.sub);
    socket.join(`thread:${thread.id}`);
    socket.join(`user:${user.sub}`);
  }
}
```

---

## 7. File Upload Flow

```
Browser                   Next.js API Route           NestJS API           AWS S3
   |                            |                         |                   |
   |-- POST /files/upload-url -->|                         |                   |
   |                            |-- POST /files/upload-url->|                 |
   |                            |<-- { uploadUrl, fileId } --|                |
   |<-- { uploadUrl, fileId } ---|                         |                   |
   |                            |                         |                   |
   |-- PUT {uploadUrl} (file) --------------------------------->|              |
   |<-- 200 OK -------------------------------------------------|              |
   |                            |                         |                   |
   |-- POST /files/confirm ----->|                         |                   |
   |                            |-- POST /files/confirm ---->|                |
   |                            |                         |-- HEAD {s3_key} ->|
   |                            |                         |<-- file exists ---|
   |                            |                         |-- INSERT project_files
   |                            |<-- { file metadata } ------|               |
   |<-- { file metadata } -------|                         |                   |
```

**Security:** The pre-signed PUT URL is scoped to a specific S3 key and expires in 60 seconds. The `confirm` step verifies the object exists in S3 before recording in the database, preventing phantom file records.

---

## 8. Security Design

### 8.1 Defence-in-Depth Layers

| Layer | Mechanism |
|-------|-----------|
| Network | HTTPS/TLS 1.3 everywhere; HTTP → HTTPS redirect |
| Authentication | JWT (15-min access token) + httpOnly refresh token cookie |
| Authorisation (L1) | NestJS Guards + `@Roles()` decorator |
| Authorisation (L2) | PostgreSQL RLS policies with per-request session variables |
| Data isolation | Scoped SQL queries + RLS = two independent enforcement points |
| File access | Pre-signed S3 URLs; role check before every URL generation |
| Password storage | bcrypt, cost factor 12 |
| Admin hardening | TOTP 2FA, account lockout after 3 failures, lockout email alert |
| Audit | Immutable append-only `audit_log`; DB role has INSERT-only access |

### 8.2 Sensitive Data Handling

- `client_email`, `client_phone`, `client_name` are stored only in the `projects` table.
- The `ProjectEngineerView` DTO explicitly omits these three columns — they are never selected in engineer-scoped queries.
- Chat message content is stored in DB but never returned cross-thread.
- S3 bucket has `BlockPublicAcls: true` and `BlockPublicPolicy: true`.
- All S3 objects use server-side encryption (SSE-S3 AES-256 by default; SSE-KMS optionally).

### 8.3 Input Validation

- All API inputs validated via NestJS `class-validator` DTOs with a global `ValidationPipe`.
- File uploads validated for MIME type (server-side magic bytes check via `file-type` library) and size before pre-signed URL generation.
- SQL injection is not possible — all DB queries use Prisma parameterised queries.

---

## 9. PWA Design

### 9.1 Web App Manifest (`public/manifest.json`)

```json
{
  "name": "Estimation Portal",
  "short_name": "Portal",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#1e40af",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png" },
    { "src": "/icons/icon-512-maskable.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

### 9.2 Service Worker Strategy

- **Static assets** (JS bundles, CSS, fonts): Cache-first, served from cache with background revalidation.
- **API requests**: Network-first with fallback to cached response for GET requests.
- **POST/PATCH/PUT**: Never cached; if offline, queued in IndexedDB and retried on reconnection.
- **Offline page**: Cached offline fallback page shown when network is unavailable and no cached route exists.

---

## 10. Environment Configuration

```
# apps/api/.env
DATABASE_URL=postgresql://portal_admin:xxx@localhost:5432/portal
JWT_SECRET=<256-bit secret>
JWT_REFRESH_SECRET=<256-bit secret>
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=us-east-1
AWS_S3_BUCKET=estimation-portal-files
SENDGRID_API_KEY=
SENDGRID_FROM_EMAIL=noreply@yourdomain.com
APP_BASE_URL=https://portal.yourdomain.com
ADMIN_EMAIL=admin@yourdomain.com

# apps/web/.env.local
NEXT_PUBLIC_API_URL=https://api.yourdomain.com
NEXT_PUBLIC_WS_URL=wss://api.yourdomain.com
```

---

## 11. Deployment Architecture

```
                        ┌─────────────────────────────┐
                        │    Cloud VPS / App Platform  │
                        │                             │
         HTTPS          │  ┌──────────┐  ┌─────────┐ │
Users ──────────────────►  │  Nginx   │  │ Node.js │ │
                        │  │ (reverse │──► (NestJS  │ │
                        │  │  proxy)  │  │ + Next)  │ │
                        │  └──────────┘  └────┬────┘ │
                        │                     │      │
                        └─────────────────────┼──────┘
                                              │
                    ┌─────────────────────────┼──────────────┐
                    │         │               │              │
               ┌────▼────┐  ┌▼──────────┐  ┌▼──────────┐   │
               │Postgres │  │  AWS S3   │  │ SendGrid  │   │
               │(managed │  │ (private  │  │   API     │   │
               │ DB)     │  │  bucket)  │  │           │   │
               └─────────┘  └───────────┘  └───────────┘   │
```

- **Nginx** handles SSL termination, HTTP→HTTPS redirect, and WebSocket upgrade (`Upgrade: websocket` header proxied).
- Next.js frontend and NestJS API can run as a combined Node.js process on a single VPS to start, or be split to separate processes behind Nginx for scaling.
- PostgreSQL runs on a managed database service (e.g., DigitalOcean Managed Postgres, AWS RDS) for automated backups and failover.

---

## 12. Key Design Decisions & Rationale

| Decision | Rationale |
|----------|-----------|
| Two-layer access control (NestJS Guards + PostgreSQL RLS) | Provides defence in depth. Even if application code has a bug and calls the wrong query, RLS at the DB level prevents data leakage. |
| `UNIQUE(employee_id)` on `chat_threads` | Enforces the single-thread-per-employee rule at the schema level — not just application logic. It is structurally impossible to create a second thread or an employee-to-employee thread. |
| Status always returned as "Received" for BD role | The API transforms the internal status at the service layer, not the DB. The internal status is never sent over the wire to BD clients. |
| Engineer DTOs omit client fields | Client name/email/phone are never selected in engineer-scoped queries — not just redacted in the response; the columns are absent from the SELECT statement entirely. |
| Pre-signed S3 URLs for all file access | Files are never proxied through the application server, keeping bandwidth costs low and removing the server as a bottleneck for large file downloads. |
| SendGrid over Amazon SES | Simpler API, better deliverability dashboard for non-technical Admin to monitor. Can be swapped for SES with minimal code change (service interface is abstracted). |
| Append-only `audit_log` with DB-level INSERT-only role | Application code physically cannot UPDATE or DELETE audit entries — even if exploited. |
| `BIGSERIAL` primary key on `audit_log` | Provides guaranteed ordering by insertion sequence, important for chronological audit review. |
