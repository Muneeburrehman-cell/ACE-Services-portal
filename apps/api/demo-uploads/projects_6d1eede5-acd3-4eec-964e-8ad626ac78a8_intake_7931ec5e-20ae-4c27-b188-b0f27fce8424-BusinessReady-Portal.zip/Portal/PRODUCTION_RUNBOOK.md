# Business Deployment Runbook

## 1. Build from source

Use Node 22 LTS and the locked dependencies. In CI:

```bash
npm ci
npm run build
```

Run the API build and web build independently if using the monorepo package manager.

## 2. Database

Use PostgreSQL 16+ with a dedicated non-superuser runtime account. Do not run the API with the `postgres` superuser.

```bash
npx prisma migrate deploy
npx prisma generate
```

The `0002_production_hardening` migration replaces the original restrictive/permissive RLS combination with explicit role-scoped policies.

## 3. Seed the administrator

Set `SEED_ADMIN_EMAIL`, `SEED_ADMIN_PASSWORD` (14+ characters), and `SEED_ADMIN_TOTP_SECRET` in a secure one-time seed environment. Do not commit those values.

The seed no longer creates public demo credentials unless `SEED_DEMO=true` is explicitly enabled.

## 4. Storage

Use a private S3 bucket with server-side encryption and least-privilege IAM. Configure object lifecycle and backups. Add malware scanning/quarantine before production client access.

## 5. TLS / proxy

Terminate TLS at a load balancer or reverse proxy and forward `X-Forwarded-Proto: https`. The API rejects plain HTTP in production.

## 6. Email

Configure a verified sender domain and transactional email provider. The API uses the client's stored email as the delivery recipient and does not accept a user-supplied recipient.

## 7. Launch acceptance tests

- BD creates a draft, uploads files, and submits exactly once.
- BD cannot access another BD agent's project.
- Engineers only see projects assigned to them.
- Engineers cannot access client identity fields through project APIs.
- Engineers can only upload deliverables to their assigned project.
- Admin can assign only a matching engineer type.
- Only one active Admin exists.
- Admin 2FA is required.
- Refresh-token replay is rejected.
- Duplicate client delivery is rejected while another delivery is in progress.
- Chat isolation is verified for every non-admin employee.
- Audit records exist for all critical workflow events.
- Database backup restore and S3 recovery are tested.
