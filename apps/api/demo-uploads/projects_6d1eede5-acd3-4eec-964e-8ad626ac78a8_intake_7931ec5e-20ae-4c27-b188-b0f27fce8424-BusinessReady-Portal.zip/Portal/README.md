# Estimation Company Portal — Production-Hardened

A role-isolated construction estimation workflow portal using Next.js, NestJS, PostgreSQL, S3, Socket.IO and transactional email.

## What was hardened

- Draft -> received submission flow requiring at least one intake file.
- Corrected PostgreSQL RLS policy semantics and explicit runtime context.
- Non-superuser database deployment model.
- Server-side engineer/project-type matching.
- S3 upload confirmation binding to project and file type, with size/MIME validation.
- Atomic refresh-token rotation.
- Atomic client-delivery claim to prevent duplicate sends.
- Single active administrator protections.
- Strict WebSocket CORS.
- HTTPS enforcement in production.
- Validated client-delivery DTO.
- Production Dockerfiles and compose configuration.
- Production seed no longer ships with public/default credentials.
- PWA icon/offline assets.

## Architecture

| Layer | Technology | Port |
|---|---|---:|
| Frontend | Next.js 14 App Router / TypeScript / Tailwind | 3000 |
| Backend | NestJS 11 / TypeScript | 4000 |
| Database | PostgreSQL 16 | 5432 |
| Real-time | Socket.IO | — |
| File storage | Private AWS S3 + pre-signed URLs | — |
| Email | SendGrid transactional API | — |

## Local development

### Prerequisites

- Node.js 22 LTS
- Docker
- AWS S3 test bucket/credentials if file upload is being tested
- SendGrid test credentials if email delivery is being tested

### Database

```bash
docker compose up -d
```

The local database uses a dedicated `portal_app` account rather than the PostgreSQL superuser.

### API configuration

Copy `apps/api/.env.local.example` to `apps/api/.env` for local-only values, then add your S3/email configuration if required.

Apply migrations:

```bash
cd apps/api
npx prisma migrate deploy
npx prisma generate
```

Seed a local administrator using environment variables from `apps/api/.env.seed.example`:

```bash
npx prisma db seed
```

The seed requires a unique administrator password of at least 14 characters and a TOTP secret. It does not create the old public demo credentials unless `SEED_DEMO=true` is explicitly enabled.

### Start services

```bash
# API
cd apps/api
npm run dev

# Web, in another terminal
cd apps/web
npm run dev
```

## Production deployment

Use `docker-compose.production.yml` as the baseline and place a TLS reverse proxy/load balancer in front of the web/API services.

Before launch, complete `PRODUCTION_RUNBOOK.md` and `PRODUCTION_READINESS.md`.

Production requirements include:

1. Strong JWT secrets (32+ characters each).
2. `APP_BASE_URL=https://...`.
3. Private S3 with least-privilege IAM.
4. Transactional email configuration.
5. Non-superuser PostgreSQL runtime account.
6. Malware scanning/quarantine for uploaded client files.
7. Automated database backups and restore testing.
8. Application monitoring, alerting and error tracking.
9. End-to-end acceptance testing of the complete project lifecycle.
10. Security/penetration testing before handling sensitive client data.

## Database security

Sensitive tables use PostgreSQL RLS with `FORCE ROW LEVEL SECURITY`. The application sets the authenticated user ID and role inside the transaction through `PrismaService.withRlsContext()`.

Do not run the API as `postgres` or another superuser in production.

## Important workflow

```text
DRAFT
  -> RECEIVED
  -> ASSIGNED
  -> IN_PROGRESS
  -> DELIVERED
  -> DELIVERY_IN_PROGRESS
  -> SENT_TO_CLIENT
```

A BD agent cannot submit a project until at least one intake file has been confirmed. Engineers cannot upload deliverables for projects that are not assigned to them. Admin assignment validates engineer type against the selected project type.

## Verification performed on this package

- API TypeScript compilation passes in the provided environment after the hardening changes.
- API NestJS production build passes in the provided environment.
- Web production build could not be reproduced in the provided sandbox because the web dependency cache is incomplete/offline; the source and package lock are included for CI/build reproduction.

That final infrastructure build limitation should be resolved in your CI environment before go-live.
