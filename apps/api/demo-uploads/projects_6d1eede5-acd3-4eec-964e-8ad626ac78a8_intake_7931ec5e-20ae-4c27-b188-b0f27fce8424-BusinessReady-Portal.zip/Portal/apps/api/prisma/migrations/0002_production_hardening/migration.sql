-- Production hardening: workflow states and correct RLS semantics.
ALTER TYPE "ProjectStatus" ADD VALUE IF NOT EXISTS 'draft';
ALTER TYPE "ProjectStatus" ADD VALUE IF NOT EXISTS 'delivery_in_progress';

-- Correct the original policy model: use permissive role-specific policies,
-- and FORCE RLS so the application role cannot bypass row isolation.
DO $$ DECLARE r record; BEGIN
  FOR r IN SELECT policyname, tablename FROM pg_policies WHERE schemaname = 'public' AND tablename IN ('projects','project_files','deliverables','chat_messages','notifications') LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

ALTER TABLE "projects" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "projects" FORCE ROW LEVEL SECURITY;
CREATE POLICY projects_admin ON "projects" FOR ALL USING (current_setting('app.current_user_role', true) = 'ADMIN') WITH CHECK (current_setting('app.current_user_role', true) = 'ADMIN');
CREATE POLICY projects_bd ON "projects" FOR ALL USING (current_setting('app.current_user_role', true) = 'BD_AGENT' AND bd_agent_id = current_setting('app.current_user_id', true)::uuid) WITH CHECK (current_setting('app.current_user_role', true) = 'BD_AGENT' AND bd_agent_id = current_setting('app.current_user_id', true)::uuid);
CREATE POLICY projects_engineer ON "projects" FOR SELECT USING (current_setting('app.current_user_role', true) IN ('ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND assigned_to = current_setting('app.current_user_id', true)::uuid);
CREATE POLICY projects_engineer_update ON "projects" FOR UPDATE USING (current_setting('app.current_user_role', true) IN ('ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND assigned_to = current_setting('app.current_user_id', true)::uuid) WITH CHECK (current_setting('app.current_user_role', true) IN ('ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND assigned_to = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE "project_files" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "project_files" FORCE ROW LEVEL SECURITY;
CREATE POLICY project_files_admin ON "project_files" FOR ALL USING (current_setting('app.current_user_role', true) = 'ADMIN') WITH CHECK (current_setting('app.current_user_role', true) = 'ADMIN');
CREATE POLICY project_files_bd ON "project_files" FOR ALL USING (current_setting('app.current_user_role', true) = 'BD_AGENT' AND EXISTS (SELECT 1 FROM projects p WHERE p.id = project_id AND p.bd_agent_id = current_setting('app.current_user_id', true)::uuid)) WITH CHECK (current_setting('app.current_user_role', true) = 'BD_AGENT' AND EXISTS (SELECT 1 FROM projects p WHERE p.id = project_id AND p.bd_agent_id = current_setting('app.current_user_id', true)::uuid));
CREATE POLICY project_files_engineer ON "project_files" FOR SELECT USING (current_setting('app.current_user_role', true) IN ('ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND EXISTS (SELECT 1 FROM projects p WHERE p.id = project_id AND p.assigned_to = current_setting('app.current_user_id', true)::uuid));

ALTER TABLE "deliverables" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "deliverables" FORCE ROW LEVEL SECURITY;
CREATE POLICY deliverables_admin ON "deliverables" FOR ALL USING (current_setting('app.current_user_role', true) = 'ADMIN') WITH CHECK (current_setting('app.current_user_role', true) = 'ADMIN');
CREATE POLICY deliverables_engineer ON "deliverables" FOR ALL USING (current_setting('app.current_user_role', true) IN ('ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND engineer_id = current_setting('app.current_user_id', true)::uuid) WITH CHECK (current_setting('app.current_user_role', true) IN ('ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND engineer_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE "chat_messages" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "chat_messages" FORCE ROW LEVEL SECURITY;
CREATE POLICY chat_messages_admin ON "chat_messages" FOR ALL USING (current_setting('app.current_user_role', true) = 'ADMIN') WITH CHECK (current_setting('app.current_user_role', true) = 'ADMIN');
CREATE POLICY chat_messages_employee ON "chat_messages" FOR ALL USING (current_setting('app.current_user_role', true) IN ('BD_AGENT','ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND EXISTS (SELECT 1 FROM chat_threads t WHERE t.id = thread_id AND t.employee_id = current_setting('app.current_user_id', true)::uuid)) WITH CHECK (current_setting('app.current_user_role', true) IN ('BD_AGENT','ESTIMATION_ENGINEER','DESIGN_ENGINEER') AND sender_id = current_setting('app.current_user_id', true)::uuid AND EXISTS (SELECT 1 FROM chat_threads t WHERE t.id = thread_id AND t.employee_id = current_setting('app.current_user_id', true)::uuid));

ALTER TABLE "notifications" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "notifications" FORCE ROW LEVEL SECURITY;
CREATE POLICY notifications_own ON "notifications" FOR ALL USING (user_id = current_setting('app.current_user_id', true)::uuid) WITH CHECK (user_id = current_setting('app.current_user_id', true)::uuid);

CREATE INDEX IF NOT EXISTS idx_projects_status_updated ON projects(status, updated_at);
CREATE INDEX IF NOT EXISTS idx_delivery_logs_project_success ON client_delivery_log(project_id, success, sent_at);
