import { PrismaClient, UserRole } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL?.trim().toLowerCase();
  const adminPassword = process.env.SEED_ADMIN_PASSWORD;

  if (!adminEmail || !adminPassword || adminPassword.length < 14) {
    throw new Error('SEED_ADMIN_EMAIL and SEED_ADMIN_PASSWORD (minimum 14 characters) are required to seed the administrator.');
  }

  const existing = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existing) {
    await prisma.user.create({
      data: {
        fullName: process.env.SEED_ADMIN_NAME || 'System Administrator',
        email: adminEmail,
        passwordHash: await bcrypt.hash(adminPassword, 12),
        role: UserRole.ADMIN,
        totpSecret: process.env.SEED_ADMIN_TOTP_SECRET || null,
      },
    });
    console.log(`Administrator created: ${adminEmail}`);
  } else if (existing.role !== UserRole.ADMIN) {
    throw new Error('SEED_ADMIN_EMAIL belongs to a non-admin user. Refusing to alter an existing account.');
  } else {
    console.log(`Administrator already exists: ${adminEmail}`);
  }

  if (process.env.SEED_DEMO === 'true') {
    const demoUsers = [
      { email: 'bd.demo@portal.local', name: 'Demo BD Agent', role: UserRole.BD_AGENT, password: process.env.SEED_DEMO_PASSWORD || 'DemoOnlyChangeMe123!' },
      { email: 'engineer.demo@portal.local', name: 'Demo Estimation Engineer', role: UserRole.ESTIMATION_ENGINEER, password: process.env.SEED_DEMO_PASSWORD || 'DemoOnlyChangeMe123!' },
    ];
    for (const demo of demoUsers) {
      const exists = await prisma.user.findUnique({ where: { email: demo.email } });
      if (!exists) {
        await prisma.user.create({
          data: { fullName: demo.name, email: demo.email, passwordHash: await bcrypt.hash(demo.password, 12), role: demo.role },
        });
      }
    }
  }
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => prisma.$disconnect());
