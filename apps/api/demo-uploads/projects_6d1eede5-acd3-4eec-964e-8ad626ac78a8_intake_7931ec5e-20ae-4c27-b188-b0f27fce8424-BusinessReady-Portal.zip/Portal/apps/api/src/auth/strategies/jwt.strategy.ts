import { Injectable, UnauthorizedException, OnModuleInit } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) implements OnModuleInit {
  constructor(
    private config: ConfigService,
    private prisma: PrismaService,
  ) {
    const secret = config.get<string>('JWT_SECRET');
    if (!secret) {
      throw new Error('JWT_SECRET environment variable is not set. Refusing to start.');
    }
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: secret,
    });
  }

  onModuleInit() {
    // Validate all required secrets are present at startup
    const required = ['JWT_SECRET', 'JWT_REFRESH_SECRET'] as const;
    for (const key of required) {
      if (!this.config.get<string>(key)) {
        throw new Error(`${key} environment variable is not set. Refusing to start.`);
      }
    }
  }

  async validate(payload: any) {
    if (payload.pre2fa) {
      // Pre-2FA tokens are not valid for authenticated routes
      throw new UnauthorizedException('2FA verification required');
    }
    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, role: true, isActive: true },
    });
    if (!user || !user.isActive) throw new UnauthorizedException();
    return { sub: user.id, role: user.role };
  }
}
