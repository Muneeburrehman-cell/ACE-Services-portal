import {
  Injectable,
  ForbiddenException,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { PrismaService } from '../prisma/prisma.service';
import { UserRole } from '@prisma/client';
import * as crypto from 'crypto';
import * as path from 'path';

const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/png',
  'image/jpeg',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/zip',
  'application/x-zip-compressed',
  // CAD formats (no standard MIME, accept as octet-stream with extension check)
  'application/octet-stream',
  'application/acad',
  'image/vnd.dwg',
];

const ALLOWED_EXTENSIONS = ['.pdf', '.dwg', '.dxf', '.png', '.jpg', '.jpeg', '.xlsx', '.docx', '.zip'];
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100 MB

@Injectable()
export class FilesService {
  private s3: S3Client;
  private bucket: string;

  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
  ) {
    this.s3 = new S3Client({
      region: config.get('AWS_REGION', 'us-east-1'),
      credentials: {
        accessKeyId: config.get('AWS_ACCESS_KEY_ID') || '',
        secretAccessKey: config.get('AWS_SECRET_ACCESS_KEY') || '',
      },
    });
    this.bucket = config.get('AWS_S3_BUCKET') || 'estimation-portal-files';
  }

  async getUploadUrl(dto: {
    projectId: string;
    fileName: string;
    mimeType: string;
    sizeBytes: number;
    fileType: 'intake' | 'deliverable';
  }, user: { sub: string; role: UserRole }) {
    // Validate extension
    const safeOriginalName = path.basename(dto.fileName).trim();
    if (!safeOriginalName || safeOriginalName.length > 500 || safeOriginalName === '.' || safeOriginalName === '..') {
      throw new BadRequestException('Invalid file name');
    }
    const ext = '.' + safeOriginalName.split('.').pop()?.toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      throw new BadRequestException(`File type ${ext} is not allowed`);
    }
    if (!ALLOWED_MIME_TYPES.includes(dto.mimeType)) {
      throw new BadRequestException('File MIME type is not allowed');
    }
    if (dto.sizeBytes > MAX_FILE_SIZE) {
      throw new BadRequestException('File size exceeds 100 MB limit');
    }

    // Validate project access
    await this.assertProjectAccess(dto.projectId, user, dto.fileType);

    const fileId = crypto.randomUUID();
    const s3Key = `projects/${dto.projectId}/${dto.fileType}/${fileId}-${safeOriginalName}`;

    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: s3Key,
      ContentType: dto.mimeType,
      ContentLength: dto.sizeBytes,
      ServerSideEncryption: 'AES256',
    });

    const uploadUrl = await getSignedUrl(this.s3, command, { expiresIn: 60 });
    return { uploadUrl, s3Key, fileId };
  }

  async confirmUpload(dto: {
    projectId: string;
    s3Key: string;
    originalName: string;
    mimeType: string;
    sizeBytes: number;
    fileType: 'intake' | 'deliverable';
  }, user: { sub: string; role: UserRole }) {
    await this.assertProjectAccess(dto.projectId, user, dto.fileType);

    const expectedPrefix = `projects/${dto.projectId}/${dto.fileType}/`;
    if (!dto.s3Key.startsWith(expectedPrefix)) {
      throw new ForbiddenException('Invalid storage object for this project');
    }

    const ext = '.' + dto.originalName.split('.').pop()?.toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) throw new BadRequestException('File extension is not allowed');
    if (!ALLOWED_MIME_TYPES.includes(dto.mimeType)) throw new BadRequestException('File MIME type is not allowed');

    let head: any;
    try {
      head = await this.s3.send(new HeadObjectCommand({ Bucket: this.bucket, Key: dto.s3Key }));
    } catch {
      throw new BadRequestException('File not found in storage. Upload may have failed.');
    }
    if (!head.ContentLength || Number(head.ContentLength) !== dto.sizeBytes) {
      throw new BadRequestException('Uploaded file size does not match the requested upload');
    }
    if (Number(head.ContentLength) > MAX_FILE_SIZE) throw new BadRequestException('File size exceeds 100 MB limit');

    if (dto.fileType === 'intake' && user.role !== UserRole.BD_AGENT) throw new ForbiddenException();
    if (dto.fileType === 'deliverable' && user.role !== UserRole.ESTIMATION_ENGINEER && user.role !== UserRole.DESIGN_ENGINEER) throw new ForbiddenException();

    const existingIntake: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.projectFile.findUnique({ where: { s3Key: dto.s3Key } }));
    const existingDeliverable: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.deliverable.findUnique({ where: { s3Key: dto.s3Key } }));
    if (existingIntake || existingDeliverable) return { id: (existingIntake || existingDeliverable)!.id, originalName: dto.originalName };

    if (dto.fileType === 'intake') {
      const file: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.projectFile.create({
        data: {
          projectId: dto.projectId,
          originalName: dto.originalName,
          s3Key: dto.s3Key,
          mimeType: dto.mimeType,
          sizeBytes: BigInt(dto.sizeBytes),
        },
      }));
      return { id: file.id, originalName: file.originalName };
    } else {
      // deliverable — also update project status
      const deliverable: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.deliverable.create({
        data: {
          projectId: dto.projectId,
          engineerId: user.sub,
          originalName: dto.originalName,
          s3Key: dto.s3Key,
          mimeType: dto.mimeType,
          sizeBytes: BigInt(dto.sizeBytes),
        },
      }));
      return { id: deliverable.id, originalName: deliverable.originalName };
    }
  }

  async getDownloadUrl(
    fileId: string,
    fileType: 'intake' | 'deliverable',
    user: { sub: string; role: UserRole },
  ) {
    let s3Key: string;
    let projectId: string;

    if (fileType === 'intake') {
      const file: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.projectFile.findUnique({ where: { id: fileId } }));
      if (!file) throw new NotFoundException('File not found');
      s3Key = file.s3Key;
      projectId = file.projectId;

      // BD agents cannot access deliverables; check project ownership
      if (user.role === UserRole.BD_AGENT) {
        const project: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.project.findUnique({ where: { id: projectId } }));
        if (!project || project.bdAgentId !== user.sub) throw new ForbiddenException();
      } else if (user.role === UserRole.ESTIMATION_ENGINEER || user.role === UserRole.DESIGN_ENGINEER) {
        const project: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.project.findUnique({ where: { id: projectId } }));
        if (!project || project.assignedTo !== user.sub) throw new ForbiddenException();
      }
    } else {
      // deliverable
      if (user.role === UserRole.BD_AGENT) throw new ForbiddenException();

      const deliverable: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.deliverable.findUnique({ where: { id: fileId } }));
      if (!deliverable) throw new NotFoundException('Deliverable not found');
      s3Key = deliverable.s3Key;
      projectId = deliverable.projectId;

      if (user.role === UserRole.ESTIMATION_ENGINEER || user.role === UserRole.DESIGN_ENGINEER) {
        if (deliverable.engineerId !== user.sub) throw new ForbiddenException();
      }
    }

    const command = new GetObjectCommand({ Bucket: this.bucket, Key: s3Key });
    const url = await getSignedUrl(this.s3, command, { expiresIn: 3600 }); // 60 min
    return { url };
  }

  async deleteFile(fileId: string, fileType: 'intake' | 'deliverable', adminId: string) {
    if (fileType === 'intake') {
      const file: any = await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.projectFile.findUnique({ where: { id: fileId } }));
      if (!file) throw new NotFoundException();
      await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: file.s3Key }));
      await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.projectFile.delete({ where: { id: fileId } }));
    } else {
      const file: any = await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.deliverable.findUnique({ where: { id: fileId } }));
      if (!file) throw new NotFoundException();
      await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: file.s3Key }));
      await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.deliverable.delete({ where: { id: fileId } }));
    }
    return { success: true };
  }

  async getDeliverablesByProject(projectId: string) {
    return this.prisma.deliverable.findMany({ where: { projectId } });
  }

  async getSignedUrlForDelivery(s3Key: string, expiresIn: number) {
    const command = new GetObjectCommand({ Bucket: this.bucket, Key: s3Key });
    return getSignedUrl(this.s3, command, { expiresIn });
  }

  async getDeliverableStream(s3Key: string) {
    const response = await this.s3.send(
      new GetObjectCommand({ Bucket: this.bucket, Key: s3Key }),
    );
    return response.Body;
  }

  private async assertProjectAccess(
    projectId: string,
    user: { sub: string; role: UserRole },
    fileType: 'intake' | 'deliverable',
  ) {
    const project: any = await this.prisma.withRlsContext(user.sub, user.role, (tx: any) => tx.project.findUnique({ where: { id: projectId } }));
    if (!project) throw new NotFoundException('Project not found');

    if (user.role === UserRole.BD_AGENT) {
      if (fileType !== 'intake') throw new ForbiddenException();
      if (project.bdAgentId !== user.sub) throw new ForbiddenException();
    } else if (user.role === UserRole.ESTIMATION_ENGINEER || user.role === UserRole.DESIGN_ENGINEER) {
      if (fileType !== 'deliverable') throw new ForbiddenException();
      if (project.assignedTo !== user.sub) throw new ForbiddenException();
    } else if (user.role !== UserRole.ADMIN) {
      throw new ForbiddenException();
    }
  }
}
