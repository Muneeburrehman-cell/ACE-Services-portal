import { Test, TestingModule } from '@nestjs/testing';
import { ProjectsService } from './projects.service';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { UserRole, ProjectStatus } from '@prisma/client';

// ── Minimal mocks ──────────────────────────────────────────────────────────

const makeMockPrisma = () => ({
  project: {
    create: jest.fn(),
    findUnique: jest.fn(),
    findMany: jest.fn(),
    count: jest.fn(),
    update: jest.fn(),
  },
  projectStatusHistory: { create: jest.fn() },
  user: { findUnique: jest.fn() },
  $transaction: jest.fn((ops: any) => {
    if (Array.isArray(ops)) return Promise.all(ops);
    return ops(makeMockPrisma());
  }),
  $queryRaw: jest.fn().mockResolvedValue([{ nextval: 1n }]),
  $executeRawUnsafe: jest.fn().mockResolvedValue(null),
  withRlsContext: jest.fn((_uid: string, _role: string, fn: any) => fn({
    project: { findUnique: jest.fn(), findMany: jest.fn(), count: jest.fn() },
    chatThread: { findUnique: jest.fn() },
    chatMessage: { findMany: jest.fn(), count: jest.fn() },
  })),
});

const mockAudit = { log: jest.fn() };
const mockNotifications = { notifyUser: jest.fn(), notifyAdmin: jest.fn() };

// ── Helpers ────────────────────────────────────────────────────────────────

const adminUser = { sub: 'admin-id', role: UserRole.ADMIN };
const bdUser    = { sub: 'bd-id',    role: UserRole.BD_AGENT };
const engUser   = { sub: 'eng-id',   role: UserRole.ESTIMATION_ENGINEER };

const makeProject = (overrides: Partial<any> = {}) => ({
  id: 'proj-id',
  referenceNumber: 'PRJ-2026-0001',
  bdAgentId: 'bd-id',
  assignedTo: null,
  status: ProjectStatus.received,
  clientName: 'ACME Corp',
  clientEmail: 'client@acme.com',
  clientPhone: '+1-555-0000',
  scopeDescription: 'Build a house',
  requestedDeadline: new Date('2026-12-01'),
  submittedAt: new Date(),
  internalDeadline: null,
  priority: null,
  adminInstructions: null,
  projectType: null,
  bdAgent: { fullName: 'BD Bob' },
  assignedEngineer: null,
  files: [],
  deliverables: [],
  statusHistory: [],
  ...overrides,
});

// ── Tests ──────────────────────────────────────────────────────────────────

describe('ProjectsService — access control', () => {
  let service: ProjectsService;
  let prisma: ReturnType<typeof makeMockPrisma>;

  beforeEach(async () => {
    jest.clearAllMocks();
    prisma = makeMockPrisma();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ProjectsService,
        { provide: PrismaService, useValue: prisma },
        { provide: AuditService, useValue: mockAudit },
        { provide: NotificationsService, useValue: mockNotifications },
      ],
    }).compile();

    service = module.get<ProjectsService>(ProjectsService);
  });

  // ── BD agent isolation ───────────────────────────────────────────────────

  describe('findOne — BD agent isolation', () => {
    it('throws ForbiddenException when BD agent requests another BD agent\'s project', async () => {
      const otherBdProject = makeProject({ bdAgentId: 'other-bd-id' });
      // withRlsContext calls the callback with a tx mock
      prisma.withRlsContext.mockImplementation((_u: any, _r: any, fn: any) =>
        fn({ project: { findUnique: jest.fn().mockResolvedValue(otherBdProject) } }),
      );

      await expect(
        service.findOne('proj-id', { sub: 'bd-id', role: UserRole.BD_AGENT }),
      ).rejects.toThrow(ForbiddenException);
    });

    it('returns BD-scoped view (status always "Received", no engineer data)', async () => {
      const ownProject = makeProject({ bdAgentId: 'bd-id', status: ProjectStatus.delivered });
      prisma.withRlsContext.mockImplementation((_u: any, _r: any, fn: any) =>
        fn({ project: { findUnique: jest.fn().mockResolvedValue(ownProject) } }),
      );

      const result: any = await service.findOne('proj-id', bdUser);
      expect(result.status).toBe('Received');
      expect(result).not.toHaveProperty('clientEmail');
      expect(result).not.toHaveProperty('assignedEngineer');
    });
  });

  // ── Engineer isolation ───────────────────────────────────────────────────

  describe('findOne — Engineer isolation', () => {
    it('throws ForbiddenException when engineer requests project assigned to someone else', async () => {
      const otherEngProject = makeProject({ assignedTo: 'other-eng-id' });
      prisma.withRlsContext.mockImplementation((_u: any, _r: any, fn: any) =>
        fn({ project: { findUnique: jest.fn().mockResolvedValue(otherEngProject) } }),
      );

      await expect(
        service.findOne('proj-id', { sub: 'eng-id', role: UserRole.ESTIMATION_ENGINEER }),
      ).rejects.toThrow(ForbiddenException);
    });

    it('returns engineer-scoped view — no client fields present', async () => {
      const assignedProject = makeProject({ assignedTo: 'eng-id', status: ProjectStatus.assigned });
      prisma.withRlsContext.mockImplementation((_u: any, _r: any, fn: any) =>
        fn({ project: { findUnique: jest.fn().mockResolvedValue(assignedProject) } }),
      );

      const result: any = await service.findOne('proj-id', engUser);
      expect(result).not.toHaveProperty('clientName');
      expect(result).not.toHaveProperty('clientEmail');
      expect(result).not.toHaveProperty('clientPhone');
      expect(result).not.toHaveProperty('bdAgentName');
      expect(result.scopeDescription).toBeDefined();
    });
  });

  // ── Admin full view ──────────────────────────────────────────────────────

  describe('findOne — Admin full view', () => {
    it('returns all fields including client contact info', async () => {
      const project = makeProject({ assignedTo: 'eng-id' });
      prisma.withRlsContext.mockImplementation((_u: any, _r: any, fn: any) =>
        fn({ project: { findUnique: jest.fn().mockResolvedValue(project) } }),
      );

      const result: any = await service.findOne('proj-id', adminUser);
      expect(result.clientName).toBe('ACME Corp');
      expect(result.clientEmail).toBe('client@acme.com');
      expect(result.clientPhone).toBeDefined();
      expect(result.bdAgentName).toBe('BD Bob');
    });
  });

  // ── BD status always "Received" ──────────────────────────────────────────

  it('BD agent sees status as "Received" regardless of internal status', async () => {
    for (const internalStatus of Object.values(ProjectStatus)) {
      const project = makeProject({ bdAgentId: 'bd-id', status: internalStatus });
      prisma.withRlsContext.mockImplementation((_u: any, _r: any, fn: any) =>
        fn({ project: { findUnique: jest.fn().mockResolvedValue(project) } }),
      );
      const result: any = await service.findOne('proj-id', bdUser);
      expect(result.status).toBe('Received');
    }
  });

  // ── Assignment ───────────────────────────────────────────────────────────

  describe('assign', () => {
    it('throws BadRequestException when engineerId belongs to a non-engineer', async () => {
      prisma.project.findUnique.mockResolvedValue(makeProject());
      prisma.user.findUnique.mockResolvedValue({
        id: 'admin-id', role: UserRole.ADMIN, isActive: true,
      });

      await expect(
        service.assign('proj-id', {
          engineerId: 'admin-id',
          internalDeadline: '2026-12-01',
          priority: 'high' as any,
          projectType: 'estimation',
        }, 'admin-id'),
      ).rejects.toThrow();
    });

    it('records assignment and notifies engineer on success', async () => {
      const project = makeProject();
      prisma.project.findUnique.mockResolvedValue(project);
      prisma.user.findUnique.mockResolvedValue({
        id: 'eng-id', role: UserRole.ESTIMATION_ENGINEER, isActive: true,
      });
      prisma.$transaction.mockImplementation(async (fn: any) => fn(prisma));
      prisma.project.update.mockResolvedValue({});
      prisma.projectStatusHistory.create.mockResolvedValue({});

      await service.assign('proj-id', {
        engineerId: 'eng-id',
        internalDeadline: '2026-12-01',
        priority: 'high' as any,
        projectType: 'estimation',
      }, 'admin-id');

      expect(mockNotifications.notifyUser).toHaveBeenCalledWith(
        'eng-id',
        'PROJECT_ASSIGNED',
        expect.any(Object),
      );
      expect(mockAudit.log).toHaveBeenCalledWith(
        expect.objectContaining({ eventType: 'PROJECT_ASSIGNED' }),
      );
    });
  });
});
