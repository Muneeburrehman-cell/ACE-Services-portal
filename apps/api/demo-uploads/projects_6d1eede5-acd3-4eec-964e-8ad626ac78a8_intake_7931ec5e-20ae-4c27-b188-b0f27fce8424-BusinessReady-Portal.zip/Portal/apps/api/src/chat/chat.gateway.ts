import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { ChatService } from './chat.service';
import { UserRole } from '@prisma/client';

@WebSocketGateway({ namespace: '/chat', cors: { origin: process.env.APP_BASE_URL || 'http://localhost:3000', credentials: true } })
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  constructor(
    private jwtService: JwtService,
    private config: ConfigService,
    private chatService: ChatService,
  ) {}

  async handleConnection(socket: Socket) {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.query?.token;
      const payload = this.jwtService.verify(token as string, {
        secret: this.config.get('JWT_SECRET'),
      });
      socket.data.user = payload;

      if (payload.role === UserRole.ADMIN) {
        const threadIds = await this.chatService.getAllThreadIds();
        threadIds.forEach((id) => socket.join(`thread:${id}`));
        // Send thread list to admin
        const threads = await this.chatService.getAllThreadsWithPreview();
        socket.emit('thread_list', threads);
      } else {
        const thread: any = await this.chatService.getOrCreateThread(payload.sub, payload.role);
        socket.join(`thread:${thread.id}`);
        socket.data.threadId = thread.id;
      }

      socket.join(`user:${payload.sub}`);
    } catch {
      socket.disconnect();
    }
  }

  handleDisconnect(_socket: Socket) {}

  @SubscribeMessage('send_message')
  async handleMessage(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: { content: string; threadId?: string },
  ) {
    const user = socket.data.user;
    const threadId = user.role === UserRole.ADMIN ? data.threadId : socket.data.threadId;

    if (!threadId) return;

    const message = await this.chatService.sendMessage(
      threadId,
      user.sub,
      user.role,
      data.content,
    );

    // Emit to all sockets in the room (both parties)
    this.server.to(`thread:${threadId}`).emit('new_message', message);
  }

  @SubscribeMessage('mark_read')
  async handleMarkRead(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: { message_id: string },
  ) {
    const user = socket.data.user;
    await this.chatService.markRead(data.message_id, user.sub, user.role);
  }
}
