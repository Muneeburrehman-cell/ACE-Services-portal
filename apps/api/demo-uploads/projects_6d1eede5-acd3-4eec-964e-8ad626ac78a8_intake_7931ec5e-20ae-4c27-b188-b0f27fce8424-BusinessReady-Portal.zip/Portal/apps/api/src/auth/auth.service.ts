import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ForbiddenException,
  InternalServerErrorException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import * as speakeasy from 'speakeasy';
import * as QRCode from 'qrcode';
import { AuditEventType, UserRole } from '@prisma/client';
import * as sgMail from '@sendgrid/mail';
const sg = sgMail as any;

const LOGIN_LOCKOUT_ATTEMPTS = 5;   // applies to ALL roles
const LOGIN_LOCKOUT_MINUTES = 15;
const TWO_FA_LOCKOUT_ATTEMPTS = 3;  // Admin TOTP failures
const TWO_FA_LOCKOUT_MINUTES = 30;

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private config: ConfigService,
    private audit: AuditService,
  ) {
    sg.setApiKey(this.config.get<string>('SENDGRID_API_KEY') ?? '');
  }

  async login(email: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });

    if (!user || !user.isActive) {
      await this.audit.log({
        eventType: AuditEventType.USER_LOGIN_FAILURE,
        metadata: { email, reason: 'user_not_found_or_inactive' },
      });
      throw new UnauthorizedException('Invalid credentials');
    }

    // Check lockout — applies to ALL roles (extended from Admin-only)
    if (user.lockoutUntil && user.lockoutUntil > new Date()) {
      const remainingMs = user.lockoutUntil.getTime() - Date.now();
      const remainingMin = Math.ceil(remainingMs / 60000);
      throw new ForbiddenException(`Account locked. Try again in ${remainingMin} minute(s).`);
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      // Increment failed login counter for ALL roles
      const newCount = (user.failed2faCount ?? 0) + 1;
      const update: any = { failed2faCount: newCount };
      if (newCount >= LOGIN_LOCKOUT_ATTEMPTS) {
        update.lockoutUntil = new Date(Date.now() + LOGIN_LOCKOUT_MINUTES * 60 * 1000);
        update.failed2faCount = 0;
        await this.sendEmail(
          user.email,
          'Account Locked',
          `Your account has been locked for ${LOGIN_LOCKOUT_MINUTES} minutes after ${LOGIN_LOCKOUT_ATTEMPTS} failed login attempts.`,
        );
      }
      await this.prisma.user.update({ where: { id: user.id }, data: update });

      await this.audit.log({
        eventType: AuditEventType.USER_LOGIN_FAILURE,
        actorId: user.id,
        actorRole: user.role,
        metadata: { reason: 'wrong_password', failCount: newCount },
      });
      throw new UnauthorizedException('Invalid credentials');
    }

    // Reset failure counter on successful password
    if (user.failed2faCount > 0) {
      await this.prisma.user.update({
        where: { id: user.id },
        data: { failed2faCount: 0 },
      });
    }

    // Admin requires 2FA
    if (user.role === UserRole.ADMIN) {
      if (!user.totpSecret) {
        throw new ForbiddenException('Admin 2FA not configured. Contact system administrator.');
      }
      // Pre-2FA token — NOT a full session token; rejected by JwtStrategy.validate
      const jwtSecret = this.config.get<string>('JWT_SECRET');
      if (!jwtSecret) throw new InternalServerErrorException('Server misconfigured');
      const pre2faToken = this.jwtService.sign(
        { sub: user.id, role: user.role, pre2fa: true },
        { expiresIn: '5m', secret: jwtSecret },
      );
      return { requires2fa: true, pre2faToken };
    }

    await this.audit.log({
      eventType: AuditEventType.USER_LOGIN_SUCCESS,
      actorId: user.id,
      actorRole: user.role,
    });

    return this.issueTokens(user.id, user.role);
  }

  async verify2fa(pre2faToken: string, totpCode: string) {
    const jwtSecret = this.config.get<string>('JWT_SECRET');
    if (!jwtSecret) throw new InternalServerErrorException('Server misconfigured');

    let payload: any;
    try {
      payload = this.jwtService.verify(pre2faToken, { secret: jwtSecret });
    } catch {
      throw new UnauthorizedException('Invalid or expired token');
    }

    if (!payload.pre2fa) throw new UnauthorizedException('Invalid token type');

    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || !user.isActive) throw new UnauthorizedException();

    if (user.lockoutUntil && user.lockoutUntil > new Date()) {
      throw new ForbiddenException('Account temporarily locked.');
    }

    const valid = speakeasy.totp.verify({
      secret: user.totpSecret!,
      encoding: 'base32',
      token: totpCode,
      window: 1,
    });

    if (!valid) {
      const newCount = user.failed2faCount + 1;
      const update: any = { failed2faCount: newCount };

      if (newCount >= TWO_FA_LOCKOUT_ATTEMPTS) {
        update.lockoutUntil = new Date(Date.now() + TWO_FA_LOCKOUT_MINUTES * 60 * 1000);
        update.failed2faCount = 0;
        await this.sendLockoutEmail(user.email);
      }
      await this.prisma.user.update({ where: { id: user.id }, data: update });
      throw new UnauthorizedException('Invalid 2FA code');
    }

    // Reset counter on success
    await this.prisma.user.update({
      where: { id: user.id },
      data: { failed2faCount: 0, lockoutUntil: null },
    });

    await this.audit.log({
      eventType: AuditEventType.USER_LOGIN_SUCCESS,
      actorId: user.id,
      actorRole: user.role,
    });

    return this.issueTokens(user.id, user.role);
  }

  async setup2fa(userId: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    const secret = speakeasy.generateSecret({
      name: `Estimation Portal (${user.email})`,
      length: 20,
    });

    await this.prisma.user.update({
      where: { id: userId },
      data: { totpSecret: secret.base32 },
    });

    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url!);
    return { secret: secret.base32, qrCode: qrCodeUrl };
  }

  async confirm2faSetup(userId: string, totpCode: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.totpSecret) throw new BadRequestException('2FA setup not started');

    const valid = speakeasy.totp.verify({
      secret: user.totpSecret,
      encoding: 'base32',
      token: totpCode,
      window: 1,
    });

    if (!valid) throw new BadRequestException('Invalid TOTP code');
    return { success: true };
  }

  async refresh(refreshToken: string) {
    const tokenHash = this.hashToken(refreshToken);
    const stored = await this.prisma.refreshToken.findUnique({
      where: { tokenHash },
      include: { user: true },
    });

    if (!stored || stored.revoked || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid refresh token');
    }

    if (!stored.user.isActive) throw new UnauthorizedException();

    const claimed = await this.prisma.refreshToken.updateMany({
      where: { id: stored.id, revoked: false, expiresAt: { gt: new Date() } },
      data: { revoked: true },
    });
    if (claimed.count !== 1) throw new UnauthorizedException('Invalid refresh token');

    return this.issueTokens(stored.user.id, stored.user.role);
  }

  async logout(refreshToken: string) {
    const tokenHash = this.hashToken(refreshToken);
    await this.prisma.refreshToken.updateMany({
      where: { tokenHash },
      data: { revoked: true },
    });
  }

  async forgotPassword(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    // Always return — never leak whether email exists
    if (!user || !user.isActive) return;

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = this.hashToken(rawToken);

    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      },
    });

    await this.audit.log({
      eventType: AuditEventType.PASSWORD_RESET_REQUEST,
      actorId: user.id,
      actorRole: user.role,
    });

    const resetUrl = `${this.config.get<string>('APP_BASE_URL')}/reset-password?token=${rawToken}`;
    await this.sendEmail(
      user.email,
      'Password Reset Request',
      `Click to reset your password: ${resetUrl}\n\nThis link expires in 60 minutes.`,
    );
  }

  async resetPassword(rawToken: string, newPassword: string) {
    const tokenHash = this.hashToken(rawToken);
    const record = await this.prisma.passwordResetToken.findUnique({
      where: { tokenHash },
      include: { user: true },
    });

    if (!record || record.used || record.expiresAt < new Date()) {
      throw new BadRequestException('Invalid or expired reset link');
    }

    const passwordHash = await bcrypt.hash(newPassword, 12);

    await this.prisma.$transaction([
      this.prisma.user.update({
        where: { id: record.userId },
        data: { passwordHash },
      }),
      this.prisma.passwordResetToken.update({
        where: { id: record.id },
        data: { used: true },
      }),
      this.prisma.refreshToken.updateMany({
        where: { userId: record.userId },
        data: { revoked: true },
      }),
    ]);

    await this.audit.log({
      eventType: AuditEventType.PASSWORD_RESET_COMPLETE,
      actorId: record.userId,
      actorRole: record.user.role,
    });
  }

  private async issueTokens(userId: string, role: UserRole) {
    const jwtSecret = this.config.get<string>('JWT_SECRET');
    if (!jwtSecret) throw new InternalServerErrorException('Server misconfigured');

    const payload = { sub: userId, role };
    const accessToken = this.jwtService.sign(payload, { secret: jwtSecret });

    const rawRefresh = crypto.randomBytes(40).toString('hex');
    const tokenHash = this.hashToken(rawRefresh);

    await this.prisma.refreshToken.create({
      data: {
        userId,
        tokenHash,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return { accessToken, refreshToken: rawRefresh, role };
  }

  hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  private async sendLockoutEmail(email: string) {
    const adminEmail = this.config.get<string>('ADMIN_EMAIL');
    await this.sendEmail(
      adminEmail ?? email,
      'Admin Account Locked',
      `The Admin account (${email}) has been locked for ${TWO_FA_LOCKOUT_MINUTES} minutes after ${TWO_FA_LOCKOUT_ATTEMPTS} failed 2FA attempts.`,
    );
  }

  async sendEmail(to: string, subject: string, text: string) {
    try {
      const from = this.config.get<string>('SENDGRID_FROM_EMAIL') ?? 'noreply@portal.com';
      await sg.send({ to, from, subject, text });
    } catch (err) {
      console.error('Email send failed:', err);
    }
  }
}
