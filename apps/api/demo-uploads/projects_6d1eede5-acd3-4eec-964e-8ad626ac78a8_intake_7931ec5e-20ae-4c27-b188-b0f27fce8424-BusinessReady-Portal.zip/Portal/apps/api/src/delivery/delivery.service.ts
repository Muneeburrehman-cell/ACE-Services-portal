import { Injectable, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { FilesService } from '../files/files.service';
import { AuditEventType, ProjectStatus, UserRole } from '@prisma/client';
import * as sgMail from '@sendgrid/mail';
const sg = sgMail as any;

const MAX_ATTACHMENT_SIZE = 25 * 1024 * 1024; // 25 MB

@Injectable()
export class DeliveryService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
    private files: FilesService,
    private config: ConfigService,
  ) {
    sg.setApiKey(config.get('SENDGRID_API_KEY') || '');
  }

  async getPreview(projectId: string, adminId: string) {
    const project: any = await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.project.findUnique({
      where: { id: projectId },
      include: { deliverables: true },
    }));
    if (!project) throw new NotFoundException();
    if (project.status !== ProjectStatus.delivered) {
      throw new BadRequestException('Project is not in delivered status');
    }

    if (project.deliverables.length === 0) throw new BadRequestException('No deliverables are available for delivery');
    const totalSize = project.deliverables.reduce((acc, d) => acc + Number(d.sizeBytes), 0);
    const canAttach = totalSize <= MAX_ATTACHMENT_SIZE;

    return {
      to: project.clientEmail,
      subject: `Your Project ${project.referenceNumber} is Ready`,
      body: this.buildEmailBody(project, null),
      deliveryMethod: canAttach ? 'attachment' : 'link',
      totalDeliverableSize: totalSize,
    };
  }

  async sendToClient(
    projectId: string,
    dto: { subject: string; body: string; deliveryMethod: 'attachment' | 'link' },
    adminId: string,
  ) {
    const project: any = await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.project.findUnique({
      where: { id: projectId },
      include: { deliverables: true },
    }));
    if (!project) throw new NotFoundException();
    if (project.deliverables.length === 0) throw new BadRequestException('No deliverables are available for delivery');

    const claim: any = await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.project.updateMany({
      where: { id: projectId, status: ProjectStatus.delivered },
      data: { status: ProjectStatus.delivery_in_progress },
    }));
    if (claim.count !== 1) throw new BadRequestException('Project is already being delivered or has already been sent');

    const recipientEmail = project.clientEmail; // Source of truth — never from user input
    let success = false;
    let errorMessage: string | undefined;

    try {
      const msg: any = {
        to: recipientEmail,
        from: this.config.get('SENDGRID_FROM_EMAIL') || 'noreply@portal.com',
        subject: dto.subject,
        text: dto.body,
        // No employee info included
      };

      if (dto.deliveryMethod === 'attachment') {
        const totalSize = project.deliverables.reduce((a, d) => a + Number(d.sizeBytes), 0);
        if (totalSize > MAX_ATTACHMENT_SIZE) {
          throw new BadRequestException('Total size exceeds 25 MB. Use link delivery instead.');
        }

        const attachments = await Promise.all(
          project.deliverables.map(async (d) => {
            const stream = await this.files.getDeliverableStream(d.s3Key);
            const chunks: Buffer[] = [];
            for await (const chunk of stream as any) {
              chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
            }
            return {
              content: Buffer.concat(chunks).toString('base64'),
              filename: d.originalName,
              type: d.mimeType,
              disposition: 'attachment',
            };
          }),
        );
        msg.attachments = attachments;
      } else {
        // Generate 72-hour signed links
        const links = await Promise.all(
          project.deliverables.map(async (d) => {
            const url = await this.files.getSignedUrlForDelivery(d.s3Key, 72 * 3600);
            return `${d.originalName}: ${url}`;
          }),
        );
        msg.text += '\n\nDownload your files (links expire in 72 hours):\n' + links.join('\n');
      }

      await sg.send(msg);
      success = true;
    } catch (err: any) {
      errorMessage = err.message;
    }

    // Log delivery attempt
    await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.clientDeliveryLog.create({
      data: {
        projectId,
        sentBy: adminId,
        recipientEmail,
        subject: dto.subject,
        deliveryMethod: dto.deliveryMethod,
        success,
        errorMessage: errorMessage ?? null,
      },
    }));

    await this.audit.log({
      eventType: success ? AuditEventType.SEND_TO_CLIENT_SUCCESS : AuditEventType.SEND_TO_CLIENT_FAILURE,
      actorId: adminId,
      actorRole: UserRole.ADMIN,
      targetId: projectId,
      metadata: { recipientEmail, deliveryMethod: dto.deliveryMethod, success, errorMessage },
    });

    if (!success) {
      await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.project.update({ where: { id: projectId }, data: { status: ProjectStatus.delivered } }));
      throw new BadRequestException(`Failed to send email: ${errorMessage}`);
    }

    // Update project status
    await this.prisma.withRlsContext(adminId, UserRole.ADMIN, async (tx: any) => {
      await tx.project.update({ where: { id: projectId }, data: { status: ProjectStatus.sent_to_client } });
      await tx.projectStatusHistory.create({ data: { projectId, fromStatus: ProjectStatus.delivery_in_progress, toStatus: ProjectStatus.sent_to_client, changedBy: adminId } });
    });

    return { success: true, sentTo: recipientEmail };
  }

  private buildEmailBody(project: any, downloadUrl: string | null): string {
    const companyName = this.config.get('COMPANY_NAME') || 'Estimation Company';
    return `Dear ${project.clientName},\n\nYour project (Reference: ${project.referenceNumber}) has been completed and is ready for delivery.\n\n${downloadUrl ? `Download your files here: ${downloadUrl}\n\nThis link expires in 72 hours.` : 'Please find the files attached.'}\n\nBest regards,\n${companyName}`;
  }
}
