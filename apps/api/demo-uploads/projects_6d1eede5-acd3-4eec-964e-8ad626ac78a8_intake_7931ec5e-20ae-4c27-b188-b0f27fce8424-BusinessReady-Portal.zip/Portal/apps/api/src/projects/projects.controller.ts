import {
  Controller, Get, Post, Patch, Body, Param, Query, UseGuards, Req,
} from '@nestjs/common';
import { ProjectsService } from './projects.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '@prisma/client';
import { CreateProjectDto } from './dto/create-project.dto';
import { AssignProjectDto } from './dto/assign-project.dto';

@Controller('projects')
@UseGuards(JwtAuthGuard)
export class ProjectsController {
  constructor(private projects: ProjectsService) {}

  @Post()
  @UseGuards(RolesGuard)
  @Roles(UserRole.BD_AGENT)
  create(@Body() dto: CreateProjectDto, @Req() req: any) {
    return this.projects.create(dto, req.user.sub);
  }

  @Post(':id/submit')
  @UseGuards(RolesGuard)
  @Roles(UserRole.BD_AGENT)
  submit(@Param('id') id: string, @Req() req: any) {
    return this.projects.submit(id, req.user.sub);
  }

  @Get()
  findAll(@Req() req: any, @Query() query: any) {
    return this.projects.findAll(req.user, query);
  }

  @Get(':id')
  findOne(@Param('id') id: string, @Req() req: any) {
    return this.projects.findOne(id, req.user);
  }

  @Patch(':id/assign')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ADMIN)
  assign(@Param('id') id: string, @Body() dto: AssignProjectDto, @Req() req: any) {
    return this.projects.assign(id, dto, req.user.sub);
  }

  @Patch(':id/reassign')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ADMIN)
  reassign(@Param('id') id: string, @Body() dto: AssignProjectDto, @Req() req: any) {
    return this.projects.assign(id, dto, req.user.sub);
  }

  @Patch(':id/status-in-progress')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ESTIMATION_ENGINEER, UserRole.DESIGN_ENGINEER)
  markInProgress(@Param('id') id: string, @Req() req: any) {
    return this.projects.updateStatusToInProgress(id, req.user.sub, req.user.role);
  }

  @Patch(':id/mark-delivered')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ESTIMATION_ENGINEER, UserRole.DESIGN_ENGINEER)
  markDelivered(@Param('id') id: string, @Req() req: any) {
    return this.projects.markDelivered(id, req.user.sub, req.user.role);
  }

  @Get(':id/status-history')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ADMIN)
  getStatusHistory(@Param('id') id: string, @Req() req: any) {
    return this.projects.getStatusHistory(id, req.user.sub);
  }
}
