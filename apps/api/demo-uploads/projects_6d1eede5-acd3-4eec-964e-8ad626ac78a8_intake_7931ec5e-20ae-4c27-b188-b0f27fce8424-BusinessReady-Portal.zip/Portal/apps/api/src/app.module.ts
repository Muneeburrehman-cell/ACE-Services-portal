import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ProjectsModule } from './projects/projects.module';
import { FilesModule } from './files/files.module';
import { ChatModule } from './chat/chat.module';
import { NotificationsModule } from './notifications/notifications.module';
import { DeliveryModule } from './delivery/delivery.module';
import { AuditModule } from './audit/audit.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(),
    // Named throttle tiers — referenced via @Throttle({ tier: { ttl, limit } })
    ThrottlerModule.forRoot([
      // default: general API — 100 req / 60 s
      { name: 'default', ttl: 60_000, limit: 100 },
      // auth: login / password-reset — 10 req / 15 min
      { name: 'auth', ttl: 15 * 60_000, limit: 10 },
    ]),
    PrismaModule,
    AuthModule,
    UsersModule,
    ProjectsModule,
    FilesModule,
    ChatModule,
    NotificationsModule,
    DeliveryModule,
    AuditModule,
  ],
  providers: [
    // Apply default throttle globally; auth endpoints override with 'auth' tier
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
