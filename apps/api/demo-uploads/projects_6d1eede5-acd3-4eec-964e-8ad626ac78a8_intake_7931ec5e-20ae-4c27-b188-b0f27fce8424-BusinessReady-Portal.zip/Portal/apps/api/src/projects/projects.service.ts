import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { AuditEventType, ProjectStatus, UserRole } from '@prisma/client';
import { CreateProjectDto } from './dto/create-project.dto';
import { AssignProjectDto } from './dto/assign-project.dto';

@Injectable()
export class ProjectsService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
    private notifications: NotificationsService,
  ) {}

  async create(dto: CreateProjectDto, bdAgentId: string) {
    const referenceNumber = await this.generateReferenceNumber();
    const project: any = await this.prisma.withRlsContext(bdAgentId, UserRole.BD_AGENT, async (tx: any) => {
      const p = await tx.project.create({
        data: {
          referenceNumber,
          bdAgentId,
          clientName: dto.clientName,
          clientEmail: dto.clientEmail,
          clientPhone: dto.clientPhone,
          scopeDescription: dto.scopeDescription,
          requestedDeadline: new Date(dto.requestedDeadline),
          status: ProjectStatus.draft,
        },
      });
      await tx.projectStatusHistory.create({
        data: { projectId: p.id, fromStatus: null, toStatus: ProjectStatus.draft, changedBy: bdAgentId },
      });
      return p;
    });
    return project;
  }

  async submit(projectId: string, bdAgentId: string) {
    const project: any = await this.prisma.withRlsContext(bdAgentId, UserRole.BD_AGENT, (tx: any) => tx.project.findUnique({
      where: { id: projectId }, include: { files: { select: { id: true } } },
    }));
    if (!project || project.bdAgentId !== bdAgentId) throw new ForbiddenException();
    if (project.status !== ProjectStatus.draft) {
      throw new BadRequestException('Project has already been submitted');
    }
    if (project.files.length < 1) {
      throw new BadRequestException('At least one project file is required before submission');
    }

    const submitted: any = await this.prisma.withRlsContext(bdAgentId, UserRole.BD_AGENT, async (tx: any) => {
      const result = await tx.project.updateMany({
        where: { id: projectId, bdAgentId: bdAgentId, status: ProjectStatus.draft },
        data: { status: ProjectStatus.received },
      });
      if (result.count !== 1) throw new BadRequestException('Project submission could not be completed');
      await tx.projectStatusHistory.create({
        data: { projectId, fromStatus: ProjectStatus.draft, toStatus: ProjectStatus.received, changedBy: bdAgentId },
      });
      return tx.project.findUniqueOrThrow({ where: { id: projectId } });
    });

    await this.audit.log({
      eventType: AuditEventType.PROJECT_SUBMITTED,
      actorId: bdAgentId,
      actorRole: UserRole.BD_AGENT,
      targetId: projectId,
      metadata: { referenceNumber: submitted.referenceNumber },
    });
    await this.notifications.notifyAdmin('PROJECT_SUBMITTED', {
      title: 'New Project Submitted',
      body: `Project ${submitted.referenceNumber} has been submitted and awaits assignment.`,
      metadata: { projectId, referenceNumber: submitted.referenceNumber },
    });
    return submitted;
  }

  async findAll(user: { sub: string; role: UserRole }, filters: any) {
    const { status, engineerId, projectType, from, to, search, page = 1, limit = 50 } = filters;
    const safeLimit = Math.min(Number(limit), 100);
    const safePage = Math.max(Number(page), 1);

    // Build the application-layer where clause (defence layer 1).
    // RLS policies on the DB enforce the same rules (defence layer 2).
    let where: any = {};
    if (user.role === UserRole.BD_AGENT) {
      where.bdAgentId = user.sub;
    } else if (user.role === UserRole.ESTIMATION_ENGINEER || user.role === UserRole.DESIGN_ENGINEER) {
      where.assignedTo = user.sub;
    }

    if (status) where.status = status;
    if (engineerId && user.role === UserRole.ADMIN) where.assignedTo = engineerId;
    if (projectType) where.projectType = projectType;
    if (from || to) {
      where.submittedAt = {};
      if (from) where.submittedAt.gte = new Date(from as string);
      if (to) where.submittedAt.lte = new Date(to as string);
    }
    if (search && user.role === UserRole.ADMIN) {
      where.OR = [
        { clientName: { contains: search, mode: 'insensitive' } },
        { referenceNumber: { contains: search, mode: 'insensitive' } },
      ];
    }

    // Run inside RLS context so DB policies also enforce isolation
    return this.prisma.withRlsContext(user.sub, user.role, async (tx: any) => {
      const [projects, total] = await Promise.all([
        tx.project.findMany({
          where,
          skip: (safePage - 1) * safeLimit,
          take: safeLimit,
          orderBy: { submittedAt: 'desc' },
          include: {
            bdAgent: { select: { fullName: true } },
            assignedEngineer: { select: { id: true, fullName: true, role: true } },
            files: { select: { id: true, originalName: true, sizeBytes: true, mimeType: true } },
          },
        }),
        tx.project.count({ where }),
      ]);
      return { data: projects.map((p: any) => this.toRoleView(p, user.role)), total, page: safePage, limit: safeLimit };
    });
  }

  async findOne(id: string, user: { sub: string; role: UserRole }) {
    return this.prisma.withRlsContext(user.sub, user.role, async (tx: any) => {
      const project = await tx.project.findUnique({
        where: { id },
        include: {
          bdAgent: { select: { fullName: true } },
          assignedEngineer: { select: { id: true, fullName: true, role: true } },
          files: { select: { id: true, originalName: true, sizeBytes: true, mimeType: true } },
          deliverables: { select: { id: true, originalName: true, sizeBytes: true, mimeType: true, uploadedAt: true } },
          statusHistory: { orderBy: { changedAt: 'asc' } },
        },
      });

      if (!project) throw new NotFoundException('Project not found');

      // Application-layer checks (defence layer 1, in addition to RLS)
      if (user.role === UserRole.BD_AGENT && project.bdAgentId !== user.sub) throw new ForbiddenException();
      if ((user.role === UserRole.ESTIMATION_ENGINEER || user.role === UserRole.DESIGN_ENGINEER) && project.assignedTo !== user.sub) throw new ForbiddenException();

      return this.toRoleView(project, user.role);
    });
  }

  async assign(projectId: string, dto: AssignProjectDto, adminId: string) {
    const project: any = await this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.project.findUnique({ where: { id: projectId } }));
    if (!project) throw new NotFoundException('Project not found');

    const engineer = await this.prisma.user.findUnique({
      where: { id: dto.engineerId },
      select: { id: true, fullName: true, role: true, isActive: true },
    });
    if (!engineer || !engineer.isActive) throw new BadRequestException('Engineer not found or inactive');

    if (dto.projectType === 'estimation' && engineer.role !== UserRole.ESTIMATION_ENGINEER) {
      throw new BadRequestException('Selected engineer is not an estimation engineer');
    }
    if (dto.projectType === 'design' && engineer.role !== UserRole.DESIGN_ENGINEER) {
      throw new BadRequestException('Selected engineer is not a design engineer');
    }
    if (!['estimation', 'design'].includes(dto.projectType)) {
      throw new BadRequestException('projectType must be estimation or design');
    }
    if (project.status !== ProjectStatus.received && project.status !== ProjectStatus.assigned && project.status !== ProjectStatus.in_progress && project.status !== ProjectStatus.delivered) {
      throw new BadRequestException('Project cannot be assigned in its current status');
    }

    const isReassignment = !!project.assignedTo;

    await this.prisma.withRlsContext(adminId, UserRole.ADMIN, async (tx: any) => {
      await tx.project.update({
        where: { id: projectId },
        data: {
          assignedTo: dto.engineerId,
          status: ProjectStatus.assigned,
          internalDeadline: new Date(dto.internalDeadline),
          priority: dto.priority,
          adminInstructions: dto.adminInstructions ?? null,
          projectType: dto.projectType,
        },
      });
      await tx.projectStatusHistory.create({
        data: {
          projectId,
          fromStatus: project.status,
          toStatus: ProjectStatus.assigned,
          changedBy: adminId,
          notes: isReassignment ? `Reassigned from ${project.assignedTo}` : 'Initial assignment',
        },
      });
    });

    await this.audit.log({
      eventType: isReassignment ? AuditEventType.PROJECT_REASSIGNED : AuditEventType.PROJECT_ASSIGNED,
      actorId: adminId,
      actorRole: UserRole.ADMIN,
      targetId: projectId,
      metadata: { engineerId: dto.engineerId, isReassignment },
    });

    await this.notifications.notifyUser(dto.engineerId, 'PROJECT_ASSIGNED', {
      title: 'New Project Assigned',
      body: `Project ${project.referenceNumber} has been assigned to you. Deadline: ${dto.internalDeadline}.`,
      metadata: { projectId, referenceNumber: project.referenceNumber },
    });

    return { success: true };
  }

  async getStatusHistory(projectId: string, adminId: string) {
    return this.prisma.withRlsContext(adminId, UserRole.ADMIN, (tx: any) => tx.projectStatusHistory.findMany({
      where: { projectId },
      orderBy: { changedAt: 'asc' },
      include: { changedByUser: { select: { fullName: true, role: true } } },
    }));
  }

  async updateStatusToInProgress(projectId: string, engineerId: string, engineerRole: UserRole) {
    const project: any = await this.prisma.withRlsContext(engineerId, engineerRole, (tx: any) => tx.project.findUnique({ where: { id: projectId } }));
    if (!project || project.assignedTo !== engineerId) throw new ForbiddenException();
    if (project.status !== ProjectStatus.assigned) return;

    await this.prisma.withRlsContext(engineerId, engineerRole, async (tx: any) => {
      await tx.project.update({ where: { id: projectId }, data: { status: ProjectStatus.in_progress } });
      await tx.projectStatusHistory.create({ data: { projectId, fromStatus: ProjectStatus.assigned, toStatus: ProjectStatus.in_progress, changedBy: engineerId } });
    });
  }

  async markDelivered(projectId: string, engineerId: string, engineerRole: UserRole) {
    const project: any = await this.prisma.withRlsContext(engineerId, engineerRole, (tx: any) => tx.project.findUnique({ where: { id: projectId } }));
    if (!project || project.assignedTo !== engineerId) throw new ForbiddenException();
    if (project.status !== ProjectStatus.assigned && project.status !== ProjectStatus.in_progress) {
      throw new BadRequestException('Project is not ready to be delivered');
    }
    const deliverableCount: any = await this.prisma.withRlsContext(engineerId, engineerRole, (tx: any) => tx.deliverable.count({ where: { projectId, engineerId } }));
    if (deliverableCount < 1) throw new BadRequestException('Upload at least one deliverable before marking the project delivered');

    await this.prisma.withRlsContext(engineerId, engineerRole, async (tx: any) => {
      await tx.project.update({ where: { id: projectId }, data: { status: ProjectStatus.delivered } });
      await tx.projectStatusHistory.create({ data: { projectId, fromStatus: project.status, toStatus: ProjectStatus.delivered, changedBy: engineerId } });
    });

    await this.audit.log({
      eventType: AuditEventType.DELIVERABLE_UPLOADED,
      actorId: engineerId,
      actorRole: engineerRole,
      targetId: projectId,
      metadata: { referenceNumber: project.referenceNumber },
    });

    await this.notifications.notifyAdmin('DELIVERABLE_UPLOADED', {
      title: 'Work Delivered',
      body: `Project ${project.referenceNumber} has been delivered and is ready for review.`,
      metadata: { projectId, referenceNumber: project.referenceNumber },
    });
  }

  private toRoleView(project: any, role: UserRole) {
    if (role === UserRole.BD_AGENT) {
      return {
        id: project.id,
        referenceNumber: project.referenceNumber,
        clientName: project.clientName,
        scopeSummary: (project.scopeDescription as string).substring(0, 200),
        submittedAt: project.submittedAt,
        status: 'Received', // Always "Received" — internal status NEVER sent to BD
      };
    }

    if (role === UserRole.ESTIMATION_ENGINEER || role === UserRole.DESIGN_ENGINEER) {
      const now = new Date();
      const deadline = project.internalDeadline ? new Date(project.internalDeadline) : null;
      const diffMs = deadline ? deadline.getTime() - now.getTime() : null;
      const days = diffMs !== null ? Math.floor(diffMs / (1000 * 60 * 60 * 24)) : null;
      const hours = diffMs !== null ? Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)) : null;

      // CLIENT NAME / EMAIL / PHONE deliberately absent — not in select, not here
      return {
        id: project.id,
        referenceNumber: project.referenceNumber,
        scopeDescription: project.scopeDescription,
        adminInstructions: project.adminInstructions,
        internalDeadline: project.internalDeadline,
        priority: project.priority,
        status: project.status,
        files: project.files ?? [],
        deliverables: project.deliverables ?? [],
        deadlineCountdown: deadline ? { days, hours } : null,
      };
    }

    // Admin: full view
    return {
      id: project.id,
      referenceNumber: project.referenceNumber,
      bdAgentName: project.bdAgent?.fullName,
      clientName: project.clientName,
      clientEmail: project.clientEmail,
      clientPhone: project.clientPhone,
      scopeDescription: project.scopeDescription,
      requestedDeadline: project.requestedDeadline,
      submittedAt: project.submittedAt,
      status: project.status,
      assignedEngineer: project.assignedEngineer,
      internalDeadline: project.internalDeadline,
      priority: project.priority,
      adminInstructions: project.adminInstructions,
      projectType: project.projectType,
      statusHistory: project.statusHistory ?? [],
      files: project.files ?? [],
      deliverables: project.deliverables ?? [],
    };
  }

  private async generateReferenceNumber(): Promise<string> {
    // Atomic PostgreSQL sequence per year — eliminates TOCTOU race condition
    const year = new Date().getFullYear();
    const seqName = `prj_seq_${year}`;
    const result = await this.prisma.$queryRaw<{ nextval: bigint }[]>`
      SELECT nextval(${seqName}::regclass) AS nextval
    `.catch(async () => {
      await this.prisma.$executeRawUnsafe(
        `CREATE SEQUENCE IF NOT EXISTS "${seqName}" START 1 INCREMENT 1 NO CYCLE`,
      );
      return this.prisma.$queryRaw<{ nextval: bigint }[]>`
        SELECT nextval(${seqName}::regclass) AS nextval
      `;
    });
    const n = Number(result[0].nextval);
    return `PRJ-${year}-${String(n).padStart(4, '0')}`;
  }
}
