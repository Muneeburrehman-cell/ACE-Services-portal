import { Controller, Get, Post, Param, Body, UseGuards, Req } from '@nestjs/common';
import { DeliveryService } from './delivery.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '@prisma/client';
import { SendToClientDto } from './dto/send-to-client.dto';

@Controller('delivery')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.ADMIN)
export class DeliveryController {
  constructor(private delivery: DeliveryService) {}

  @Get(':projectId/preview')
  preview(@Param('projectId') projectId: string, @Req() req: any) {
    return this.delivery.getPreview(projectId, req.user.sub);
  }

  @Post(':projectId/send')
  send(@Param('projectId') projectId: string, @Body() body: SendToClientDto, @Req() req: any) {
    return this.delivery.sendToClient(projectId, body, req.user.sub);
  }
}
