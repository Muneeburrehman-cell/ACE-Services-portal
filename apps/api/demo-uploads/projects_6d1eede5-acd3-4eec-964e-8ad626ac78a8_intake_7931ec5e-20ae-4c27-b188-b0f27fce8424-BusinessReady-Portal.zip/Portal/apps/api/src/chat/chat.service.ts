import { Injectable, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { AuditEventType, UserRole } from '@prisma/client';

const MAX_MESSAGE_LENGTH = 4000;
const SYSTEM_ADMIN_CONTEXT = '00000000-0000-0000-0000-000000000000';

@Injectable()
export class ChatService {
  constructor(private prisma: PrismaService, private audit: AuditService) {}

  async getOrCreateThread(employeeId: string, role: UserRole) {
    return this.prisma.withRlsContext(employeeId, role, (tx: any) =>
      tx.chatThread.upsert({ where: { employeeId }, create: { employeeId }, update: {} }),
    );
  }

  async getAllThreadIds(): Promise<string[]> {
    const threads: any[] = await this.prisma.withRlsContext(
      SYSTEM_ADMIN_CONTEXT,
      UserRole.ADMIN,
      (tx: any) => tx.chatThread.findMany({ select: { id: true } }),
    );
    return threads.map((t) => t.id);
  }

  async getAllThreadsWithPreview() {
    const threads: any[] = await this.prisma.withRlsContext(
      SYSTEM_ADMIN_CONTEXT,
      UserRole.ADMIN,
      (tx: any) =>
        tx.chatThread.findMany({
          include: {
            employee: { select: { id: true, fullName: true, role: true } },
            messages: {
              orderBy: { sentAt: 'desc' },
              take: 1,
              select: { content: true, sentAt: true, senderId: true },
            },
          },
          orderBy: { createdAt: 'asc' },
        }),
    );

    return threads.map((t) => ({
      id: t.id,
      employee: t.employee,
      lastMessage: t.messages[0] ?? null,
    }));
  }

  async getThreadMessages(threadId: string, userId: string, role: UserRole, page = 1, limit = 50) {
    const safeLimit = Math.min(Math.max(limit, 1), 100);
    return this.prisma.withRlsContext(userId, role, async (tx: any) => {
      if (role !== UserRole.ADMIN) {
        const thread = await tx.chatThread.findUnique({ where: { id: threadId } });
        if (!thread || thread.employeeId !== userId) throw new ForbiddenException();
      } else {
        const thread = await tx.chatThread.findUnique({ where: { id: threadId } });
        if (!thread) throw new ForbiddenException();
      }

      const [messages, total] = await Promise.all([
        tx.chatMessage.findMany({
          where: { threadId },
          orderBy: { sentAt: 'asc' },
          skip: (page - 1) * safeLimit,
          take: safeLimit,
          include: { sender: { select: { id: true, fullName: true, role: true } } },
        }),
        tx.chatMessage.count({ where: { threadId } }),
      ]);
      return { messages, total, page, limit: safeLimit };
    });
  }

  async getMyThread(userId: string, role: UserRole) {
    return this.getOrCreateThread(userId, role);
  }

  async sendMessage(threadId: string, senderId: string, senderRole: UserRole, content: string) {
    if (!content || content.trim().length === 0) throw new Error('Message content cannot be empty');
    const trimmed = content.trim().substring(0, MAX_MESSAGE_LENGTH);

    const message: any = await this.prisma.withRlsContext(senderId, senderRole, async (tx: any) => {
      const thread = await tx.chatThread.findUnique({ where: { id: threadId } });
      if (!thread) throw new ForbiddenException();
      if (senderRole !== UserRole.ADMIN && thread.employeeId !== senderId) throw new ForbiddenException();

      return tx.chatMessage.create({
        data: { threadId, senderId, content: trimmed },
        include: { sender: { select: { id: true, fullName: true, role: true } } },
      });
    });

    await this.audit.log({
      eventType: AuditEventType.CHAT_MESSAGE_SENT,
      actorId: senderId,
      actorRole: senderRole,
      metadata: { threadId },
    });
    return message;
  }

  async markRead(messageId: string, userId: string, role: UserRole) {
    await this.prisma.withRlsContext(userId, role, async (tx: any) => {
      await tx.chatMessage.updateMany({
        where: { id: messageId, thread: { employeeId: userId } },
        data: { readAt: new Date() },
      });
    });
  }
}
