import {
  Controller, Post, Get, Delete, Body, Param, Query, UseGuards, Req,
} from '@nestjs/common';
import { FilesService } from './files.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '@prisma/client';
import { UploadUrlDto } from './dto/upload-url.dto';
import { ConfirmUploadDto } from './dto/confirm-upload.dto';

@Controller('files')
@UseGuards(JwtAuthGuard)
export class FilesController {
  constructor(private files: FilesService) {}

  /**
   * BD agents: fileType must be 'intake', projectId must be their own project.
   * Engineers: fileType must be 'deliverable', projectId must be assigned to them.
   * Both: validated by FilesService.assertProjectAccess.
   */
  @Post('upload-url')
  getUploadUrl(@Body() dto: UploadUrlDto, @Req() req: any) {
    return this.files.getUploadUrl(dto, req.user);
  }

  @Post('confirm')
  confirmUpload(@Body() dto: ConfirmUploadDto, @Req() req: any) {
    return this.files.confirmUpload(dto, req.user);
  }

  @Get(':id/download-url')
  getDownloadUrl(
    @Param('id') id: string,
    @Query('type') type: 'intake' | 'deliverable' = 'intake',
    @Req() req: any,
  ) {
    return this.files.getDownloadUrl(id, type, req.user);
  }

  @Delete(':id')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ADMIN)
  deleteFile(@Param('id') id: string, @Query('type') type: 'intake' | 'deliverable' = 'intake', @Req() req: any) {
    return this.files.deleteFile(id, type, req.user.sub);
  }
}
