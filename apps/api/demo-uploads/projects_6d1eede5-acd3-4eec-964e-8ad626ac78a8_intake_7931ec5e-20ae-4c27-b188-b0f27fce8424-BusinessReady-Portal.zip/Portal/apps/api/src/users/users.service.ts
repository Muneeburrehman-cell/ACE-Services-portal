import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { AuditEventType, UserRole } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import * as sgMail from '@sendgrid/mail';
const sg = sgMail as any;
import { ConfigService } from '@nestjs/config';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UsersService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
    private config: ConfigService,
  ) {
    sg.setApiKey(this.config.get('SENDGRID_API_KEY') || '');
  }

  async findAll(role?: UserRole, page = 1, limit = 50) {
    const where = role ? { role } : {};
    const [data, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        select: {
          id: true,
          fullName: true,
          email: true,
          role: true,
          isActive: true,
          createdAt: true,
        },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.user.count({ where }),
    ]);
    return { data, total, page, limit };
  }

  async findEngineers(type?: 'estimation' | 'design') {
    const roles =
      type === 'estimation'
        ? [UserRole.ESTIMATION_ENGINEER]
        : type === 'design'
          ? [UserRole.DESIGN_ENGINEER]
          : [UserRole.ESTIMATION_ENGINEER, UserRole.DESIGN_ENGINEER];

    return this.prisma.user.findMany({
      where: { role: { in: roles }, isActive: true },
      select: { id: true, fullName: true, role: true },
      orderBy: { fullName: 'asc' },
    });
  }

  async create(dto: CreateUserDto, createdBy: string) {
    if (dto.role === UserRole.ADMIN) {
      const existingAdmin = await this.prisma.user.count({ where: { role: UserRole.ADMIN, isActive: true } });
      if (existingAdmin > 0) throw new ConflictException('Only one active administrator account is permitted');
    }
    const exists = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (exists) throw new ConflictException('Email already in use');

    const tempPassword = crypto.randomBytes(12).toString('hex');
    const passwordHash = await bcrypt.hash(tempPassword, 12);

    const user = await this.prisma.user.create({
      data: {
        fullName: dto.fullName,
        email: dto.email,
        role: dto.role,
        passwordHash,
      },
      select: { id: true, fullName: true, email: true, role: true, createdAt: true },
    });

    await this.audit.log({
      eventType: AuditEventType.USER_ACCOUNT_CREATED,
      actorId: createdBy,
      actorRole: UserRole.ADMIN,
      targetId: user.id,
      metadata: { email: user.email, role: user.role },
    });

    // Send welcome email with password set link
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    });

    const setPasswordUrl = `${this.config.get('APP_BASE_URL')}/reset-password?token=${rawToken}`;
    await this.sendWelcomeEmail(user.email, user.fullName, setPasswordUrl);

    return user;
  }

  async update(id: string, dto: UpdateUserDto, updatedBy: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException('User not found');

    const data: any = {};
    if (dto.fullName) data.fullName = dto.fullName;
    if (dto.role && dto.role !== user.role) {
      if (dto.role === UserRole.ADMIN) {
        const existingAdmin = await this.prisma.user.count({ where: { role: UserRole.ADMIN, isActive: true, id: { not: id } } });
        if (existingAdmin > 0) throw new ConflictException('Only one active administrator account is permitted');
      }
      data.role = dto.role;
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data,
      select: { id: true, fullName: true, email: true, role: true, isActive: true },
    });

    const eventType = dto.role && dto.role !== user.role
      ? AuditEventType.ROLE_CHANGED
      : AuditEventType.USER_ACCOUNT_UPDATED;

    await this.audit.log({
      eventType,
      actorId: updatedBy,
      actorRole: UserRole.ADMIN,
      targetId: id,
      metadata: dto as any,
    });

    return updated;
  }

  async deactivate(id: string, deactivatedBy: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException('User not found');
    if (user.id === deactivatedBy) throw new ConflictException('You cannot deactivate your own account');
    if (user.role === UserRole.ADMIN) {
      const adminCount = await this.prisma.user.count({ where: { role: UserRole.ADMIN, isActive: true } });
      if (adminCount <= 1) throw new ConflictException('The last active administrator cannot be deactivated');
    }

    await this.prisma.$transaction([
      this.prisma.user.update({ where: { id }, data: { isActive: false } }),
      this.prisma.refreshToken.updateMany({ where: { userId: id }, data: { revoked: true } }),
    ]);

    await this.audit.log({
      eventType: AuditEventType.USER_ACCOUNT_DEACTIVATED,
      actorId: deactivatedBy,
      actorRole: UserRole.ADMIN,
      targetId: id,
    });

    return { success: true };
  }

  async triggerPasswordReset(id: string, triggeredBy: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException('User not found');

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');

    await this.prisma.passwordResetToken.create({
      data: {
        userId: id,
        tokenHash,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      },
    });

    const resetUrl = `${this.config.get('APP_BASE_URL')}/reset-password?token=${rawToken}`;
    try {
      await sg.send({
        to: user.email,
        from: this.config.get('SENDGRID_FROM_EMAIL') || 'noreply@portal.com',
        subject: 'Password Reset',
        text: `Reset your password: ${resetUrl}\n\nExpires in 60 minutes.`,
      });
    } catch (e) {
      console.error('Email failed:', e);
    }

    return { success: true };
  }

  private async sendWelcomeEmail(email: string, name: string, setPasswordUrl: string) {
    try {
      await sg.send({
        to: email,
        from: this.config.get('SENDGRID_FROM_EMAIL') || 'noreply@portal.com',
        subject: 'Welcome to the Estimation Portal',
        text: `Hi ${name},\n\nYour account has been created. Set your password here:\n${setPasswordUrl}\n\nThis link expires in 24 hours.`,
      });
    } catch (e) {
      console.error('Welcome email failed:', e);
    }
  }
}
