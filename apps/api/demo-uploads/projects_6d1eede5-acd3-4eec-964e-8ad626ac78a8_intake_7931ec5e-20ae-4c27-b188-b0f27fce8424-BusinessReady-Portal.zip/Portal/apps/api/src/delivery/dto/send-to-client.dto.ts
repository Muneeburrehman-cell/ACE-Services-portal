import { IsIn, IsString, MaxLength, MinLength } from 'class-validator';

export class SendToClientDto {
  @IsString() @MinLength(1) @MaxLength(500) subject: string;
  @IsString() @MinLength(1) @MaxLength(20000) body: string;
  @IsIn(['attachment', 'link']) deliveryMethod: 'attachment' | 'link';
}
