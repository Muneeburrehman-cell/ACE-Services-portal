import {
  Controller, Get, Param, Query, UseGuards, Req,
} from '@nestjs/common';
import { ChatService } from './chat.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '@prisma/client';

@Controller('chat')
@UseGuards(JwtAuthGuard)
export class ChatController {
  constructor(private chat: ChatService) {}

  @Get('thread')
  @UseGuards(RolesGuard)
  @Roles(UserRole.BD_AGENT, UserRole.ESTIMATION_ENGINEER, UserRole.DESIGN_ENGINEER)
  async getMyThread(@Req() req: any, @Query('page') page = '1', @Query('limit') limit = '50') {
    const thread: any = await this.chat.getMyThread(req.user.sub, req.user.role);
    const history = await this.chat.getThreadMessages(thread.id, req.user.sub, req.user.role, Number(page), Number(limit));
    return { thread, ...history };
  }

  @Get('threads')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ADMIN)
  getAllThreads() {
    return this.chat.getAllThreadsWithPreview();
  }

  @Get('threads/:id/messages')
  @UseGuards(RolesGuard)
  @Roles(UserRole.ADMIN)
  getThreadMessages(
    @Param('id') id: string,
    @Req() req: any,
    @Query('page') page = '1',
    @Query('limit') limit = '50',
  ) {
    return this.chat.getThreadMessages(id, req.user.sub, req.user.role, Number(page), Number(limit));
  }
}
