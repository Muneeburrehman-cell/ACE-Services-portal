import { IsEmail, IsString, MinLength, IsDateString, IsPhoneNumber } from 'class-validator';

export class CreateProjectDto {
  @IsString()
  @MinLength(2)
  clientName: string;

  @IsEmail()
  clientEmail: string;

  @IsString()
  clientPhone: string;

  @IsString()
  @MinLength(10)
  scopeDescription: string;

  @IsDateString()
  requestedDeadline: string;
}
