import {
  Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, Req,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '@prisma/client';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Controller('users')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.ADMIN)
export class UsersController {
  constructor(private users: UsersService) {}

  @Get()
  findAll(
    @Query('role') role?: UserRole,
    @Query('page') page = '1',
    @Query('limit') limit = '50',
  ) {
    return this.users.findAll(role, Number(page), Number(limit));
  }

  @Get('engineers')
  findEngineers(@Query('type') type?: 'estimation' | 'design') {
    return this.users.findEngineers(type);
  }

  @Post()
  create(@Body() dto: CreateUserDto, @Req() req: any) {
    return this.users.create(dto, req.user.sub);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateUserDto, @Req() req: any) {
    return this.users.update(id, dto, req.user.sub);
  }

  @Delete(':id/deactivate')
  deactivate(@Param('id') id: string, @Req() req: any) {
    return this.users.deactivate(id, req.user.sub);
  }

  @Post(':id/reset-password')
  resetPassword(@Param('id') id: string, @Req() req: any) {
    return this.users.triggerPasswordReset(id, req.user.sub);
  }
}
