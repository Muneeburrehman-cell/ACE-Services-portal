import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';

async function bootstrap() {
  const isProduction = process.env.NODE_ENV === 'production';
  if (isProduction) {
    const jwtSecret = process.env.JWT_SECRET || '';
    const refreshSecret = process.env.JWT_REFRESH_SECRET || '';
    const appBaseUrl = process.env.APP_BASE_URL || '';
    if (jwtSecret.length < 32 || refreshSecret.length < 32) {
      throw new Error('Production JWT secrets must each be at least 32 characters long.');
    }
    if (!appBaseUrl.startsWith('https://')) {
      throw new Error('APP_BASE_URL must use HTTPS in production.');
    }
    for (const [key, value] of Object.entries({ SENDGRID_API_KEY: process.env.SENDGRID_API_KEY, SENDGRID_FROM_EMAIL: process.env.SENDGRID_FROM_EMAIL, AWS_S3_BUCKET: process.env.AWS_S3_BUCKET })) {
      if (!value) throw new Error(`${key} is required in production.`);
    }
  }
  const app = await NestFactory.create(AppModule);

  if (isProduction && process.env.ENFORCE_HTTPS !== 'false') {
    app.getHttpAdapter().getInstance().set('trust proxy', 1);
    app.use((req, res, next) => {
      const forwardedProto = req.headers['x-forwarded-proto'];
      if (forwardedProto && forwardedProto !== 'https') return res.status(400).json({ message: 'HTTPS is required' });
      if (!forwardedProto && req.protocol !== 'https') return res.status(400).json({ message: 'HTTPS is required' });
      next();
    });
  }
  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(cookieParser());

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  const allowedOrigin = process.env.APP_BASE_URL || 'http://localhost:3000';
  app.enableCors({ origin: allowedOrigin, credentials: true });

  app.setGlobalPrefix('api');

  await app.listen(4000);
  console.log('API running on http://localhost:4000');
}
bootstrap();
