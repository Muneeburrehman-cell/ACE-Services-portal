'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { PriorityBadge } from '@/components/ui/PriorityBadge';
import { DeadlineCountdown } from '@/components/ui/DeadlineCountdown';

export default function EngineerDashboard() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<any>('/projects').then((res) => setProjects(res.data || [])).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">My Assigned Projects</h1>

      {loading && <p className="text-gray-500">Loading...</p>}
      {!loading && projects.length === 0 && (
        <div className="card text-center py-12">
          <p className="text-gray-500">No projects assigned yet.</p>
        </div>
      )}

      {projects.length > 0 && (
        <div className="card overflow-hidden p-0">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left p-4 font-medium text-gray-600">Reference</th>
                <th className="text-left p-4 font-medium text-gray-600">Scope</th>
                <th className="text-left p-4 font-medium text-gray-600">Priority</th>
                <th className="text-left p-4 font-medium text-gray-600">Deadline</th>
                <th className="text-left p-4 font-medium text-gray-600">Status</th>
                <th className="p-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {projects.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="p-4 font-mono text-xs">{p.referenceNumber}</td>
                  <td className="p-4 text-gray-600 max-w-xs truncate">{p.scopeDescription}</td>
                  <td className="p-4">{p.priority && <PriorityBadge priority={p.priority} />}</td>
                  <td className="p-4"><DeadlineCountdown deadline={p.internalDeadline} /></td>
                  <td className="p-4"><StatusBadge status={p.status} /></td>
                  <td className="p-4">
                    <Link href={`/engineer/projects/${p.id}`} className="text-primary text-sm hover:underline">
                      View →
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
