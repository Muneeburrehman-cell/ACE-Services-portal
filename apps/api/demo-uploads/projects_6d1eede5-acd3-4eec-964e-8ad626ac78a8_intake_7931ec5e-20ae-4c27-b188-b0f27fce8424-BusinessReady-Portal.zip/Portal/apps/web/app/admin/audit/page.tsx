'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

export default function AuditPage() {
  const [entries, setEntries] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [eventType, setEventType] = useState('');

  function load(p = page, et = eventType) {
    const params = new URLSearchParams({ page: String(p), limit: '50' });
    if (et) params.set('eventType', et);
    api.get<any>(`/audit?${params}`).then((res) => {
      setEntries(res.data || []);
      setTotal(res.total || 0);
    });
  }
  useEffect(() => { load(); }, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Audit Log</h1>
        <span className="text-sm text-gray-500">{total} entries</span>
      </div>

      <div className="flex gap-3 mb-4">
        <select className="input max-w-xs text-sm" onChange={(e) => { setEventType(e.target.value); load(1, e.target.value); }}>
          <option value="">All event types</option>
          {['USER_LOGIN_SUCCESS','USER_LOGIN_FAILURE','PROJECT_SUBMITTED','PROJECT_ASSIGNED','PROJECT_REASSIGNED','DELIVERABLE_UPLOADED','SEND_TO_CLIENT_SUCCESS','SEND_TO_CLIENT_FAILURE','CHAT_MESSAGE_SENT','USER_ACCOUNT_CREATED','USER_ACCOUNT_DEACTIVATED'].map((e) => (
            <option key={e} value={e}>{e.replace(/_/g, ' ')}</option>
          ))}
        </select>
      </div>

      <div className="card overflow-hidden p-0">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left p-4 font-medium text-gray-600">Time (UTC)</th>
              <th className="text-left p-4 font-medium text-gray-600">Event</th>
              <th className="text-left p-4 font-medium text-gray-600">Actor</th>
              <th className="text-left p-4 font-medium text-gray-600">Details</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {entries.map((e) => (
              <tr key={e.id} className="hover:bg-gray-50">
                <td className="p-4 text-xs text-gray-500 whitespace-nowrap">
                  {new Date(e.occurredAt).toISOString().replace('T', ' ').substring(0, 19)}
                </td>
                <td className="p-4 text-xs font-mono">{e.eventType}</td>
                <td className="p-4 text-xs">{e.actor?.fullName || '—'}</td>
                <td className="p-4 text-xs text-gray-400 max-w-xs truncate">
                  {JSON.stringify(e.metadata)}
                </td>
              </tr>
            ))}
            {entries.length === 0 && (
              <tr><td colSpan={4} className="p-8 text-center text-gray-400">No audit entries</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {total > 50 && (
        <div className="flex gap-2 mt-4 justify-center">
          <button onClick={() => { setPage(p => Math.max(1, p - 1)); load(Math.max(1, page - 1)); }} disabled={page === 1} className="btn-secondary text-sm">Prev</button>
          <span className="py-2 text-sm">{page} / {Math.ceil(total / 50)}</span>
          <button onClick={() => { setPage(p => p + 1); load(page + 1); }} disabled={page * 50 >= total} className="btn-secondary text-sm">Next</button>
        </div>
      )}
    </div>
  );
}
