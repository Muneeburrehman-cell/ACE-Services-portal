import { Navbar } from '@/components/layout/Navbar';

export default function BDLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar role="BD_AGENT" />
      <main className="max-w-6xl mx-auto p-6">{children}</main>
    </div>
  );
}
