'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { api } from '@/lib/api';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { PriorityBadge } from '@/components/ui/PriorityBadge';

export default function AdminProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<any>(null);
  const [engineers, setEngineers] = useState<any[]>([]);
  const [showAssign, setShowAssign] = useState(false);
  const [showDeliver, setShowDeliver] = useState(false);
  const [deliverPreview, setDeliverPreview] = useState<any>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [error, setError] = useState('');

  const assignForm = useForm();
  const deliverForm = useForm();

  useEffect(() => {
    api.get<any>(`/projects/${id}`).then(setProject);
    api.get<any>('/users/engineers').then(setEngineers);
  }, [id]);

  async function onAssign(data: any) {
    setError('');
    try {
      await api.patch(`/projects/${id}/assign`, data);
      const updated = await api.get<any>(`/projects/${id}`);
      setProject(updated);
      setShowAssign(false);
      setSuccessMsg('Project assigned successfully');
    } catch (e: any) { setError(e.message); }
  }

  async function onSendToClient(data: any) {
    setError('');
    try {
      await api.post(`/delivery/${id}/send`, data);
      const updated = await api.get<any>(`/projects/${id}`);
      setProject(updated);
      setShowDeliver(false);
      setSuccessMsg('Email sent to client');
    } catch (e: any) { setError(e.message); }
  }

  async function openDeliverModal() {
    const preview = await api.get<any>(`/delivery/${id}/preview`);
    setDeliverPreview(preview);
    deliverForm.setValue('to', preview.to);
    deliverForm.setValue('subject', preview.subject);
    deliverForm.setValue('body', preview.body);
    deliverForm.setValue('deliveryMethod', preview.deliveryMethod);
    setShowDeliver(true);
  }

  async function downloadFile(fileId: string, type: 'intake' | 'deliverable') {
    const res = await api.get<any>(`/files/${fileId}/download-url?type=${type}`);
    window.open(res.url, '_blank');
  }

  if (!project) return <div className="p-6 text-gray-500">Loading...</div>;

  return (
    <div className="max-w-4xl space-y-6">
      {successMsg && (
        <div className="bg-green-50 border border-green-200 text-green-700 p-3 rounded flex justify-between">
          <span>{successMsg}</span>
          <button onClick={() => setSuccessMsg('')} className="text-green-500">✕</button>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3 flex-wrap">
        <h1 className="text-2xl font-bold">{project.referenceNumber}</h1>
        <StatusBadge status={project.status} />
        {project.priority && <PriorityBadge priority={project.priority} />}
        <div className="ml-auto flex gap-2">
          <button onClick={() => setShowAssign(true)} className="btn-secondary text-sm">
            {project.assignedEngineer ? 'Reassign' : 'Assign'}
          </button>
          {project.status === 'delivered' && (
            <button onClick={openDeliverModal} className="btn-primary text-sm">
              Send to Client
            </button>
          )}
        </div>
      </div>

      {/* Client & Project Info */}
      <div className="grid grid-cols-2 gap-6">
        <div className="card">
          <h2 className="font-semibold mb-3">Client Information</h2>
          <p className="text-sm"><span className="text-gray-500">Name:</span> {project.clientName}</p>
          <p className="text-sm mt-1"><span className="text-gray-500">Email:</span> {project.clientEmail}</p>
          <p className="text-sm mt-1"><span className="text-gray-500">Phone:</span> {project.clientPhone}</p>
        </div>
        <div className="card">
          <h2 className="font-semibold mb-3">Assignment</h2>
          <p className="text-sm"><span className="text-gray-500">Submitted by:</span> {project.bdAgentName}</p>
          <p className="text-sm mt-1"><span className="text-gray-500">Assigned to:</span> {project.assignedEngineer?.fullName || '—'}</p>
          <p className="text-sm mt-1"><span className="text-gray-500">Deadline:</span> {project.internalDeadline ? new Date(project.internalDeadline).toLocaleDateString() : '—'}</p>
          <p className="text-sm mt-1"><span className="text-gray-500">Type:</span> {project.projectType || '—'}</p>
        </div>
      </div>

      {/* Scope */}
      <div className="card">
        <h2 className="font-semibold mb-2">Scope Description</h2>
        <p className="text-sm text-gray-700 whitespace-pre-wrap">{project.scopeDescription}</p>
        {project.adminInstructions && (
          <>
            <h3 className="font-medium mt-4 mb-1">Admin Instructions</h3>
            <p className="text-sm text-gray-700 bg-yellow-50 p-3 rounded whitespace-pre-wrap">{project.adminInstructions}</p>
          </>
        )}
      </div>

      {/* Status History */}
      <div className="card">
        <h2 className="font-semibold mb-3">Status History</h2>
        <div className="space-y-2">
          {(project.statusHistory || []).map((h: any, i: number) => (
            <div key={i} className="flex items-center gap-3 text-sm">
              <span className="text-gray-400 text-xs w-36">{new Date(h.changedAt).toLocaleString()}</span>
              <StatusBadge status={h.toStatus} />
              {h.notes && <span className="text-gray-500 text-xs">{h.notes}</span>}
            </div>
          ))}
        </div>
      </div>

      {/* Files */}
      {project.files?.length > 0 && (
        <div className="card">
          <h2 className="font-semibold mb-3">Project Files</h2>
          <div className="space-y-2">
            {project.files.map((f: any) => (
              <div key={f.id} className="flex items-center justify-between bg-gray-50 rounded p-3">
                <p className="text-sm">{f.originalName}</p>
                <button onClick={() => downloadFile(f.id, 'intake')} className="btn-secondary text-xs">Download</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Deliverables */}
      {project.deliverables?.length > 0 && (
        <div className="card">
          <h2 className="font-semibold mb-3">Deliverables</h2>
          <div className="space-y-2">
            {project.deliverables.map((d: any) => (
              <div key={d.id} className="flex items-center justify-between bg-green-50 rounded p-3">
                <p className="text-sm">{d.originalName}</p>
                <button onClick={() => downloadFile(d.id, 'deliverable')} className="btn-secondary text-xs">Download</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Assign Modal */}
      {showAssign && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
            <h2 className="text-lg font-bold mb-4">Assign Project</h2>
            <form onSubmit={assignForm.handleSubmit(onAssign)} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Engineer *</label>
                <select {...assignForm.register('engineerId', { required: true })} className="input">
                  <option value="">Select engineer...</option>
                  {engineers.map((e) => (
                    <option key={e.id} value={e.id}>{e.fullName} ({e.role.replace('_', ' ')})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Project Type *</label>
                <select {...assignForm.register('projectType', { required: true })} className="input">
                  <option value="">Select type...</option>
                  <option value="estimation">Estimation</option>
                  <option value="design">Design & Drafting</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Internal Deadline *</label>
                <input {...assignForm.register('internalDeadline', { required: true })} type="date" className="input" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Priority *</label>
                <select {...assignForm.register('priority', { required: true })} className="input">
                  <option value="">Select priority...</option>
                  {['low', 'medium', 'high', 'urgent'].map((p) => (
                    <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Instructions</label>
                <textarea {...assignForm.register('adminInstructions')} rows={3} className="input resize-none" />
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <div className="flex gap-3">
                <button type="submit" className="btn-primary" disabled={assignForm.formState.isSubmitting}>
                  {project.assignedEngineer ? 'Reassign' : 'Assign'}
                </button>
                <button type="button" onClick={() => { setShowAssign(false); setError(''); }} className="btn-secondary">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Send to Client Modal */}
      {showDeliver && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg p-6">
            <h2 className="text-lg font-bold mb-4">Send to Client</h2>
            <form onSubmit={deliverForm.handleSubmit(onSendToClient)} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Recipient Email</label>
                <input {...deliverForm.register('to')} className="input bg-gray-50" readOnly />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Subject</label>
                <input {...deliverForm.register('subject')} className="input" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Email Body</label>
                <textarea {...deliverForm.register('body')} rows={6} className="input resize-none" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Delivery Method</label>
                <select {...deliverForm.register('deliveryMethod')} className="input">
                  <option value="attachment">Attachment (≤25 MB)</option>
                  <option value="link">Secure Download Link (72h)</option>
                </select>
                {deliverPreview && (
                  <p className="text-xs text-gray-400 mt-1">
                    Total deliverable size: {(deliverPreview.totalDeliverableSize / 1024 / 1024).toFixed(2)} MB
                  </p>
                )}
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <div className="flex gap-3">
                <button type="submit" className="btn-primary" disabled={deliverForm.formState.isSubmitting}>
                  {deliverForm.formState.isSubmitting ? 'Sending...' : 'Send Email'}
                </button>
                <button type="button" onClick={() => { setShowDeliver(false); setError(''); }} className="btn-secondary">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
