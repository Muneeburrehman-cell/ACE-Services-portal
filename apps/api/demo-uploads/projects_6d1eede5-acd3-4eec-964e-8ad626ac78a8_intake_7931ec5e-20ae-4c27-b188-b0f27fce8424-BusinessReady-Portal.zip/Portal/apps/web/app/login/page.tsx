'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { login, verify2fa, getRoleDashboard } from '@/lib/auth';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});
const totpSchema = z.object({ totpCode: z.string().length(6) });

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<'login' | '2fa'>('login');
  const [pre2faToken, setPre2faToken] = useState('');
  const [error, setError] = useState('');

  const loginForm = useForm({ resolver: zodResolver(loginSchema) });
  const totpForm = useForm({ resolver: zodResolver(totpSchema) });

  async function onLogin(data: any) {
    setError('');
    try {
      const res = await login(data.email, data.password);
      if (res.requires2fa) {
        setPre2faToken(res.pre2faToken);
        setStep('2fa');
      } else {
        router.push(getRoleDashboard(res.role));
      }
    } catch (e: any) {
      setError(e.message);
    }
  }

  async function on2fa(data: any) {
    setError('');
    try {
      const res = await verify2fa(pre2faToken, data.totpCode);
      router.push(getRoleDashboard(res.role));
    } catch (e: any) {
      setError(e.message);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="card w-full max-w-md">
        <h1 className="text-2xl font-bold text-center text-primary mb-6">Estimation Portal</h1>

        {step === 'login' && (
          <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <input {...loginForm.register('email')} type="email" className="input" placeholder="you@company.com" />
              {loginForm.formState.errors.email && (
                <p className="text-red-500 text-xs mt-1">Valid email required</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Password</label>
              <input {...loginForm.register('password')} type="password" className="input" placeholder="••••••••" />
            </div>
            {error && <p className="text-red-600 text-sm bg-red-50 p-2 rounded">{error}</p>}
            <button type="submit" className="btn-primary w-full" disabled={loginForm.formState.isSubmitting}>
              {loginForm.formState.isSubmitting ? 'Signing in...' : 'Sign In'}
            </button>
            <div className="text-center">
              <a href="/reset-password" className="text-sm text-primary hover:underline">
                Forgot password?
              </a>
            </div>
          </form>
        )}

        {step === '2fa' && (
          <form onSubmit={totpForm.handleSubmit(on2fa)} className="space-y-4">
            <p className="text-sm text-gray-600 text-center">
              Enter the 6-digit code from your authenticator app.
            </p>
            <input
              {...totpForm.register('totpCode')}
              type="text"
              inputMode="numeric"
              maxLength={6}
              className="input text-center text-2xl tracking-widest"
              placeholder="000000"
              autoFocus
            />
            {error && <p className="text-red-600 text-sm bg-red-50 p-2 rounded">{error}</p>}
            <button type="submit" className="btn-primary w-full" disabled={totpForm.formState.isSubmitting}>
              Verify
            </button>
            <button type="button" onClick={() => setStep('login')} className="btn-secondary w-full">
              Back
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
