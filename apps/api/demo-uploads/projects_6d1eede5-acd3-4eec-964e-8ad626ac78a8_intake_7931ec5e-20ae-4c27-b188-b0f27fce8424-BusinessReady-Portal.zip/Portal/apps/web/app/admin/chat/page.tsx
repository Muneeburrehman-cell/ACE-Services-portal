'use client';
import { useEffect, useState, useRef } from 'react';
import { api } from '@/lib/api';
import { getChatSocket } from '@/lib/socket';

export default function AdminChatPage() {
  const [threads, setThreads] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get<any>('/chat/threads').then(setThreads);
    const socket = getChatSocket();
    socket.on('thread_list', setThreads);
    socket.on('new_message', (msg: any) => {
      setMessages((prev) => {
        if (selected?.id === msg.threadId) return [...prev, msg];
        return prev;
      });
    });
    return () => { socket.off('thread_list'); socket.off('new_message'); };
  }, [selected]);

  async function selectThread(thread: any) {
    setSelected(thread);
    const res = await api.get<any>(`/chat/threads/${thread.id}/messages`);
    setMessages(res.messages || []);
  }

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  function send() {
    if (!input.trim() || !selected) return;
    const socket = getChatSocket();
    socket.emit('send_message', { content: input.trim(), threadId: selected.id });
    setInput('');
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Chat</h1>
      <div className="flex gap-4" style={{ height: '70vh' }}>
        {/* Thread list */}
        <div className="w-64 card p-0 overflow-y-auto flex-shrink-0">
          {threads.length === 0 && <p className="p-4 text-sm text-gray-400">No chats yet</p>}
          {threads.map((t) => (
            <button
              key={t.id}
              onClick={() => selectThread(t)}
              className={`w-full text-left px-4 py-3 border-b hover:bg-gray-50 ${selected?.id === t.id ? 'bg-blue-50' : ''}`}
            >
              <p className="text-sm font-medium">{t.employee.fullName}</p>
              <p className="text-xs text-gray-400">{t.employee.role.replace(/_/g, ' ')}</p>
              {t.lastMessage && (
                <p className="text-xs text-gray-400 truncate mt-0.5">{t.lastMessage.content}</p>
              )}
            </button>
          ))}
        </div>

        {/* Message area */}
        {selected ? (
          <div className="flex-1 card flex flex-col p-0">
            <div className="px-4 py-3 border-b bg-gray-50 font-medium text-sm">
              {selected.employee.fullName}
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((m) => (
                <div key={m.id} className={`flex ${m.sender?.role === 'ADMIN' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs rounded-2xl px-4 py-2 text-sm ${m.sender?.role === 'ADMIN' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'}`}>
                    <p>{m.content}</p>
                    <p className="text-xs mt-1 opacity-70">{new Date(m.sentAt).toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
            <div className="border-t p-3 flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && send()}
                className="input flex-1 text-sm"
                placeholder="Type a message..."
              />
              <button onClick={send} className="btn-primary text-sm">Send</button>
            </div>
          </div>
        ) : (
          <div className="flex-1 card flex items-center justify-center text-gray-400">
            Select a conversation
          </div>
        )}
      </div>
    </div>
  );
}
