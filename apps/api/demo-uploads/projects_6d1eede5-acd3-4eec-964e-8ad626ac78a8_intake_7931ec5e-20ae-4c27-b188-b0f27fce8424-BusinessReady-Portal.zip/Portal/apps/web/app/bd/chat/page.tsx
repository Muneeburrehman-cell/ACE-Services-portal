'use client';
import { useEffect, useState, useRef } from 'react';
import { api } from '@/lib/api';
import { getChatSocket } from '@/lib/socket';

export default function BDChatPage() {
  const [messages, setMessages] = useState<any[]>([]);
  const [threadId, setThreadId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [userId, setUserId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get<any>('/chat/thread').then((res) => {
      setThreadId(res.thread.id);
      setMessages(res.messages || []);
    });

    const socket = getChatSocket();
    socket.on('new_message', (msg: any) => {
      setMessages((prev) => [...prev, msg]);
    });
    return () => { socket.off('new_message'); };
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function send() {
    if (!input.trim() || !threadId) return;
    const socket = getChatSocket();
    socket.emit('send_message', { content: input.trim() });
    setInput('');
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Chat with Admin</h1>
      <div className="card flex flex-col" style={{ height: '60vh' }}>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((m) => (
            <div key={m.id} className={`flex ${m.sender?.role === 'ADMIN' ? 'justify-start' : 'justify-end'}`}>
              <div className={`max-w-xs rounded-2xl px-4 py-2 text-sm ${m.sender?.role === 'ADMIN' ? 'bg-gray-100 text-gray-800' : 'bg-primary text-white'}`}>
                <p>{m.content}</p>
                <p className={`text-xs mt-1 ${m.sender?.role === 'ADMIN' ? 'text-gray-400' : 'text-blue-200'}`}>
                  {new Date(m.sentAt).toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
        <div className="border-t p-3 flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && send()}
            className="input flex-1 text-sm"
            placeholder="Type a message..."
          />
          <button onClick={send} className="btn-primary text-sm">Send</button>
        </div>
      </div>
    </div>
  );
}
