'use client';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { api } from '@/lib/api';

const ROLES = ['BD_AGENT', 'ESTIMATION_ENGINEER', 'DESIGN_ENGINEER'];

export default function AdminUsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [error, setError] = useState('');
  const form = useForm();

  function load() {
    api.get<any>('/users').then((res) => setUsers(res.data || []));
  }
  useEffect(() => { load(); }, []);

  async function onCreate(data: any) {
    setError('');
    try {
      await api.post('/users', data);
      load();
      setShowCreate(false);
      form.reset();
    } catch (e: any) { setError(e.message); }
  }

  async function deactivate(id: string) {
    if (!confirm('Deactivate this account?')) return;
    await api.delete(`/users/${id}/deactivate`);
    load();
  }

  async function resetPassword(id: string) {
    await api.post(`/users/${id}/reset-password`);
    alert('Password reset email sent');
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">User Management</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary">+ New User</button>
      </div>

      <div className="card overflow-hidden p-0">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left p-4 font-medium text-gray-600">Name</th>
              <th className="text-left p-4 font-medium text-gray-600">Email</th>
              <th className="text-left p-4 font-medium text-gray-600">Role</th>
              <th className="text-left p-4 font-medium text-gray-600">Status</th>
              <th className="p-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {users.map((u) => (
              <tr key={u.id} className={`hover:bg-gray-50 ${!u.isActive ? 'opacity-50' : ''}`}>
                <td className="p-4 font-medium">{u.fullName}</td>
                <td className="p-4 text-gray-500">{u.email}</td>
                <td className="p-4 text-xs font-mono">{u.role}</td>
                <td className="p-4">
                  <span className={`badge ${u.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {u.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => resetPassword(u.id)} className="text-xs text-primary hover:underline">Reset PW</button>
                    {u.isActive && (
                      <button onClick={() => deactivate(u.id)} className="text-xs text-red-500 hover:underline">Deactivate</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
            <h2 className="text-lg font-bold mb-4">Create New User</h2>
            <form onSubmit={form.handleSubmit(onCreate)} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Full Name *</label>
                <input {...form.register('fullName', { required: true })} className="input" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Email *</label>
                <input {...form.register('email', { required: true })} type="email" className="input" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Role *</label>
                <select {...form.register('role', { required: true })} className="input">
                  <option value="">Select role...</option>
                  {ROLES.map((r) => <option key={r} value={r}>{r.replace(/_/g, ' ')}</option>)}
                </select>
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <p className="text-xs text-gray-400">A welcome email with a password setup link will be sent automatically.</p>
              <div className="flex gap-3">
                <button type="submit" className="btn-primary" disabled={form.formState.isSubmitting}>Create</button>
                <button type="button" onClick={() => { setShowCreate(false); setError(''); }} className="btn-secondary">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
