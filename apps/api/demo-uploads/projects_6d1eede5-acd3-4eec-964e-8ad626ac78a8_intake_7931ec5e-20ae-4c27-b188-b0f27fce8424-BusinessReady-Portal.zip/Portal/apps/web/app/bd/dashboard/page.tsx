'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { StatusBadge } from '@/components/ui/StatusBadge';

export default function BDDashboard() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<any>('/projects').then((res) => {
      setProjects(res.data || []);
    }).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">My Projects</h1>
        <Link href="/bd/submit" className="btn-primary">+ New Project</Link>
      </div>

      {loading && <p className="text-gray-500">Loading...</p>}
      {!loading && projects.length === 0 && (
        <div className="card text-center py-12">
          <p className="text-gray-500 mb-4">No projects submitted yet.</p>
          <Link href="/bd/submit" className="btn-primary">Submit Your First Project</Link>
        </div>
      )}

      {projects.length > 0 && (
        <div className="card overflow-hidden p-0">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left p-4 font-medium text-gray-600">Reference</th>
                <th className="text-left p-4 font-medium text-gray-600">Client Name</th>
                <th className="text-left p-4 font-medium text-gray-600">Scope</th>
                <th className="text-left p-4 font-medium text-gray-600">Submitted</th>
                <th className="text-left p-4 font-medium text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {projects.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="p-4 font-mono text-xs">{p.referenceNumber}</td>
                  <td className="p-4 font-medium">{p.clientName}</td>
                  <td className="p-4 text-gray-600 max-w-xs truncate">{p.scopeSummary}</td>
                  <td className="p-4 text-gray-500">
                    {new Date(p.submittedAt).toLocaleDateString()}
                  </td>
                  <td className="p-4">
                    <StatusBadge status={p.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
