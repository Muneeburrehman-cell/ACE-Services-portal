import { Navbar } from '@/components/layout/Navbar';

export default function EngineerLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar role="ESTIMATION_ENGINEER" />
      <main className="max-w-6xl mx-auto p-6">{children}</main>
    </div>
  );
}
