'use client';
import { Suspense } from 'react';
import { useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { api } from '@/lib/api';

function ResetPasswordForm() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get('token');
  const [step] = useState(token ? 'reset' : 'request');
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');
  const form = useForm();

  async function onRequest(data: any) {
    setError('');
    try {
      await api.post('/auth/forgot-password', { email: data.email });
      setDone(true);
    } catch (e: any) { setError(e.message); }
  }

  async function onReset(data: any) {
    if (data.newPassword !== data.confirm) { setError('Passwords do not match'); return; }
    setError('');
    try {
      await api.post('/auth/reset-password', { token, newPassword: data.newPassword });
      router.push('/login?reset=1');
    } catch (e: any) { setError(e.message); }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="card w-full max-w-md">
        <h1 className="text-xl font-bold mb-4">{token ? 'Set New Password' : 'Reset Password'}</h1>
        {done ? (
          <p className="text-green-700 text-sm">Check your email for a reset link.</p>
        ) : step === 'request' ? (
          <form onSubmit={form.handleSubmit(onRequest)} className="space-y-4">
            <input {...form.register('email')} type="email" className="input" placeholder="Your email" />
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button className="btn-primary w-full">Send Reset Link</button>
            <a href="/login" className="block text-center text-sm text-primary hover:underline">Back to login</a>
          </form>
        ) : (
          <form onSubmit={form.handleSubmit(onReset)} className="space-y-4">
            <input {...form.register('newPassword')} type="password" className="input" placeholder="New password (min 8 chars)" />
            <input {...form.register('confirm')} type="password" className="input" placeholder="Confirm password" />
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button className="btn-primary w-full">Set Password</button>
          </form>
        )}
      </div>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <ResetPasswordForm />
    </Suspense>
  );
}
