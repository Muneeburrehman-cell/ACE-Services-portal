'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { api } from '@/lib/api';
import { FileUploader } from '@/components/ui/FileUploader';

const schema = z.object({
  clientName: z.string().min(2),
  clientEmail: z.string().email(),
  clientPhone: z.string().min(7),
  scopeDescription: z.string().min(10),
  requestedDeadline: z.string().min(1),
});

export default function SubmitProjectPage() {
  const router = useRouter();
  const [projectId, setProjectId] = useState<string | null>(null);
  const [files, setFiles] = useState<any[]>([]);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const form = useForm({ resolver: zodResolver(schema) });

  async function onSubmit(data: any) {
    setError('');
    if (!projectId) {
      setError('Create the project draft and upload at least one file before submitting.');
      return;
    }
    if (files.length === 0) {
      setError('Please upload at least one project file.');
      return;
    }
    try {
      await api.post<any>(`/projects/${projectId}/submit`);
      setSuccess(true);
      setTimeout(() => router.push('/bd/dashboard'), 2000);
    } catch (e: any) {
      setError(e.message);
    }
  }

  async function createProjectAndGetId() {
    const valid = await form.trigger();
    if (!valid) return null;
    const data = form.getValues();
    try {
      const project = await api.post<any>('/projects', data);
      setProjectId(project.id);
      return project.id;
    } catch (e: any) {
      setError(e.message);
      return null;
    }
  }

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-6">Submit New Project</h1>

      {success ? (
        <div className="card text-center py-8">
          <div className="text-green-600 text-4xl mb-3">✓</div>
          <h2 className="text-xl font-semibold text-green-700">Project Submitted!</h2>
          <p className="text-gray-500 mt-2">Redirecting to your dashboard...</p>
        </div>
      ) : (
        <form onSubmit={form.handleSubmit(onSubmit)} className="card space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Client Name *</label>
              <input {...form.register('clientName')} className="input" />
              {form.formState.errors.clientName && <p className="text-red-500 text-xs mt-1">Required</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Client Email *</label>
              <input {...form.register('clientEmail')} type="email" className="input" />
              {form.formState.errors.clientEmail && <p className="text-red-500 text-xs mt-1">Valid email required</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Client Phone *</label>
              <input {...form.register('clientPhone')} type="tel" className="input" placeholder="+1 555 000 0000" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Requested Deadline *</label>
              <input {...form.register('requestedDeadline')} type="date" className="input" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Project Description *</label>
            <textarea {...form.register('scopeDescription')} rows={4} className="input resize-none" placeholder="Describe the scope of work..." />
            {form.formState.errors.scopeDescription && <p className="text-red-500 text-xs mt-1">Min 10 characters</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Project Files *</label>
            {projectId ? (
              <>
                <FileUploader
                  projectId={projectId}
                  fileType="intake"
                  onUpload={(f) => setFiles((prev) => [...prev, f])}
                />
                {files.length > 0 && (
                  <ul className="mt-2 space-y-1">
                    {files.map((f) => (
                      <li key={f.id} className="text-sm text-green-700">✓ {f.originalName}</li>
                    ))}
                  </ul>
                )}
              </>
            ) : (
              <p className="text-sm text-gray-500">
                Fill in the form fields above, then{' '}
                <button type="button" onClick={createProjectAndGetId} className="text-primary underline">
                  click here to enable file upload
                </button>
              </p>
            )}
          </div>

          {error && <p className="text-red-600 text-sm bg-red-50 p-3 rounded">{error}</p>}

          <div className="flex gap-3">
            <button type="submit" className="btn-primary" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? 'Submitting...' : 'Submit Project'}
            </button>
            <button type="button" onClick={() => router.back()} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
