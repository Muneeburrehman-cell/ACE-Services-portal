'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { api } from '@/lib/api';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { PriorityBadge } from '@/components/ui/PriorityBadge';
import { DeadlineCountdown } from '@/components/ui/DeadlineCountdown';
import { FileUploader } from '@/components/ui/FileUploader';

export default function EngineerProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [deliverables, setDeliverables] = useState<any[]>([]);

  useEffect(() => {
    api.get<any>(`/projects/${id}`).then((p) => {
      setProject(p);
      setDeliverables(p.deliverables || []);
      // Mark in progress when engineer opens project
      if (p.status === 'assigned') {
        api.patch(`/projects/${id}/status-in-progress`).catch(() => {});
      }
    }).finally(() => setLoading(false));
  }, [id]);

  async function downloadFile(fileId: string) {
    const res = await api.get<any>(`/files/${fileId}/download-url?type=intake`);
    window.open(res.url, '_blank');
  }

  const canUpload = project && !['delivered', 'sent_to_client'].includes(project.status);

  if (loading) return <div className="p-6 text-gray-500">Loading...</div>;
  if (!project) return <div className="p-6 text-red-500">Project not found</div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-bold">{project.referenceNumber}</h1>
        <StatusBadge status={project.status} />
        {project.priority && <PriorityBadge priority={project.priority} />}
      </div>

      {/* Scope & Instructions */}
      <div className="card space-y-4">
        <h2 className="font-semibold text-gray-800">Project Details</h2>
        <div>
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Scope Description</p>
          <p className="text-sm text-gray-700 whitespace-pre-wrap">{project.scopeDescription}</p>
        </div>
        {project.adminInstructions && (
          <div>
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Admin Instructions</p>
            <p className="text-sm text-gray-700 bg-yellow-50 p-3 rounded whitespace-pre-wrap">{project.adminInstructions}</p>
          </div>
        )}
        <div className="flex gap-8">
          <div>
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Deadline</p>
            <div className="mt-1"><DeadlineCountdown deadline={project.internalDeadline} /></div>
            {project.internalDeadline && (
              <p className="text-xs text-gray-400 mt-0.5">{new Date(project.internalDeadline).toLocaleDateString()}</p>
            )}
          </div>
        </div>
      </div>

      {/* Project Files */}
      <div className="card">
        <h2 className="font-semibold text-gray-800 mb-3">Project Files</h2>
        {project.files?.length === 0 && <p className="text-gray-500 text-sm">No files attached.</p>}
        <div className="space-y-2">
          {project.files?.map((f: any) => (
            <div key={f.id} className="flex items-center justify-between bg-gray-50 rounded p-3">
              <div>
                <p className="text-sm font-medium">{f.originalName}</p>
                <p className="text-xs text-gray-400">{(Number(f.sizeBytes) / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <button onClick={() => downloadFile(f.id)} className="btn-secondary text-xs">
                Download
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Deliver Work */}
      <div className="card">
        <h2 className="font-semibold text-gray-800 mb-3">Upload Completed Work</h2>
        {!canUpload ? (
          <p className="text-gray-500 text-sm">Work has been delivered. No further uploads allowed.</p>
        ) : (
          <>
            <FileUploader
              projectId={id}
              fileType="deliverable"
              onUpload={(f) => {
                setDeliverables((prev) => [...prev, f]);
                // Update status to delivered
                api.patch(`/projects/${id}/mark-delivered`).then(() => {
                  setProject((p: any) => ({ ...p, status: 'delivered' }));
                }).catch(() => {});
              }}
            />
            {deliverables.length > 0 && (
              <div className="mt-3 space-y-1">
                <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Uploaded Deliverables</p>
                {deliverables.map((d: any) => (
                  <p key={d.id} className="text-sm text-green-700">✓ {d.originalName}</p>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
