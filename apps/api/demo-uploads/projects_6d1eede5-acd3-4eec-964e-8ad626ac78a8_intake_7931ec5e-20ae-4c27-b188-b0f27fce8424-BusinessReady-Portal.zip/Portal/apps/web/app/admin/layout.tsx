import { Navbar } from '@/components/layout/Navbar';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar role="ADMIN" />
      <main className="max-w-7xl mx-auto p-6">{children}</main>
    </div>
  );
}
