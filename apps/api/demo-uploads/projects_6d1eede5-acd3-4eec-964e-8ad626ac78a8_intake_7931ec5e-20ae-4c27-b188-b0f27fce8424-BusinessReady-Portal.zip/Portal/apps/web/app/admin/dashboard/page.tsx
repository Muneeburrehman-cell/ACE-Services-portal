'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { PriorityBadge } from '@/components/ui/PriorityBadge';
import { DeadlineCountdown } from '@/components/ui/DeadlineCountdown';

const STATUSES = ['received', 'assigned', 'in_progress', 'delivered', 'sent_to_client'];

export default function AdminDashboard() {
  const [projects, setProjects] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ status: '', search: '', page: 1 });

  function fetchProjects(f = filters) {
    setLoading(true);
    const params = new URLSearchParams();
    if (f.status) params.set('status', f.status);
    if (f.search) params.set('search', f.search);
    params.set('page', String(f.page));
    api.get<any>(`/projects?${params}`).then((res) => {
      setProjects(res.data || []);
      setTotal(res.total || 0);
    }).finally(() => setLoading(false));
  }

  useEffect(() => { fetchProjects(); }, []);

  function setFilter(key: string, value: any) {
    const next = { ...filters, [key]: value, page: 1 };
    setFilters(next);
    fetchProjects(next);
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Project Pipeline</h1>
        <span className="text-sm text-gray-500">{total} total</span>
      </div>

      {/* Filter bar */}
      <div className="flex gap-3 mb-4 flex-wrap">
        <input
          placeholder="Search by client name or reference..."
          className="input max-w-xs text-sm"
          onChange={(e) => setFilter('search', e.target.value)}
        />
        <select className="input max-w-xs text-sm" onChange={(e) => setFilter('status', e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
      </div>

      {loading ? (
        <p className="text-gray-500">Loading...</p>
      ) : (
        <div className="card overflow-hidden p-0">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left p-4 font-medium text-gray-600">Reference</th>
                <th className="text-left p-4 font-medium text-gray-600">Client</th>
                <th className="text-left p-4 font-medium text-gray-600">Submitted By</th>
                <th className="text-left p-4 font-medium text-gray-600">Assigned To</th>
                <th className="text-left p-4 font-medium text-gray-600">Priority</th>
                <th className="text-left p-4 font-medium text-gray-600">Deadline</th>
                <th className="text-left p-4 font-medium text-gray-600">Status</th>
                <th className="p-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {projects.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="p-4 font-mono text-xs">{p.referenceNumber}</td>
                  <td className="p-4">
                    <p className="font-medium">{p.clientName}</p>
                    <p className="text-xs text-gray-400">{p.clientEmail}</p>
                  </td>
                  <td className="p-4 text-gray-500 text-xs">{p.bdAgentName}</td>
                  <td className="p-4 text-xs">
                    {p.assignedEngineer?.fullName || <span className="text-gray-400">Unassigned</span>}
                  </td>
                  <td className="p-4">{p.priority && <PriorityBadge priority={p.priority} />}</td>
                  <td className="p-4"><DeadlineCountdown deadline={p.internalDeadline} /></td>
                  <td className="p-4"><StatusBadge status={p.status} /></td>
                  <td className="p-4">
                    <Link href={`/admin/projects/${p.id}`} className="text-primary text-sm hover:underline">
                      Manage →
                    </Link>
                  </td>
                </tr>
              ))}
              {projects.length === 0 && (
                <tr><td colSpan={8} className="p-8 text-center text-gray-400">No projects found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
