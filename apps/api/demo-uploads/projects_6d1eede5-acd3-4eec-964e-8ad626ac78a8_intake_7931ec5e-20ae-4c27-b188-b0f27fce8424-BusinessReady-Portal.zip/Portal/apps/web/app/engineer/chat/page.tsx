'use client';
export { default } from '@/app/bd/chat/page';
