'use client';

const colors: Record<string, string> = {
  low: 'bg-gray-100 text-gray-700',
  medium: 'bg-blue-100 text-blue-700',
  high: 'bg-orange-100 text-orange-700',
  urgent: 'bg-red-100 text-red-700',
};

export function PriorityBadge({ priority }: { priority: string }) {
  return (
    <span className={`badge ${colors[priority] || 'bg-gray-100 text-gray-600'} uppercase`}>
      {priority}
    </span>
  );
}
