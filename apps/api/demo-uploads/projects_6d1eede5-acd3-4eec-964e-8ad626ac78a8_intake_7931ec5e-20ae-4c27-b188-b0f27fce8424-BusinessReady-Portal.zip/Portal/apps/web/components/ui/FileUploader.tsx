'use client';
import { useState, useRef } from 'react';
import { api, getAccessToken } from '@/lib/api';

const ALLOWED = '.pdf,.dwg,.dxf,.png,.jpg,.jpeg,.xlsx,.docx,.zip';
const MAX_SIZE = 100 * 1024 * 1024;

interface UploadedFile { id: string; originalName: string; }

interface Props {
  projectId: string;
  fileType: 'intake' | 'deliverable';
  onUpload: (file: UploadedFile) => void;
  disabled?: boolean;
}

export function FileUploader({ projectId, fileType, onUpload, disabled }: Props) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setError('');

    for (const file of Array.from(files)) {
      if (file.size > MAX_SIZE) {
        setError(`${file.name} exceeds the 100 MB limit`);
        continue;
      }

      setUploading(true);
      setProgress(10);

      try {
        // 1. Get pre-signed upload URL
        const { uploadUrl, s3Key } = await api.post<any>('/files/upload-url', {
          projectId,
          fileName: file.name,
          mimeType: file.type || 'application/octet-stream',
          sizeBytes: file.size,
          fileType,
        });

        setProgress(30);

        // 2. Upload directly to S3
        const token = getAccessToken();
        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.open('PUT', uploadUrl);
          xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
              setProgress(30 + Math.round((e.loaded / e.total) * 60));
            }
          };
          xhr.onload = () => (xhr.status < 300 ? resolve() : reject(new Error(`S3 upload failed: ${xhr.status}`)));
          xhr.onerror = () => reject(new Error('Network error'));
          xhr.send(file);
        });

        setProgress(95);

        // 3. Confirm upload
        const confirmed = await api.post<UploadedFile>('/files/confirm', {
          projectId,
          s3Key,
          originalName: file.name,
          mimeType: file.type,
          sizeBytes: file.size,
          fileType,
        });

        setProgress(100);
        onUpload(confirmed);
      } catch (err: any) {
        setError(err.message || 'Upload failed');
      } finally {
        setUploading(false);
        setProgress(0);
      }
    }
  }

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept={ALLOWED}
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
        disabled={disabled || uploading}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={disabled || uploading}
        className="btn-secondary text-sm"
      >
        {uploading ? `Uploading... ${progress}%` : 'Choose Files'}
      </button>
      {uploading && (
        <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
          <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${progress}%` }} />
        </div>
      )}
      {error && <p className="text-red-600 text-sm mt-1">{error}</p>}
      <p className="text-gray-400 text-xs mt-1">
        Accepted: PDF, DWG, DXF, PNG, JPG, XLSX, DOCX, ZIP · Max 100 MB per file
      </p>
    </div>
  );
}
