'use client';

export function DeadlineCountdown({ deadline }: { deadline: string | null }) {
  if (!deadline) return <span className="text-gray-400 text-sm">No deadline</span>;

  const now = new Date();
  const due = new Date(deadline);
  const diffMs = due.getTime() - now.getTime();

  if (diffMs < 0) {
    return <span className="text-red-600 font-semibold text-sm">Overdue</span>;
  }

  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

  const color = days === 0 ? 'text-red-600' : days <= 3 ? 'text-amber-600' : 'text-green-700';
  return (
    <span className={`text-sm font-medium ${color}`}>
      {days}d {hours}h
    </span>
  );
}
