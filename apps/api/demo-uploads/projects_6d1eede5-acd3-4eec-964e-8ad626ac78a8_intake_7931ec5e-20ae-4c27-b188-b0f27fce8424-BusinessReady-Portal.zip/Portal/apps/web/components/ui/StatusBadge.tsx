'use client';

const statusColors: Record<string, string> = {
  received: 'bg-blue-100 text-blue-800',
  assigned: 'bg-yellow-100 text-yellow-800',
  in_progress: 'bg-orange-100 text-orange-800',
  delivered: 'bg-green-100 text-green-800',
  sent_to_client: 'bg-purple-100 text-purple-800',
  Received: 'bg-blue-100 text-blue-800',
};

const statusLabels: Record<string, string> = {
  received: 'Received',
  assigned: 'Assigned',
  in_progress: 'In Progress',
  delivered: 'Delivered',
  sent_to_client: 'Sent to Client',
  Received: 'Received',
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`badge ${statusColors[status] || 'bg-gray-100 text-gray-700'}`}>
      {statusLabels[status] || status}
    </span>
  );
}
